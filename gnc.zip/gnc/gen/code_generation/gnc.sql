-- root-types-contained: SystemModel_c,PackageableElement_c,DataType_c,CoreDataType_c,UserDataType_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES ("d923df31-2d4f-4454-ba3a-3347665a758b",
	'gnc',
	1);
INSERT INTO EP_PKG
	VALUES ("a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'External Entities',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("2fd70a9f-eaa7-4d40-a481-ff861310433e",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Time',
	1);
INSERT INTO S_BRG
	VALUES ("7cedef90-3ff6-47cb-865f-f2a4d5cdfb21",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'current_date',
	'',
	1,
	"ba5eda7a-def5-0000-0000-00000000000e",
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("a69ecc6e-750b-44f9-a6ca-23a6dce1e32b",
	"7cedef90-3ff6-47cb-865f-f2a4d5cdfb21");
INSERT INTO ACT_ACT
	VALUES ("a69ecc6e-750b-44f9-a6ca-23a6dce1e32b",
	'bridge',
	0,
	"1b6f7dbf-4f67-4991-9bc5-595dd79c1549",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::current_date',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("1b6f7dbf-4f67-4991-9bc5-595dd79c1549",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a69ecc6e-750b-44f9-a6ca-23a6dce1e32b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("885835ed-0d41-44d5-a1b5-7e8007ff883a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'create_date',
	'',
	1,
	"ba5eda7a-def5-0000-0000-00000000000e",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("e26eddec-36ab-4e36-b856-1eaa69692c14",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'second',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"8c2f8836-521b-4f47-ba97-f9c8309b52f4",
	'');
INSERT INTO S_BPARM
	VALUES ("2ed26ccd-e8f8-4e38-aac7-f825b913f96f",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'minute',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"75124bf0-c1ce-4dca-bc91-21ac16396b72",
	'');
INSERT INTO S_BPARM
	VALUES ("75124bf0-c1ce-4dca-bc91-21ac16396b72",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'hour',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"95196946-0edf-4e69-b2ad-4b20d5c78fda",
	'');
INSERT INTO S_BPARM
	VALUES ("95196946-0edf-4e69-b2ad-4b20d5c78fda",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'day',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("8c2f8836-521b-4f47-ba97-f9c8309b52f4",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'month',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"2ed26ccd-e8f8-4e38-aac7-f825b913f96f",
	'');
INSERT INTO S_BPARM
	VALUES ("e0545463-2cc1-4caf-b6f4-baff465c1370",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'year',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"e26eddec-36ab-4e36-b856-1eaa69692c14",
	'');
INSERT INTO ACT_BRB
	VALUES ("98058156-88de-4070-9f5b-2edbd6c57649",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a");
INSERT INTO ACT_ACT
	VALUES ("98058156-88de-4070-9f5b-2edbd6c57649",
	'bridge',
	0,
	"416adc4c-f07e-48e8-9106-9e78723612a0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::create_date',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("416adc4c-f07e-48e8-9106-9e78723612a0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"98058156-88de-4070-9f5b-2edbd6c57649",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("0de4654f-76f7-44f5-ad32-307f6f132e9e",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_second',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("4e33a7dd-1a67-4b85-8dbc-2b8c12bacc71",
	"0de4654f-76f7-44f5-ad32-307f6f132e9e",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("69c411fc-c441-4e10-9029-79528323bfbf",
	"0de4654f-76f7-44f5-ad32-307f6f132e9e");
INSERT INTO ACT_ACT
	VALUES ("69c411fc-c441-4e10-9029-79528323bfbf",
	'bridge',
	0,
	"2adcc580-7f11-4429-b7a4-d1a28189a3e9",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_second',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("2adcc580-7f11-4429-b7a4-d1a28189a3e9",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"69c411fc-c441-4e10-9029-79528323bfbf",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("506ec051-e809-4ad3-838c-dbcce43a116c",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_minute',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("095f3f5c-db7f-4e4a-9bda-63ac8efeeab6",
	"506ec051-e809-4ad3-838c-dbcce43a116c",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("9850e7b4-73ef-4e18-ae3c-3a128d28ae05",
	"506ec051-e809-4ad3-838c-dbcce43a116c");
INSERT INTO ACT_ACT
	VALUES ("9850e7b4-73ef-4e18-ae3c-3a128d28ae05",
	'bridge',
	0,
	"fd2405da-ed22-4fe2-b9aa-31f150a5f04c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_minute',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("fd2405da-ed22-4fe2-b9aa-31f150a5f04c",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9850e7b4-73ef-4e18-ae3c-3a128d28ae05",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("d91d2b03-9a66-47ef-9dac-87b57f9266a8",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_hour',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("eeeb6b29-233f-4034-92c3-3480f65cfd43",
	"d91d2b03-9a66-47ef-9dac-87b57f9266a8",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("4b3dcc7b-b9fb-49b0-98e0-bf8dc212988a",
	"d91d2b03-9a66-47ef-9dac-87b57f9266a8");
INSERT INTO ACT_ACT
	VALUES ("4b3dcc7b-b9fb-49b0-98e0-bf8dc212988a",
	'bridge',
	0,
	"b2371ff6-dcd5-4530-ae24-557e8f02b3be",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_hour',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b2371ff6-dcd5-4530-ae24-557e8f02b3be",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4b3dcc7b-b9fb-49b0-98e0-bf8dc212988a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("05736629-401d-4624-8114-cfffe7db2ff0",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_day',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("136fa754-90f9-476a-84af-8c0f0f4c6c2a",
	"05736629-401d-4624-8114-cfffe7db2ff0",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("0e6ae622-699d-4dc7-9085-498afac713ba",
	"05736629-401d-4624-8114-cfffe7db2ff0");
INSERT INTO ACT_ACT
	VALUES ("0e6ae622-699d-4dc7-9085-498afac713ba",
	'bridge',
	0,
	"3b0ec412-6f68-4d5c-aeae-1c86d27bc0b7",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_day',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3b0ec412-6f68-4d5c-aeae-1c86d27bc0b7",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0e6ae622-699d-4dc7-9085-498afac713ba",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("23a621c8-1743-46d0-9f13-3f7faa7dec6a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_month',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5754c5a5-c178-4367-8077-e0151b686a96",
	"23a621c8-1743-46d0-9f13-3f7faa7dec6a",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("cc237a7d-8b4a-4e15-8127-cd714c0b18fc",
	"23a621c8-1743-46d0-9f13-3f7faa7dec6a");
INSERT INTO ACT_ACT
	VALUES ("cc237a7d-8b4a-4e15-8127-cd714c0b18fc",
	'bridge',
	0,
	"e5719d4a-f3cc-4273-aa00-a297013a4eed",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_month',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e5719d4a-f3cc-4273-aa00-a297013a4eed",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"cc237a7d-8b4a-4e15-8127-cd714c0b18fc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("22dd5f8d-8ec0-480b-aa7c-c2b3c5155230",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_year',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("b068413b-fb88-4844-9237-7b9648f4a69e",
	"22dd5f8d-8ec0-480b-aa7c-c2b3c5155230",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("6541ca10-800e-4258-acfe-adddcf94331a",
	"22dd5f8d-8ec0-480b-aa7c-c2b3c5155230");
INSERT INTO ACT_ACT
	VALUES ("6541ca10-800e-4258-acfe-adddcf94331a",
	'bridge',
	0,
	"b80e00fe-8cf0-4b7c-9a80-9ff7b47e503b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_year',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b80e00fe-8cf0-4b7c-9a80-9ff7b47e503b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6541ca10-800e-4258-acfe-adddcf94331a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("eccc3978-a3d3-4735-8b47-3973a041f799",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'current_clock',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000010",
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("e00ad8f0-0717-4db1-b697-a3fd406bb975",
	"eccc3978-a3d3-4735-8b47-3973a041f799");
INSERT INTO ACT_ACT
	VALUES ("e00ad8f0-0717-4db1-b697-a3fd406bb975",
	'bridge',
	0,
	"b1e2772f-59c0-48c3-837c-a9ca2493ef9c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::current_clock',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b1e2772f-59c0-48c3-837c-a9ca2493ef9c",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e00ad8f0-0717-4db1-b697-a3fd406bb975",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("012516b5-2372-4c49-bcac-48cf3499122a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	1,
	"ba5eda7a-def5-0000-0000-00000000000f",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fec87e8d-6d3c-4d19-9c2b-b629eefd2276",
	"012516b5-2372-4c49-bcac-48cf3499122a",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"47ecb3cc-fc05-47d4-afc1-693328b6c942",
	'');
INSERT INTO S_BPARM
	VALUES ("47ecb3cc-fc05-47d4-afc1-693328b6c942",
	"012516b5-2372-4c49-bcac-48cf3499122a",
	'event_inst',
	"ba5eda7a-def5-0000-0000-00000000000a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("0ce646a5-f400-4771-a7dd-2cf9ce1b0640",
	"012516b5-2372-4c49-bcac-48cf3499122a");
INSERT INTO ACT_ACT
	VALUES ("0ce646a5-f400-4771-a7dd-2cf9ce1b0640",
	'bridge',
	0,
	"32dd35e4-4b2b-407e-a97d-9fa363688071",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("32dd35e4-4b2b-407e-a97d-9fa363688071",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0ce646a5-f400-4771-a7dd-2cf9ce1b0640",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	1,
	"ba5eda7a-def5-0000-0000-00000000000f",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("0006b186-f90c-446a-9b32-fbeb81f82b83",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"11f05ffe-227e-4e23-a720-4313facbac55",
	'');
INSERT INTO S_BPARM
	VALUES ("11f05ffe-227e-4e23-a720-4313facbac55",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	'event_inst',
	"ba5eda7a-def5-0000-0000-00000000000a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("2fa6852e-b62f-4364-b5ff-135f79970778",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7");
INSERT INTO ACT_ACT
	VALUES ("2fa6852e-b62f-4364-b5ff-135f79970778",
	'bridge',
	0,
	"500c4ea0-b2af-4659-833f-fcfd6f7c7058",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_start_recurring',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("500c4ea0-b2af-4659-833f-fcfd6f7c7058",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"2fa6852e-b62f-4364-b5ff-135f79970778",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b2c8f339-b0a5-4e8a-b153-0267d79f5781",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("9666bafd-8990-4372-9988-4618b7b9be38",
	"b2c8f339-b0a5-4e8a-b153-0267d79f5781",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("d311fc44-e74f-41c7-8dc6-043fe9eddfc7",
	"b2c8f339-b0a5-4e8a-b153-0267d79f5781");
INSERT INTO ACT_ACT
	VALUES ("d311fc44-e74f-41c7-8dc6-043fe9eddfc7",
	'bridge',
	0,
	"aa8c5b6e-56f8-4e20-b055-dd33336b2d4a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_remaining_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("aa8c5b6e-56f8-4e20-b055-dd33336b2d4a",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"d311fc44-e74f-41c7-8dc6-043fe9eddfc7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("b06bfb31-6f55-427e-9334-14b888ff1d20",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"24f4f888-57da-472b-9a64-d4bc284b78aa",
	'');
INSERT INTO S_BPARM
	VALUES ("24f4f888-57da-472b-9a64-d4bc284b78aa",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("b2de7ea9-49bc-4db3-a495-94de01734aa1",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4");
INSERT INTO ACT_ACT
	VALUES ("b2de7ea9-49bc-4db3-a495-94de01734aa1",
	'bridge',
	0,
	"9a666c72-50ca-4d9b-87cb-f3ab03daa17e",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_reset_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9a666c72-50ca-4d9b-87cb-f3ab03daa17e",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b2de7ea9-49bc-4db3-a495-94de01734aa1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("11329069-afb1-43bf-a9a3-0c9755931c05",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"005c5ae9-3661-4f79-a4e3-b6ae086be86b",
	'');
INSERT INTO S_BPARM
	VALUES ("005c5ae9-3661-4f79-a4e3-b6ae086be86b",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("c6362497-65e4-43ab-af4e-6077e2a7c0d7",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a");
INSERT INTO ACT_ACT
	VALUES ("c6362497-65e4-43ab-af4e-6077e2a7c0d7",
	'bridge',
	0,
	"4c035c14-c431-4b8b-8aac-3ffd99ab3d64",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_add_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("4c035c14-c431-4b8b-8aac-3ffd99ab3d64",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c6362497-65e4-43ab-af4e-6077e2a7c0d7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("d749e717-9081-4287-9128-876514c2a5c9",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5a8c78a4-7963-42d8-8e92-bcbecc0c513e",
	"d749e717-9081-4287-9128-876514c2a5c9",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("5b1f4a7e-a278-4e2a-a38b-25481cb4bda3",
	"d749e717-9081-4287-9128-876514c2a5c9");
INSERT INTO ACT_ACT
	VALUES ("5b1f4a7e-a278-4e2a-a38b-25481cb4bda3",
	'bridge',
	0,
	"6901688f-f73c-463c-91af-5f800c2a00a0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_cancel',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6901688f-f73c-463c-91af-5f800c2a00a0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5b1f4a7e-a278-4e2a-a38b-25481cb4bda3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	'Architecture',
	'',
	'ARCH',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Architecture',
	1);
INSERT INTO S_BRG
	VALUES ("01612056-7900-41ae-ad03-f233e1da0a84",
	"f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	'shutdown',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'control stop;',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("205414fc-397f-4d46-a2a4-9f591a8f1329",
	"01612056-7900-41ae-ad03-f233e1da0a84");
INSERT INTO ACT_ACT
	VALUES ("205414fc-397f-4d46-a2a4-9f591a8f1329",
	'bridge',
	0,
	"0c1c9eb0-8d49-497b-bc87-18b8cb59a0c2",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Architecture::shutdown',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("0c1c9eb0-8d49-497b-bc87-18b8cb59a0c2",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"205414fc-397f-4d46-a2a4-9f591a8f1329",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("f4c3bce5-f816-4879-b900-29337316c79d",
	"0c1c9eb0-8d49-497b-bc87-18b8cb59a0c2",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Architecture::shutdown line: 1');
INSERT INTO ACT_CTL
	VALUES ("f4c3bce5-f816-4879-b900-29337316c79d");
INSERT INTO PE_PE
	VALUES ("36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'Logging',
	'',
	'LOG',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Logging',
	1);
INSERT INTO S_BRG
	VALUES ("b65db544-13fe-459b-9436-379c46f3f884",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogSuccess',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("1b690e45-945a-4138-aaf9-971ac7b80bdb",
	"b65db544-13fe-459b-9436-379c46f3f884",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("aa0ef329-1a7a-448a-b87e-522b31f2a464",
	"b65db544-13fe-459b-9436-379c46f3f884");
INSERT INTO ACT_ACT
	VALUES ("aa0ef329-1a7a-448a-b87e-522b31f2a464",
	'bridge',
	0,
	"347b0176-93fb-4184-aeda-a631ea0a67e5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogSuccess',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("347b0176-93fb-4184-aeda-a631ea0a67e5",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"aa0ef329-1a7a-448a-b87e-522b31f2a464",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("26845840-b5bb-49bf-8a74-624a2a16e1cb",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogFailure',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("447876ec-a5c7-4c70-992a-e5777aacf5cd",
	"26845840-b5bb-49bf-8a74-624a2a16e1cb",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("8c13674b-a82b-493e-b5df-e72fd66d3981",
	"26845840-b5bb-49bf-8a74-624a2a16e1cb");
INSERT INTO ACT_ACT
	VALUES ("8c13674b-a82b-493e-b5df-e72fd66d3981",
	'bridge',
	0,
	"d5ce0a67-68fd-4106-81fe-28344b1be91f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogFailure',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d5ce0a67-68fd-4106-81fe-28344b1be91f",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8c13674b-a82b-493e-b5df-e72fd66d3981",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("c4857b04-079f-4db0-947c-e1895ef20ea4",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogInfo',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("92cfb361-9539-48da-928e-44aceb487d80",
	"c4857b04-079f-4db0-947c-e1895ef20ea4",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("93f148e3-37ac-41c2-9bc0-dffd98f5458b",
	"c4857b04-079f-4db0-947c-e1895ef20ea4");
INSERT INTO ACT_ACT
	VALUES ("93f148e3-37ac-41c2-9bc0-dffd98f5458b",
	'bridge',
	0,
	"a5ed0ba5-11fe-4c55-82c8-297a741d3622",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInfo',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a5ed0ba5-11fe-4c55-82c8-297a741d3622",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"93f148e3-37ac-41c2-9bc0-dffd98f5458b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogDate',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fb65973c-ceb7-450f-8981-a8ce6822e2de",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	'd',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("da6ae748-69cb-4fd9-9355-f3beb44f4ce1",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"fb65973c-ceb7-450f-8981-a8ce6822e2de",
	'');
INSERT INTO ACT_BRB
	VALUES ("661f47bd-3035-4d28-8d55-72d5cb70a42a",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b");
INSERT INTO ACT_ACT
	VALUES ("661f47bd-3035-4d28-8d55-72d5cb70a42a",
	'bridge',
	0,
	"7467e2c2-07b9-49a9-bb41-f2d0a3591bd3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogDate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7467e2c2-07b9-49a9-bb41-f2d0a3591bd3",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"661f47bd-3035-4d28-8d55-72d5cb70a42a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogTime',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fc4ab462-604f-439c-a0a2-3276f17853a0",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	't',
	"ba5eda7a-def5-0000-0000-000000000010",
	0,
	'',
	"9fe61b3c-a2ce-41ea-b42e-a05fe4c6b91b",
	'');
INSERT INTO S_BPARM
	VALUES ("9fe61b3c-a2ce-41ea-b42e-a05fe4c6b91b",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("0a5dc69d-026e-48e6-8728-fd1320a0ceb0",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7");
INSERT INTO ACT_ACT
	VALUES ("0a5dc69d-026e-48e6-8728-fd1320a0ceb0",
	'bridge',
	0,
	"fa9673af-fdf5-40e2-82a8-652a4cf355c6",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogTime',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("fa9673af-fdf5-40e2-82a8-652a4cf355c6",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0a5dc69d-026e-48e6-8728-fd1320a0ceb0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("4d8d47cc-720d-46e5-ae28-e54cd975a427",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogReal',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("d31c8f8b-38b0-4ada-8945-5ba88d4fc6f5",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427",
	'r',
	"ba5eda7a-def5-0000-0000-000000000003",
	0,
	'',
	"060aba76-3308-4400-aa11-0843cf3c8b7a",
	'');
INSERT INTO S_BPARM
	VALUES ("060aba76-3308-4400-aa11-0843cf3c8b7a",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("a1d3f81f-52b8-48f1-beb4-cfa89878da12",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427");
INSERT INTO ACT_ACT
	VALUES ("a1d3f81f-52b8-48f1-beb4-cfa89878da12",
	'bridge',
	0,
	"b4be286e-8a74-4b61-9c4f-39e23aa3074c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogReal',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b4be286e-8a74-4b61-9c4f-39e23aa3074c",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a1d3f81f-52b8-48f1-beb4-cfa89878da12",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b7d2a809-9794-4b40-87e1-b7c0686375e0",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogInteger',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5b5bf126-0e25-42a2-bb8e-0aa375d5b213",
	"b7d2a809-9794-4b40-87e1-b7c0686375e0",
	'message',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("b799e390-3250-4f94-8c7a-189385019b9e",
	"b7d2a809-9794-4b40-87e1-b7c0686375e0");
INSERT INTO ACT_ACT
	VALUES ("b799e390-3250-4f94-8c7a-189385019b9e",
	'bridge',
	0,
	"c2c83260-e2a9-4802-b305-679559f36281",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInteger',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c2c83260-e2a9-4802-b305-679559f36281",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b799e390-3250-4f94-8c7a-189385019b9e",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO EP_PKG
	VALUES ("0924fcd2-185c-4c76-b1c2-5ce790f1ba0a",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Interfaces',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("78776ad7-dffd-4126-8217-a913ac6e4bc8",
	1,
	"0924fcd2-185c-4c76-b1c2-5ce790f1ba0a",
	"00000000-0000-0000-0000-000000000000",
	6);
INSERT INTO C_I
	VALUES ("78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO C_EP
	VALUES ("b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'init',
	'');
INSERT INTO C_IO
	VALUES ("b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"ba5eda7a-def5-0000-0000-000000000000",
	'init',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'takeoff',
	'');
INSERT INTO C_IO
	VALUES ("7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"ba5eda7a-def5-0000-0000-000000000000",
	'takeoff',
	'',
	0,
	'',
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e");
INSERT INTO C_PP
	VALUES ("82188d43-e348-4d1f-89d7-47f817a84ae6",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"ba5eda7a-def5-0000-0000-000000000003",
	'alt',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'land',
	'');
INSERT INTO C_IO
	VALUES ("37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"ba5eda7a-def5-0000-0000-000000000000",
	'land',
	'',
	0,
	'',
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17");
INSERT INTO C_EP
	VALUES ("c53d4966-9097-4e62-8e45-bb3b7522378a",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'arm',
	'');
INSERT INTO C_IO
	VALUES ("c53d4966-9097-4e62-8e45-bb3b7522378a",
	"ba5eda7a-def5-0000-0000-000000000000",
	'arm',
	'',
	0,
	'',
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456");
INSERT INTO C_EP
	VALUES ("248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'set_destination',
	'');
INSERT INTO C_IO
	VALUES ("248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000000",
	'set_destination',
	'',
	0,
	'',
	"c53d4966-9097-4e62-8e45-bb3b7522378a");
INSERT INTO C_PP
	VALUES ("7f707e01-0f0a-48c7-afd8-8245ae5ea78d",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'x',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_PP
	VALUES ("a91a89dc-0d33-4ff1-9a4a-2367638a7031",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'y',
	'',
	0,
	'',
	"7f707e01-0f0a-48c7-afd8-8245ae5ea78d");
INSERT INTO C_PP
	VALUES ("a760ebd0-ab62-475c-b0ee-4c8528096f1d",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'z',
	'',
	0,
	'',
	"a91a89dc-0d33-4ff1-9a4a-2367638a7031");
INSERT INTO C_EP
	VALUES ("c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'set_heading',
	'');
INSERT INTO C_IO
	VALUES ("c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"ba5eda7a-def5-0000-0000-000000000000",
	'set_heading',
	'',
	0,
	'',
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279");
INSERT INTO C_PP
	VALUES ("d4a22d73-9f5f-4533-8c78-eab99944cb1f",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"ba5eda7a-def5-0000-0000-000000000003",
	'heading',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("7576d5e0-2683-4a42-967a-ddb25a458620",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'get_heading',
	'');
INSERT INTO C_IO
	VALUES ("7576d5e0-2683-4a42-967a-ddb25a458620",
	"ba5eda7a-def5-0000-0000-000000000003",
	'get_heading',
	'',
	0,
	'',
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52");
INSERT INTO C_EP
	VALUES ("e2e61698-b9dc-4911-95c7-79872095f0dd",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'ready',
	'');
INSERT INTO C_IO
	VALUES ("e2e61698-b9dc-4911-95c7-79872095f0dd",
	"ba5eda7a-def5-0000-0000-000000000000",
	'ready',
	'',
	1,
	'',
	"7576d5e0-2683-4a42-967a-ddb25a458620");
INSERT INTO EP_PKG
	VALUES ("d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Library',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	1,
	"d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"00000000-0000-0000-0000-000000000000",
	2);
INSERT INTO C_C
	VALUES ("8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'MAV',
	'',
	0,
	"00000000-0000-0000-0000-000000000000",
	0,
	'');
INSERT INTO C_PO
	VALUES ("9df3483a-ab97-4ee7-8415-9b4b161408e2",
	"8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	'Port1',
	0,
	0);
INSERT INTO C_IR
	VALUES ("93221829-0135-489c-961a-9d42c4252036",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	"9df3483a-ab97-4ee7-8415-9b4b161408e2");
INSERT INTO C_P
	VALUES ("93221829-0135-489c-961a-9d42c4252036",
	'mavcontrol',
	'Unnamed Interface',
	'',
	'MAV::Port1::mavcontrol');
INSERT INTO SPR_PEP
	VALUES ("2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a",
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a",
	'init',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("9b27ab60-1023-437c-bd4e-30819d395707",
	"2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a");
INSERT INTO ACT_ACT
	VALUES ("9b27ab60-1023-437c-bd4e-30819d395707",
	'interface operation',
	0,
	"49493edb-09f2-4f1c-b4ce-4f3bd1e1a940",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("49493edb-09f2-4f1c-b4ce-4f3bd1e1a940",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9b27ab60-1023-437c-bd4e-30819d395707",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("17b9223c-4fbe-4528-9d24-88e8c6b169cb",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("17b9223c-4fbe-4528-9d24-88e8c6b169cb",
	'takeoff',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("f9ec36ad-af0e-4fbb-9215-40f66dc455c1",
	"17b9223c-4fbe-4528-9d24-88e8c6b169cb");
INSERT INTO ACT_ACT
	VALUES ("f9ec36ad-af0e-4fbb-9215-40f66dc455c1",
	'interface operation',
	0,
	"43c0b14e-fa28-4814-b3fb-04bb45f55178",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::takeoff',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("43c0b14e-fa28-4814-b3fb-04bb45f55178",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f9ec36ad-af0e-4fbb-9215-40f66dc455c1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("843b9758-6f7e-434f-80e7-cbe244ffbe3f",
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("843b9758-6f7e-434f-80e7-cbe244ffbe3f",
	'land',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("1cf7a500-295f-4244-8151-c29029818a6a",
	"843b9758-6f7e-434f-80e7-cbe244ffbe3f");
INSERT INTO ACT_ACT
	VALUES ("1cf7a500-295f-4244-8151-c29029818a6a",
	'interface operation',
	0,
	"7d92392d-bef4-4aaa-8afe-9910e47ece0c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("7d92392d-bef4-4aaa-8afe-9910e47ece0c",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"1cf7a500-295f-4244-8151-c29029818a6a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("5485bf8e-c85a-4150-857c-8bb2aec093d7",
	"c53d4966-9097-4e62-8e45-bb3b7522378a",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("5485bf8e-c85a-4150-857c-8bb2aec093d7",
	'arm',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("2f6e1982-61f0-4461-90e7-4aec5b555a27",
	"5485bf8e-c85a-4150-857c-8bb2aec093d7");
INSERT INTO ACT_ACT
	VALUES ("2f6e1982-61f0-4461-90e7-4aec5b555a27",
	'interface operation',
	0,
	"24dbb77a-ae7e-4a2c-ba67-ea99c1b010b2",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::arm',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("24dbb77a-ae7e-4a2c-ba67-ea99c1b010b2",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"2f6e1982-61f0-4461-90e7-4aec5b555a27",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("9594ac6d-f38c-4123-b2f9-00a11f9f948b",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("9594ac6d-f38c-4123-b2f9-00a11f9f948b",
	'set_destination',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("c1e1d55c-7b9a-4ba0-8c2e-c5fe3770f6f0",
	"9594ac6d-f38c-4123-b2f9-00a11f9f948b");
INSERT INTO ACT_ACT
	VALUES ("c1e1d55c-7b9a-4ba0-8c2e-c5fe3770f6f0",
	'interface operation',
	0,
	"ff58b005-849f-4944-bba9-75bcad136119",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_destination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ff58b005-849f-4944-bba9-75bcad136119",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c1e1d55c-7b9a-4ba0-8c2e-c5fe3770f6f0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("0754e734-d3da-4fa8-bff4-fad81e3b5d4b",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("0754e734-d3da-4fa8-bff4-fad81e3b5d4b",
	'set_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("31057f59-c535-4e75-98a6-23a9ed3aca3c",
	"0754e734-d3da-4fa8-bff4-fad81e3b5d4b");
INSERT INTO ACT_ACT
	VALUES ("31057f59-c535-4e75-98a6-23a9ed3aca3c",
	'interface operation',
	0,
	"a3e64706-a262-454e-a02b-e77408a496d5",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a3e64706-a262-454e-a02b-e77408a496d5",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"31057f59-c535-4e75-98a6-23a9ed3aca3c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("5c3a02de-f488-46e9-8f8d-6c65ac369468",
	"7576d5e0-2683-4a42-967a-ddb25a458620",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("5c3a02de-f488-46e9-8f8d-6c65ac369468",
	'get_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("f71605cd-7d55-45ec-8202-f53756d03a9a",
	"5c3a02de-f488-46e9-8f8d-6c65ac369468");
INSERT INTO ACT_ACT
	VALUES ("f71605cd-7d55-45ec-8202-f53756d03a9a",
	'interface operation',
	0,
	"a1bd1b48-e490-434d-b7b7-43fae148e4d8",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::get_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a1bd1b48-e490-434d-b7b7-43fae148e4d8",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"f71605cd-7d55-45ec-8202-f53756d03a9a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("c5523a0f-b436-48b9-a89f-15e0267e2379",
	"e2e61698-b9dc-4911-95c7-79872095f0dd",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("c5523a0f-b436-48b9-a89f-15e0267e2379",
	'ready',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("ec60b5b9-e63b-4f27-adf1-96adc230cf14",
	"c5523a0f-b436-48b9-a89f-15e0267e2379");
INSERT INTO ACT_ACT
	VALUES ("ec60b5b9-e63b-4f27-adf1-96adc230cf14",
	'interface operation',
	0,
	"d2085ae1-3afa-4a1e-8dbe-3a8b0c949729",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d2085ae1-3afa-4a1e-8dbe-3a8b0c949729",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ec60b5b9-e63b-4f27-adf1-96adc230cf14",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	1,
	"d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"00000000-0000-0000-0000-000000000000",
	2);
INSERT INTO C_C
	VALUES ("0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'Control',
	'',
	0,
	"00000000-0000-0000-0000-000000000000",
	0,
	'');
INSERT INTO C_PO
	VALUES ("bada52a0-1256-430d-8579-634b9c323fea",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	'Port1',
	0,
	0);
INSERT INTO C_IR
	VALUES ("33610dbc-6887-421d-81c6-740629675b3d",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	"bada52a0-1256-430d-8579-634b9c323fea");
INSERT INTO C_R
	VALUES ("33610dbc-6887-421d-81c6-740629675b3d",
	'mavcontrol',
	'',
	'Unnamed Interface',
	'Control::Port1::mavcontrol');
INSERT INTO SPR_REP
	VALUES ("e84f3860-934a-4425-83e4-2c5983065d6e",
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("e84f3860-934a-4425-83e4-2c5983065d6e",
	'init',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("a08c552f-5211-4637-b3ae-70c258e9de94",
	"e84f3860-934a-4425-83e4-2c5983065d6e");
INSERT INTO ACT_ACT
	VALUES ("a08c552f-5211-4637-b3ae-70c258e9de94",
	'interface operation',
	0,
	"c4e639fc-3393-4a07-be38-c10636520ace",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c4e639fc-3393-4a07-be38-c10636520ace",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a08c552f-5211-4637-b3ae-70c258e9de94",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("786f401b-dc06-4f89-95d6-805158b17282",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("786f401b-dc06-4f89-95d6-805158b17282",
	'takeoff',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("5a994679-5229-46d2-b06c-f6f24cc5b2fc",
	"786f401b-dc06-4f89-95d6-805158b17282");
INSERT INTO ACT_ACT
	VALUES ("5a994679-5229-46d2-b06c-f6f24cc5b2fc",
	'interface operation',
	0,
	"b0bdbf85-e0fa-41e9-aa98-ff923e1c7aef",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::takeoff',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b0bdbf85-e0fa-41e9-aa98-ff923e1c7aef",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5a994679-5229-46d2-b06c-f6f24cc5b2fc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("ea4468fa-4b20-4012-8e54-d298c549ee90",
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("ea4468fa-4b20-4012-8e54-d298c549ee90",
	'land',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("23417c58-5f90-4169-80c4-d423612188f5",
	"ea4468fa-4b20-4012-8e54-d298c549ee90");
INSERT INTO ACT_ACT
	VALUES ("23417c58-5f90-4169-80c4-d423612188f5",
	'interface operation',
	0,
	"8560435d-b1f7-4e7f-a35b-c0bb77f66ef6",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8560435d-b1f7-4e7f-a35b-c0bb77f66ef6",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"23417c58-5f90-4169-80c4-d423612188f5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("94117eda-9f0d-4f5e-af02-0148334dd3a9",
	"c53d4966-9097-4e62-8e45-bb3b7522378a",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("94117eda-9f0d-4f5e-af02-0148334dd3a9",
	'arm',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("c9ede7d3-303c-4dbb-9fcd-cf17d9ae50a9",
	"94117eda-9f0d-4f5e-af02-0148334dd3a9");
INSERT INTO ACT_ACT
	VALUES ("c9ede7d3-303c-4dbb-9fcd-cf17d9ae50a9",
	'interface operation',
	0,
	"53ea808f-34a2-4c91-aac0-844fceaf2bb0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::arm',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("53ea808f-34a2-4c91-aac0-844fceaf2bb0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c9ede7d3-303c-4dbb-9fcd-cf17d9ae50a9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("0b7b0648-980a-4657-9783-453131e6af11",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("0b7b0648-980a-4657-9783-453131e6af11",
	'set_destination',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("6c90318f-5691-4ecf-a283-b2e398084d0b",
	"0b7b0648-980a-4657-9783-453131e6af11");
INSERT INTO ACT_ACT
	VALUES ("6c90318f-5691-4ecf-a283-b2e398084d0b",
	'interface operation',
	0,
	"812b8f60-a7e8-4b3b-a8ca-f6a56fefb864",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_destination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("812b8f60-a7e8-4b3b-a8ca-f6a56fefb864",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6c90318f-5691-4ecf-a283-b2e398084d0b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("55afac66-d149-4d24-9466-0c4a6f48dcf5",
	'set_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("130cf696-ae7e-4c86-aa77-0d5d92830e80",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5");
INSERT INTO ACT_ACT
	VALUES ("130cf696-ae7e-4c86-aa77-0d5d92830e80",
	'interface operation',
	0,
	"9ffd78b5-d820-480f-bf33-bf78bdcecc4e",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("9ffd78b5-d820-480f-bf33-bf78bdcecc4e",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"130cf696-ae7e-4c86-aa77-0d5d92830e80",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("d3b00f4a-2ff0-4200-9566-b7eba7d85c94",
	"7576d5e0-2683-4a42-967a-ddb25a458620",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("d3b00f4a-2ff0-4200-9566-b7eba7d85c94",
	'get_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("e545d33d-02cb-4da3-a11d-debbefd29cdd",
	"d3b00f4a-2ff0-4200-9566-b7eba7d85c94");
INSERT INTO ACT_ACT
	VALUES ("e545d33d-02cb-4da3-a11d-debbefd29cdd",
	'interface operation',
	0,
	"95751502-e182-45b8-bd5f-b5d9097b2a55",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::get_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("95751502-e182-45b8-bd5f-b5d9097b2a55",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e545d33d-02cb-4da3-a11d-debbefd29cdd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("f864983a-f5f2-4a40-ae2f-8dbaf0842d15",
	"e2e61698-b9dc-4911-95c7-79872095f0dd",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("f864983a-f5f2-4a40-ae2f-8dbaf0842d15",
	'ready',
	'',
	'select any ctrl from Controller;
generate Controller2:''ready'' to ctrl;
',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("46c9d8ab-17eb-46a8-ba48-8fee65596872",
	"f864983a-f5f2-4a40-ae2f-8dbaf0842d15");
INSERT INTO ACT_ACT
	VALUES ("46c9d8ab-17eb-46a8-ba48-8fee65596872",
	'interface operation',
	0,
	"e8088605-cebc-4bab-abf1-1e7dc8c2a6e3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e8088605-cebc-4bab-abf1-1e7dc8c2a6e3",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	22,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"46c9d8ab-17eb-46a8-ba48-8fee65596872",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e8bd8c16-75b9-419e-bf0d-9311f5cb0f8f",
	"e8088605-cebc-4bab-abf1-1e7dc8c2a6e3",
	"cc7ea2c4-0d12-4e33-8596-c65eeb249b5d",
	1,
	1,
	'Port1::mavcontrol::ready line: 1');
INSERT INTO ACT_FIO
	VALUES ("e8bd8c16-75b9-419e-bf0d-9311f5cb0f8f",
	"9da73989-744c-454d-9d87-d9ba0a5dacfd",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	22);
INSERT INTO ACT_SMT
	VALUES ("cc7ea2c4-0d12-4e33-8596-c65eeb249b5d",
	"e8088605-cebc-4bab-abf1-1e7dc8c2a6e3",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Port1::mavcontrol::ready line: 2');
INSERT INTO E_ESS
	VALUES ("cc7ea2c4-0d12-4e33-8596-c65eeb249b5d",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	22,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("cc7ea2c4-0d12-4e33-8596-c65eeb249b5d");
INSERT INTO E_GSME
	VALUES ("cc7ea2c4-0d12-4e33-8596-c65eeb249b5d",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c");
INSERT INTO E_GEN
	VALUES ("cc7ea2c4-0d12-4e33-8596-c65eeb249b5d",
	"9da73989-744c-454d-9d87-d9ba0a5dacfd");
INSERT INTO V_VAR
	VALUES ("9da73989-744c-454d-9d87-d9ba0a5dacfd",
	"e8088605-cebc-4bab-abf1-1e7dc8c2a6e3",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("9da73989-744c-454d-9d87-d9ba0a5dacfd",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	1,
	"00000000-0000-0000-0000-000000000000",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	7);
INSERT INTO EP_PKG
	VALUES ("c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Functions',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("6da296e0-cfc3-41ea-b021-54b367d07943",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("6da296e0-cfc3-41ea-b021-54b367d07943",
	"00000000-0000-0000-0000-000000000000",
	'setup',
	'',
	'create object instance ctrl of Controller;
//generate Controller1:''start'' to ctrl;
create object instance wp1 of Waypoint;
wp1.x = 51;
wp1.y = 35;
wp1.z = 15;
relate ctrl to wp1 across R1.''begin with'';
relate ctrl to wp1 across R3.''is flying to'';

create object instance wp2 of Waypoint;
wp2.x = 131;
wp2.y = 35;
wp2.z = 15;
relate wp1 to wp2 across R2.''follows'';

create object instance wp3 of Waypoint;
wp3.x = 91;
wp3.y = 20;
wp3.z = 15;

relate wp2 to wp3 across R2.''follows'';

create object instance wp4 of Waypoint;
wp4.x = 51;
wp4.y = 20;
wp4.z = 15;

relate wp3 to wp4 across R2.''follows'';

create object instance wp5 of Waypoint;
wp5.x = 51;
wp5.y = 75;
wp5.z = 1;

relate wp4 to wp5 across R2.''follows'';

create object instance wp6 of Waypoint;
wp6.x = 151;
wp6.y = 75;
wp6.z = 1;

relate wp5 to wp6 across R2.''follows'';

create object instance wp7 of Waypoint;
wp7.x = 151;
wp7.y = 55;
wp7.z = 1;

relate wp6 to wp7 across R2.''follows'';

create object instance wp8 of Waypoint;
wp8.x = 111;
wp8.y = 55;
wp8.z = 1;

relate wp7 to wp8 across R2.''follows'';

create object instance wp9 of Waypoint;
wp9.x = 71;
wp9.y = 55;
wp9.z = 1;

relate wp8 to wp9 across R2.''follows'';

create object instance wp10 of Waypoint;
wp10.x = 0;
wp10.y = 0;
wp10.z = 1;

relate wp9 to wp10 across R2.''follows'';

create object instance wp11 of Waypoint;
wp10.x = 0;
wp10.y = 0;
wp10.z = 0;

relate wp10 to wp11 across R2.''follows'';













',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("f8dfa359-9bbe-48a1-ad2b-5fb294894708",
	"6da296e0-cfc3-41ea-b021-54b367d07943");
INSERT INTO ACT_ACT
	VALUES ("f8dfa359-9bbe-48a1-ad2b-5fb294894708",
	'function',
	0,
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6bb17639-15ff-4249-9520-ea925efce2fb",
	0,
	0,
	0,
	'''follows''',
	'',
	'',
	77,
	1,
	72,
	32,
	0,
	0,
	77,
	28,
	77,
	31,
	0,
	0,
	0,
	"f8dfa359-9bbe-48a1-ad2b-5fb294894708",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("eb594102-99d7-4860-aad1-e85b9ab59594",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"c4fb360f-5d6c-456b-8884-780bd22440ba",
	1,
	1,
	'setup line: 1');
INSERT INTO ACT_CR
	VALUES ("eb594102-99d7-4860-aad1-e85b9ab59594",
	"02b29c3d-ad34-4478-bf9a-fd7a86743471",
	1,
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	32);
INSERT INTO ACT_SMT
	VALUES ("c4fb360f-5d6c-456b-8884-780bd22440ba",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"25711c40-1056-443d-b690-b89530764dd0",
	3,
	1,
	'setup line: 3');
INSERT INTO ACT_CR
	VALUES ("c4fb360f-5d6c-456b-8884-780bd22440ba",
	"0043cb8a-529a-475e-a2e5-3d5516854b24",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	3,
	31);
INSERT INTO ACT_SMT
	VALUES ("25711c40-1056-443d-b690-b89530764dd0",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"42a51fd8-fcc9-4687-b35f-e690415ec49a",
	4,
	1,
	'setup line: 4');
INSERT INTO ACT_AI
	VALUES ("25711c40-1056-443d-b690-b89530764dd0",
	"99ae4fd2-1620-42f4-8a1f-33df8b499484",
	"0d3ee8df-2918-4870-ae12-faaa9171e733",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("42a51fd8-fcc9-4687-b35f-e690415ec49a",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"b798271e-4261-4e06-89cf-c63179cf89f4",
	5,
	1,
	'setup line: 5');
INSERT INTO ACT_AI
	VALUES ("42a51fd8-fcc9-4687-b35f-e690415ec49a",
	"b612c258-4c80-4dec-99b5-56adfe2f1ff3",
	"c5e1048a-9704-41c0-afab-f3c8148c2ccc",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b798271e-4261-4e06-89cf-c63179cf89f4",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"3a9e2117-9262-481f-a221-b29be151b673",
	6,
	1,
	'setup line: 6');
INSERT INTO ACT_AI
	VALUES ("b798271e-4261-4e06-89cf-c63179cf89f4",
	"237214d9-1eea-4e42-a9d8-0a4ce781a637",
	"1cb1d99e-a821-4929-b67a-448e61b029a9",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("3a9e2117-9262-481f-a221-b29be151b673",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"67013a9d-fe3e-4032-a2a9-a8c7faeb7022",
	7,
	1,
	'setup line: 7');
INSERT INTO ACT_REL
	VALUES ("3a9e2117-9262-481f-a221-b29be151b673",
	"02b29c3d-ad34-4478-bf9a-fd7a86743471",
	"0043cb8a-529a-475e-a2e5-3d5516854b24",
	'''begin with''',
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	7,
	27,
	7,
	30);
INSERT INTO ACT_SMT
	VALUES ("67013a9d-fe3e-4032-a2a9-a8c7faeb7022",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"74afd61a-c2eb-49be-a0a1-e6dc6bf7ef88",
	8,
	1,
	'setup line: 8');
INSERT INTO ACT_REL
	VALUES ("67013a9d-fe3e-4032-a2a9-a8c7faeb7022",
	"02b29c3d-ad34-4478-bf9a-fd7a86743471",
	"0043cb8a-529a-475e-a2e5-3d5516854b24",
	'''is flying to''',
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	8,
	27,
	8,
	30);
INSERT INTO ACT_SMT
	VALUES ("74afd61a-c2eb-49be-a0a1-e6dc6bf7ef88",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"23821597-b2c9-4986-9953-8368a6b751d0",
	10,
	1,
	'setup line: 10');
INSERT INTO ACT_CR
	VALUES ("74afd61a-c2eb-49be-a0a1-e6dc6bf7ef88",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	10,
	31);
INSERT INTO ACT_SMT
	VALUES ("23821597-b2c9-4986-9953-8368a6b751d0",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"372e1c59-9e15-451c-b562-45ebcd9874b7",
	11,
	1,
	'setup line: 11');
INSERT INTO ACT_AI
	VALUES ("23821597-b2c9-4986-9953-8368a6b751d0",
	"a5d985a4-4e99-453d-9cdd-ef9e35f3d643",
	"3e02bc5a-ad44-475a-b4be-6215400067b9",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("372e1c59-9e15-451c-b562-45ebcd9874b7",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"19185f58-690f-4478-bec5-11348fffc618",
	12,
	1,
	'setup line: 12');
INSERT INTO ACT_AI
	VALUES ("372e1c59-9e15-451c-b562-45ebcd9874b7",
	"2dcaab33-94b8-4d00-82cf-bf13faaa9fa6",
	"b0bff056-2aed-45fc-a70b-75d3bde0f740",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("19185f58-690f-4478-bec5-11348fffc618",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"c9aeafc5-1b06-48d9-95ba-4b419a78745e",
	13,
	1,
	'setup line: 13');
INSERT INTO ACT_AI
	VALUES ("19185f58-690f-4478-bec5-11348fffc618",
	"c5a89e2f-6423-40af-a5f5-b6ac2b59e311",
	"fb1fbec9-b15f-4350-b212-76f6e6c25fd8",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c9aeafc5-1b06-48d9-95ba-4b419a78745e",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"59eee740-7ac8-4953-b716-cd03cf068ca6",
	14,
	1,
	'setup line: 14');
INSERT INTO ACT_REL
	VALUES ("c9aeafc5-1b06-48d9-95ba-4b419a78745e",
	"0043cb8a-529a-475e-a2e5-3d5516854b24",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	14,
	26,
	14,
	29);
INSERT INTO ACT_SMT
	VALUES ("59eee740-7ac8-4953-b716-cd03cf068ca6",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"6f067dfe-e9c6-4caa-b7ed-5c4f4dd70c0e",
	16,
	1,
	'setup line: 16');
INSERT INTO ACT_CR
	VALUES ("59eee740-7ac8-4953-b716-cd03cf068ca6",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	16,
	31);
INSERT INTO ACT_SMT
	VALUES ("6f067dfe-e9c6-4caa-b7ed-5c4f4dd70c0e",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"823991ff-df92-41c7-aa38-6bbdb55a34d5",
	17,
	1,
	'setup line: 17');
INSERT INTO ACT_AI
	VALUES ("6f067dfe-e9c6-4caa-b7ed-5c4f4dd70c0e",
	"e683b015-e8bd-4e0d-adde-d13640e7db84",
	"a5cdff7c-7ba8-4746-95a6-b7f8c77f521f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("823991ff-df92-41c7-aa38-6bbdb55a34d5",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"af6ac2a0-38f8-417b-97f7-6366968355af",
	18,
	1,
	'setup line: 18');
INSERT INTO ACT_AI
	VALUES ("823991ff-df92-41c7-aa38-6bbdb55a34d5",
	"0676ba26-e39a-479a-99bd-5cba5cebd9a8",
	"b745d794-4189-4620-866a-6c0d15f0af65",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("af6ac2a0-38f8-417b-97f7-6366968355af",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"4524c818-296f-448f-89b2-fec497b7beb8",
	19,
	1,
	'setup line: 19');
INSERT INTO ACT_AI
	VALUES ("af6ac2a0-38f8-417b-97f7-6366968355af",
	"aa3c582e-73c2-4ddf-9384-1a34a7076ee5",
	"bef2af52-63b0-47e0-9c09-2ffc6332dbd9",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4524c818-296f-448f-89b2-fec497b7beb8",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"10c4ed0a-b22c-461a-a649-f388fd72d4b6",
	21,
	1,
	'setup line: 21');
INSERT INTO ACT_REL
	VALUES ("4524c818-296f-448f-89b2-fec497b7beb8",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	21,
	26,
	21,
	29);
INSERT INTO ACT_SMT
	VALUES ("10c4ed0a-b22c-461a-a649-f388fd72d4b6",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"dc1b834a-4726-400f-bb97-aa865f264c82",
	23,
	1,
	'setup line: 23');
INSERT INTO ACT_CR
	VALUES ("10c4ed0a-b22c-461a-a649-f388fd72d4b6",
	"1e666150-d8fd-44a8-beee-5d8e3438f651",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	23,
	31);
INSERT INTO ACT_SMT
	VALUES ("dc1b834a-4726-400f-bb97-aa865f264c82",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"ecdbcfcc-0be8-4365-9cf2-b3a475536454",
	24,
	1,
	'setup line: 24');
INSERT INTO ACT_AI
	VALUES ("dc1b834a-4726-400f-bb97-aa865f264c82",
	"9ff72840-c353-4333-bd63-5544a5e906e7",
	"9715576c-d1f6-4ac6-a806-2d90eb42f42d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ecdbcfcc-0be8-4365-9cf2-b3a475536454",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"cf743aab-85d8-4bd8-a78c-cbe0062f6f45",
	25,
	1,
	'setup line: 25');
INSERT INTO ACT_AI
	VALUES ("ecdbcfcc-0be8-4365-9cf2-b3a475536454",
	"958b44fd-7c35-4d13-bf41-1a9b6ea8b175",
	"4e8311d6-695f-4cbd-9b72-9c6189640c7a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("cf743aab-85d8-4bd8-a78c-cbe0062f6f45",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"7d7110b3-c09b-4128-a034-bd6c9b8e920e",
	26,
	1,
	'setup line: 26');
INSERT INTO ACT_AI
	VALUES ("cf743aab-85d8-4bd8-a78c-cbe0062f6f45",
	"677b4bae-960e-4eea-8050-1a855dc34b30",
	"b94013bd-2193-4a3d-89db-a6326988fd87",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7d7110b3-c09b-4128-a034-bd6c9b8e920e",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"4ffd8ba2-ecdc-4c08-aecf-14436c5118d7",
	28,
	1,
	'setup line: 28');
INSERT INTO ACT_REL
	VALUES ("7d7110b3-c09b-4128-a034-bd6c9b8e920e",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d",
	"1e666150-d8fd-44a8-beee-5d8e3438f651",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	28,
	26,
	28,
	29);
INSERT INTO ACT_SMT
	VALUES ("4ffd8ba2-ecdc-4c08-aecf-14436c5118d7",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"c10ed5ca-1e60-4e7c-b36b-b5e696614497",
	30,
	1,
	'setup line: 30');
INSERT INTO ACT_CR
	VALUES ("4ffd8ba2-ecdc-4c08-aecf-14436c5118d7",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	30,
	31);
INSERT INTO ACT_SMT
	VALUES ("c10ed5ca-1e60-4e7c-b36b-b5e696614497",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"0d5b0558-3d04-4a21-97af-f5f34144bea1",
	31,
	1,
	'setup line: 31');
INSERT INTO ACT_AI
	VALUES ("c10ed5ca-1e60-4e7c-b36b-b5e696614497",
	"b393a637-6ec6-4fa8-a1bc-1a3a141e83d6",
	"afc753c6-0920-40f2-b147-50be33e88e39",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0d5b0558-3d04-4a21-97af-f5f34144bea1",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"232175ca-3bbc-484c-9241-abed6827c055",
	32,
	1,
	'setup line: 32');
INSERT INTO ACT_AI
	VALUES ("0d5b0558-3d04-4a21-97af-f5f34144bea1",
	"9c5b6d7c-c0a7-4c0c-98d1-7ed26e760e25",
	"df1c585e-9a1e-4ee3-b37d-67122969860c",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("232175ca-3bbc-484c-9241-abed6827c055",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"35e367dc-d010-48af-b557-69824a5c46a1",
	33,
	1,
	'setup line: 33');
INSERT INTO ACT_AI
	VALUES ("232175ca-3bbc-484c-9241-abed6827c055",
	"cccf4521-b2f3-48ac-a7b0-264110d59fd4",
	"964859cc-1b63-40de-ad6f-119bf5adafd0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("35e367dc-d010-48af-b557-69824a5c46a1",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"aa17ebad-7807-44dc-8954-898c6caf38d4",
	35,
	1,
	'setup line: 35');
INSERT INTO ACT_REL
	VALUES ("35e367dc-d010-48af-b557-69824a5c46a1",
	"1e666150-d8fd-44a8-beee-5d8e3438f651",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	35,
	26,
	35,
	29);
INSERT INTO ACT_SMT
	VALUES ("aa17ebad-7807-44dc-8954-898c6caf38d4",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"d15051e4-239d-4af2-a35e-c6ef30a3e3d2",
	37,
	1,
	'setup line: 37');
INSERT INTO ACT_CR
	VALUES ("aa17ebad-7807-44dc-8954-898c6caf38d4",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	37,
	31);
INSERT INTO ACT_SMT
	VALUES ("d15051e4-239d-4af2-a35e-c6ef30a3e3d2",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"d58c9ad5-cbf8-4594-b430-b1ca8f7669da",
	38,
	1,
	'setup line: 38');
INSERT INTO ACT_AI
	VALUES ("d15051e4-239d-4af2-a35e-c6ef30a3e3d2",
	"09c5efa3-9c2b-4462-8978-a2937116f252",
	"5448137d-9642-4bc7-a341-b80027b8b439",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d58c9ad5-cbf8-4594-b430-b1ca8f7669da",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"92d9d8de-3812-4c0b-85cb-1b63b4d02e62",
	39,
	1,
	'setup line: 39');
INSERT INTO ACT_AI
	VALUES ("d58c9ad5-cbf8-4594-b430-b1ca8f7669da",
	"1657e1ca-2222-46d5-84e2-3621c4d1bc21",
	"2c7a6836-1311-4e9f-86b3-ddf512acd39f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("92d9d8de-3812-4c0b-85cb-1b63b4d02e62",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"80843244-80c0-4773-ad80-b07e36ae74fc",
	40,
	1,
	'setup line: 40');
INSERT INTO ACT_AI
	VALUES ("92d9d8de-3812-4c0b-85cb-1b63b4d02e62",
	"46e10b17-1d1e-4970-b385-47b20b649e41",
	"320e2df3-e2f2-4a36-8b59-2232076d1866",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("80843244-80c0-4773-ad80-b07e36ae74fc",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"aa88c305-088b-4716-bef2-7146722373df",
	42,
	1,
	'setup line: 42');
INSERT INTO ACT_REL
	VALUES ("80843244-80c0-4773-ad80-b07e36ae74fc",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	42,
	26,
	42,
	29);
INSERT INTO ACT_SMT
	VALUES ("aa88c305-088b-4716-bef2-7146722373df",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"75c6ff3e-436c-4317-8c69-f4788b537e9d",
	44,
	1,
	'setup line: 44');
INSERT INTO ACT_CR
	VALUES ("aa88c305-088b-4716-bef2-7146722373df",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	44,
	31);
INSERT INTO ACT_SMT
	VALUES ("75c6ff3e-436c-4317-8c69-f4788b537e9d",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"f52e6389-a415-4dda-9c8a-da6f275c39b5",
	45,
	1,
	'setup line: 45');
INSERT INTO ACT_AI
	VALUES ("75c6ff3e-436c-4317-8c69-f4788b537e9d",
	"78c71557-b90b-4fa2-977a-818118622811",
	"aee8ef1d-6736-4e27-8fb8-c60f7736a4d4",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f52e6389-a415-4dda-9c8a-da6f275c39b5",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"ea816a13-849f-4a3f-b069-b0bf2aba2d77",
	46,
	1,
	'setup line: 46');
INSERT INTO ACT_AI
	VALUES ("f52e6389-a415-4dda-9c8a-da6f275c39b5",
	"abbbfe58-e39a-4453-966a-c6e92a727406",
	"2647ed8b-18bb-4eb6-83ea-191780373fc2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ea816a13-849f-4a3f-b069-b0bf2aba2d77",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"f3a62edf-c31f-4986-9e88-c734b372b5ba",
	47,
	1,
	'setup line: 47');
INSERT INTO ACT_AI
	VALUES ("ea816a13-849f-4a3f-b069-b0bf2aba2d77",
	"84f668a4-1dbb-4f4f-8dc3-179293a5753e",
	"aa9d09b4-f704-4d58-8c06-5fac5d176d20",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f3a62edf-c31f-4986-9e88-c734b372b5ba",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"7af8b861-c487-4097-a037-e0834c78dbca",
	49,
	1,
	'setup line: 49');
INSERT INTO ACT_REL
	VALUES ("f3a62edf-c31f-4986-9e88-c734b372b5ba",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	49,
	26,
	49,
	29);
INSERT INTO ACT_SMT
	VALUES ("7af8b861-c487-4097-a037-e0834c78dbca",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"ad6ad49d-454f-4a13-9fbf-ed187785d80d",
	51,
	1,
	'setup line: 51');
INSERT INTO ACT_CR
	VALUES ("7af8b861-c487-4097-a037-e0834c78dbca",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	51,
	31);
INSERT INTO ACT_SMT
	VALUES ("ad6ad49d-454f-4a13-9fbf-ed187785d80d",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"d4422084-0f73-4b02-a85b-f701498384db",
	52,
	1,
	'setup line: 52');
INSERT INTO ACT_AI
	VALUES ("ad6ad49d-454f-4a13-9fbf-ed187785d80d",
	"a5afb07d-e2e6-4782-80f7-085466d8965a",
	"ee184c77-276f-445e-b738-ade2003389cb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d4422084-0f73-4b02-a85b-f701498384db",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"c1b4b7eb-c147-4e4e-93f4-3dd9f0642681",
	53,
	1,
	'setup line: 53');
INSERT INTO ACT_AI
	VALUES ("d4422084-0f73-4b02-a85b-f701498384db",
	"197c4212-b740-47ba-b78f-69da2fdc8c9f",
	"6d49e868-3330-4055-b1c7-02ec67de14af",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c1b4b7eb-c147-4e4e-93f4-3dd9f0642681",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"d5adae02-0347-428a-a5e2-b01a524b2a04",
	54,
	1,
	'setup line: 54');
INSERT INTO ACT_AI
	VALUES ("c1b4b7eb-c147-4e4e-93f4-3dd9f0642681",
	"b4f7be9b-4f62-4541-aa0d-e76d664e7e2c",
	"417c40d5-6f11-4e31-b85d-1119691f1f20",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("d5adae02-0347-428a-a5e2-b01a524b2a04",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"fb94cd3a-35b5-4acc-89c5-1cb35bbb5ea4",
	56,
	1,
	'setup line: 56');
INSERT INTO ACT_REL
	VALUES ("d5adae02-0347-428a-a5e2-b01a524b2a04",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	56,
	26,
	56,
	29);
INSERT INTO ACT_SMT
	VALUES ("fb94cd3a-35b5-4acc-89c5-1cb35bbb5ea4",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"dd3d7736-a643-4e7c-ab4c-c25ab0fba0a1",
	58,
	1,
	'setup line: 58');
INSERT INTO ACT_CR
	VALUES ("fb94cd3a-35b5-4acc-89c5-1cb35bbb5ea4",
	"405c09e2-f274-4024-bd98-ce9121dfda5f",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	58,
	31);
INSERT INTO ACT_SMT
	VALUES ("dd3d7736-a643-4e7c-ab4c-c25ab0fba0a1",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"184dacfc-bf43-4ff4-afba-e4003de8b794",
	59,
	1,
	'setup line: 59');
INSERT INTO ACT_AI
	VALUES ("dd3d7736-a643-4e7c-ab4c-c25ab0fba0a1",
	"151e6eda-8088-4609-b7e3-10a641c1ef2d",
	"08696475-e4a4-49be-829f-53b59a1f8da0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("184dacfc-bf43-4ff4-afba-e4003de8b794",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"0dcd7a16-12d8-4b6d-9695-82c249ed5d63",
	60,
	1,
	'setup line: 60');
INSERT INTO ACT_AI
	VALUES ("184dacfc-bf43-4ff4-afba-e4003de8b794",
	"ba014e02-ad1a-4922-953d-8609a42eaf0c",
	"1a67ae42-066c-4992-9198-021234179aae",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0dcd7a16-12d8-4b6d-9695-82c249ed5d63",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"0811e618-7c86-4b92-a3ca-d263937dc78c",
	61,
	1,
	'setup line: 61');
INSERT INTO ACT_AI
	VALUES ("0dcd7a16-12d8-4b6d-9695-82c249ed5d63",
	"cd942c23-0735-4673-a08b-02da5fe9423b",
	"7051209c-2f1d-4b31-95d4-63af00734c08",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0811e618-7c86-4b92-a3ca-d263937dc78c",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"b011d70f-f0e4-43f5-9fbb-b3ceb6fc916d",
	63,
	1,
	'setup line: 63');
INSERT INTO ACT_REL
	VALUES ("0811e618-7c86-4b92-a3ca-d263937dc78c",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9",
	"405c09e2-f274-4024-bd98-ce9121dfda5f",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	63,
	26,
	63,
	29);
INSERT INTO ACT_SMT
	VALUES ("b011d70f-f0e4-43f5-9fbb-b3ceb6fc916d",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"f8359c58-0d37-4c5f-bd77-971798f38c2f",
	65,
	1,
	'setup line: 65');
INSERT INTO ACT_CR
	VALUES ("b011d70f-f0e4-43f5-9fbb-b3ceb6fc916d",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	65,
	32);
INSERT INTO ACT_SMT
	VALUES ("f8359c58-0d37-4c5f-bd77-971798f38c2f",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"b59a7b25-e653-4122-85a8-0ced4af1d803",
	66,
	1,
	'setup line: 66');
INSERT INTO ACT_AI
	VALUES ("f8359c58-0d37-4c5f-bd77-971798f38c2f",
	"9961254f-c913-46ec-b8dd-26c7aa786c59",
	"da016fd7-ea44-4777-9880-e825bf6a00fd",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("b59a7b25-e653-4122-85a8-0ced4af1d803",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"68507c9b-1174-495c-b527-5b1b03cead7a",
	67,
	1,
	'setup line: 67');
INSERT INTO ACT_AI
	VALUES ("b59a7b25-e653-4122-85a8-0ced4af1d803",
	"a2348b4f-3fdc-4b1f-9877-d5009f0c75b7",
	"8193eec5-92de-478f-9482-ac61387dad04",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("68507c9b-1174-495c-b527-5b1b03cead7a",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"27007e07-841c-4850-829e-6b26c4215070",
	68,
	1,
	'setup line: 68');
INSERT INTO ACT_AI
	VALUES ("68507c9b-1174-495c-b527-5b1b03cead7a",
	"3c97b929-a361-4415-9108-e10d3097a8c3",
	"fa307e37-7b62-449e-88b7-90bcaea625e7",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("27007e07-841c-4850-829e-6b26c4215070",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"dc8288b3-f828-42c2-86ce-29c1e1e7c93b",
	70,
	1,
	'setup line: 70');
INSERT INTO ACT_REL
	VALUES ("27007e07-841c-4850-829e-6b26c4215070",
	"405c09e2-f274-4024-bd98-ce9121dfda5f",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	70,
	27,
	70,
	30);
INSERT INTO ACT_SMT
	VALUES ("dc8288b3-f828-42c2-86ce-29c1e1e7c93b",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"44932806-fc80-4aad-a1a2-6562ac9cdfbb",
	72,
	1,
	'setup line: 72');
INSERT INTO ACT_CR
	VALUES ("dc8288b3-f828-42c2-86ce-29c1e1e7c93b",
	"2778ac39-3a17-4232-bf2a-bcff085c1e2f",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	72,
	32);
INSERT INTO ACT_SMT
	VALUES ("44932806-fc80-4aad-a1a2-6562ac9cdfbb",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"e66e49e3-96c8-47b0-8ea5-360f7fca1244",
	73,
	1,
	'setup line: 73');
INSERT INTO ACT_AI
	VALUES ("44932806-fc80-4aad-a1a2-6562ac9cdfbb",
	"324d8a38-3240-4b45-8d6d-0ff133be6538",
	"9e270342-77a1-4152-ba26-c845854ad33a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e66e49e3-96c8-47b0-8ea5-360f7fca1244",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"a47709b5-f7e2-4557-8c28-9472460d17b0",
	74,
	1,
	'setup line: 74');
INSERT INTO ACT_AI
	VALUES ("e66e49e3-96c8-47b0-8ea5-360f7fca1244",
	"0325edad-6332-4474-aa5b-865ddaae9b0a",
	"48464143-a64f-46f3-9396-3a35c1cae5cb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a47709b5-f7e2-4557-8c28-9472460d17b0",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"c8e852e3-c578-4d7a-b681-b00d92585345",
	75,
	1,
	'setup line: 75');
INSERT INTO ACT_AI
	VALUES ("a47709b5-f7e2-4557-8c28-9472460d17b0",
	"a7df811e-1cab-4836-8292-2b2de9842d92",
	"679f1e6b-1366-48a0-968b-253d6816f6f5",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c8e852e3-c578-4d7a-b681-b00d92585345",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	"00000000-0000-0000-0000-000000000000",
	77,
	1,
	'setup line: 77');
INSERT INTO ACT_REL
	VALUES ("c8e852e3-c578-4d7a-b681-b00d92585345",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d",
	"2778ac39-3a17-4232-bf2a-bcff085c1e2f",
	'''follows''',
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	77,
	28,
	77,
	31);
INSERT INTO V_VAL
	VALUES ("2d341468-effe-4c1c-b3e9-7ab120c6aeb5",
	1,
	0,
	4,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("2d341468-effe-4c1c-b3e9-7ab120c6aeb5",
	"0043cb8a-529a-475e-a2e5-3d5516854b24");
INSERT INTO V_VAL
	VALUES ("0d3ee8df-2918-4870-ae12-faaa9171e733",
	1,
	0,
	4,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("0d3ee8df-2918-4870-ae12-faaa9171e733",
	"2d341468-effe-4c1c-b3e9-7ab120c6aeb5",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("99ae4fd2-1620-42f4-8a1f-33df8b499484",
	0,
	0,
	4,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("99ae4fd2-1620-42f4-8a1f-33df8b499484",
	'51');
INSERT INTO V_VAL
	VALUES ("2c345dee-8af5-4979-bca9-9a74aa5eb883",
	1,
	0,
	5,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("2c345dee-8af5-4979-bca9-9a74aa5eb883",
	"0043cb8a-529a-475e-a2e5-3d5516854b24");
INSERT INTO V_VAL
	VALUES ("c5e1048a-9704-41c0-afab-f3c8148c2ccc",
	1,
	0,
	5,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("c5e1048a-9704-41c0-afab-f3c8148c2ccc",
	"2c345dee-8af5-4979-bca9-9a74aa5eb883",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("b612c258-4c80-4dec-99b5-56adfe2f1ff3",
	0,
	0,
	5,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("b612c258-4c80-4dec-99b5-56adfe2f1ff3",
	'35');
INSERT INTO V_VAL
	VALUES ("537960ed-ee66-4bc1-bb5f-720d26373f51",
	1,
	0,
	6,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("537960ed-ee66-4bc1-bb5f-720d26373f51",
	"0043cb8a-529a-475e-a2e5-3d5516854b24");
INSERT INTO V_VAL
	VALUES ("1cb1d99e-a821-4929-b67a-448e61b029a9",
	1,
	0,
	6,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("1cb1d99e-a821-4929-b67a-448e61b029a9",
	"537960ed-ee66-4bc1-bb5f-720d26373f51",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("237214d9-1eea-4e42-a9d8-0a4ce781a637",
	0,
	0,
	6,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("237214d9-1eea-4e42-a9d8-0a4ce781a637",
	'15');
INSERT INTO V_VAL
	VALUES ("49b54e51-ae59-4ff0-96cd-fac631d63107",
	1,
	0,
	11,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("49b54e51-ae59-4ff0-96cd-fac631d63107",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7");
INSERT INTO V_VAL
	VALUES ("3e02bc5a-ad44-475a-b4be-6215400067b9",
	1,
	0,
	11,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("3e02bc5a-ad44-475a-b4be-6215400067b9",
	"49b54e51-ae59-4ff0-96cd-fac631d63107",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("a5d985a4-4e99-453d-9cdd-ef9e35f3d643",
	0,
	0,
	11,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("a5d985a4-4e99-453d-9cdd-ef9e35f3d643",
	'131');
INSERT INTO V_VAL
	VALUES ("e2d7667a-818d-4fa9-9745-9f555d3b5c09",
	1,
	0,
	12,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("e2d7667a-818d-4fa9-9745-9f555d3b5c09",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7");
INSERT INTO V_VAL
	VALUES ("b0bff056-2aed-45fc-a70b-75d3bde0f740",
	1,
	0,
	12,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("b0bff056-2aed-45fc-a70b-75d3bde0f740",
	"e2d7667a-818d-4fa9-9745-9f555d3b5c09",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("2dcaab33-94b8-4d00-82cf-bf13faaa9fa6",
	0,
	0,
	12,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("2dcaab33-94b8-4d00-82cf-bf13faaa9fa6",
	'35');
INSERT INTO V_VAL
	VALUES ("87565518-0697-44c9-b9a1-322839cb9395",
	1,
	0,
	13,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("87565518-0697-44c9-b9a1-322839cb9395",
	"af3e3276-0f8f-49db-87a4-a6d790f00db7");
INSERT INTO V_VAL
	VALUES ("fb1fbec9-b15f-4350-b212-76f6e6c25fd8",
	1,
	0,
	13,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("fb1fbec9-b15f-4350-b212-76f6e6c25fd8",
	"87565518-0697-44c9-b9a1-322839cb9395",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("c5a89e2f-6423-40af-a5f5-b6ac2b59e311",
	0,
	0,
	13,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("c5a89e2f-6423-40af-a5f5-b6ac2b59e311",
	'15');
INSERT INTO V_VAL
	VALUES ("54d410b0-fdc5-4b79-ab09-cb6a0f1dda54",
	1,
	0,
	17,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("54d410b0-fdc5-4b79-ab09-cb6a0f1dda54",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d");
INSERT INTO V_VAL
	VALUES ("a5cdff7c-7ba8-4746-95a6-b7f8c77f521f",
	1,
	0,
	17,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("a5cdff7c-7ba8-4746-95a6-b7f8c77f521f",
	"54d410b0-fdc5-4b79-ab09-cb6a0f1dda54",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("e683b015-e8bd-4e0d-adde-d13640e7db84",
	0,
	0,
	17,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("e683b015-e8bd-4e0d-adde-d13640e7db84",
	'91');
INSERT INTO V_VAL
	VALUES ("54d0fca7-4b87-49ea-a72c-497e73a0c2fb",
	1,
	0,
	18,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("54d0fca7-4b87-49ea-a72c-497e73a0c2fb",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d");
INSERT INTO V_VAL
	VALUES ("b745d794-4189-4620-866a-6c0d15f0af65",
	1,
	0,
	18,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("b745d794-4189-4620-866a-6c0d15f0af65",
	"54d0fca7-4b87-49ea-a72c-497e73a0c2fb",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("0676ba26-e39a-479a-99bd-5cba5cebd9a8",
	0,
	0,
	18,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("0676ba26-e39a-479a-99bd-5cba5cebd9a8",
	'20');
INSERT INTO V_VAL
	VALUES ("d75c6cd8-d196-4894-92cd-ab2fd61494b8",
	1,
	0,
	19,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("d75c6cd8-d196-4894-92cd-ab2fd61494b8",
	"c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d");
INSERT INTO V_VAL
	VALUES ("bef2af52-63b0-47e0-9c09-2ffc6332dbd9",
	1,
	0,
	19,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("bef2af52-63b0-47e0-9c09-2ffc6332dbd9",
	"d75c6cd8-d196-4894-92cd-ab2fd61494b8",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("aa3c582e-73c2-4ddf-9384-1a34a7076ee5",
	0,
	0,
	19,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("aa3c582e-73c2-4ddf-9384-1a34a7076ee5",
	'15');
INSERT INTO V_VAL
	VALUES ("61ccb5e4-567a-4f7c-ad4a-05bece7b3107",
	1,
	0,
	24,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("61ccb5e4-567a-4f7c-ad4a-05bece7b3107",
	"1e666150-d8fd-44a8-beee-5d8e3438f651");
INSERT INTO V_VAL
	VALUES ("9715576c-d1f6-4ac6-a806-2d90eb42f42d",
	1,
	0,
	24,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("9715576c-d1f6-4ac6-a806-2d90eb42f42d",
	"61ccb5e4-567a-4f7c-ad4a-05bece7b3107",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("9ff72840-c353-4333-bd63-5544a5e906e7",
	0,
	0,
	24,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("9ff72840-c353-4333-bd63-5544a5e906e7",
	'51');
INSERT INTO V_VAL
	VALUES ("eea0f9b9-53bd-46ae-aed9-1e0055dfaf24",
	1,
	0,
	25,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("eea0f9b9-53bd-46ae-aed9-1e0055dfaf24",
	"1e666150-d8fd-44a8-beee-5d8e3438f651");
INSERT INTO V_VAL
	VALUES ("4e8311d6-695f-4cbd-9b72-9c6189640c7a",
	1,
	0,
	25,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("4e8311d6-695f-4cbd-9b72-9c6189640c7a",
	"eea0f9b9-53bd-46ae-aed9-1e0055dfaf24",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("958b44fd-7c35-4d13-bf41-1a9b6ea8b175",
	0,
	0,
	25,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("958b44fd-7c35-4d13-bf41-1a9b6ea8b175",
	'20');
INSERT INTO V_VAL
	VALUES ("f6f7f2a6-6547-48d5-b826-1bfd9712cebe",
	1,
	0,
	26,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("f6f7f2a6-6547-48d5-b826-1bfd9712cebe",
	"1e666150-d8fd-44a8-beee-5d8e3438f651");
INSERT INTO V_VAL
	VALUES ("b94013bd-2193-4a3d-89db-a6326988fd87",
	1,
	0,
	26,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("b94013bd-2193-4a3d-89db-a6326988fd87",
	"f6f7f2a6-6547-48d5-b826-1bfd9712cebe",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("677b4bae-960e-4eea-8050-1a855dc34b30",
	0,
	0,
	26,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("677b4bae-960e-4eea-8050-1a855dc34b30",
	'15');
INSERT INTO V_VAL
	VALUES ("0b71785f-37f9-4c23-aebf-ac6ed3e9bb5f",
	1,
	0,
	31,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("0b71785f-37f9-4c23-aebf-ac6ed3e9bb5f",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055");
INSERT INTO V_VAL
	VALUES ("afc753c6-0920-40f2-b147-50be33e88e39",
	1,
	0,
	31,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("afc753c6-0920-40f2-b147-50be33e88e39",
	"0b71785f-37f9-4c23-aebf-ac6ed3e9bb5f",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("b393a637-6ec6-4fa8-a1bc-1a3a141e83d6",
	0,
	0,
	31,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("b393a637-6ec6-4fa8-a1bc-1a3a141e83d6",
	'51');
INSERT INTO V_VAL
	VALUES ("2c27d43c-20d7-4061-af63-d5684c1f3eb3",
	1,
	0,
	32,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("2c27d43c-20d7-4061-af63-d5684c1f3eb3",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055");
INSERT INTO V_VAL
	VALUES ("df1c585e-9a1e-4ee3-b37d-67122969860c",
	1,
	0,
	32,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("df1c585e-9a1e-4ee3-b37d-67122969860c",
	"2c27d43c-20d7-4061-af63-d5684c1f3eb3",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("9c5b6d7c-c0a7-4c0c-98d1-7ed26e760e25",
	0,
	0,
	32,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("9c5b6d7c-c0a7-4c0c-98d1-7ed26e760e25",
	'75');
INSERT INTO V_VAL
	VALUES ("8df89563-29fa-402c-afea-b0b6b5ed7c07",
	1,
	0,
	33,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("8df89563-29fa-402c-afea-b0b6b5ed7c07",
	"47a497cb-ad6e-4a10-a882-e9d92ca9c055");
INSERT INTO V_VAL
	VALUES ("964859cc-1b63-40de-ad6f-119bf5adafd0",
	1,
	0,
	33,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("964859cc-1b63-40de-ad6f-119bf5adafd0",
	"8df89563-29fa-402c-afea-b0b6b5ed7c07",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("cccf4521-b2f3-48ac-a7b0-264110d59fd4",
	0,
	0,
	33,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("cccf4521-b2f3-48ac-a7b0-264110d59fd4",
	'1');
INSERT INTO V_VAL
	VALUES ("8a9452ad-0a40-41de-b875-e28b975b6aef",
	1,
	0,
	38,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("8a9452ad-0a40-41de-b875-e28b975b6aef",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3");
INSERT INTO V_VAL
	VALUES ("5448137d-9642-4bc7-a341-b80027b8b439",
	1,
	0,
	38,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("5448137d-9642-4bc7-a341-b80027b8b439",
	"8a9452ad-0a40-41de-b875-e28b975b6aef",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("09c5efa3-9c2b-4462-8978-a2937116f252",
	0,
	0,
	38,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("09c5efa3-9c2b-4462-8978-a2937116f252",
	'151');
INSERT INTO V_VAL
	VALUES ("55c7d075-c7c6-419f-b11c-83cb47534d01",
	1,
	0,
	39,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("55c7d075-c7c6-419f-b11c-83cb47534d01",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3");
INSERT INTO V_VAL
	VALUES ("2c7a6836-1311-4e9f-86b3-ddf512acd39f",
	1,
	0,
	39,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("2c7a6836-1311-4e9f-86b3-ddf512acd39f",
	"55c7d075-c7c6-419f-b11c-83cb47534d01",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("1657e1ca-2222-46d5-84e2-3621c4d1bc21",
	0,
	0,
	39,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("1657e1ca-2222-46d5-84e2-3621c4d1bc21",
	'75');
INSERT INTO V_VAL
	VALUES ("5bd20278-e99f-4e96-98db-254c23abab89",
	1,
	0,
	40,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("5bd20278-e99f-4e96-98db-254c23abab89",
	"5d91ce52-2ce9-48e6-befe-ee953cb0f0c3");
INSERT INTO V_VAL
	VALUES ("320e2df3-e2f2-4a36-8b59-2232076d1866",
	1,
	0,
	40,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("320e2df3-e2f2-4a36-8b59-2232076d1866",
	"5bd20278-e99f-4e96-98db-254c23abab89",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("46e10b17-1d1e-4970-b385-47b20b649e41",
	0,
	0,
	40,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("46e10b17-1d1e-4970-b385-47b20b649e41",
	'1');
INSERT INTO V_VAL
	VALUES ("772f9d0d-e74c-47c5-a310-30f7f77cfd2c",
	1,
	0,
	45,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("772f9d0d-e74c-47c5-a310-30f7f77cfd2c",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da");
INSERT INTO V_VAL
	VALUES ("aee8ef1d-6736-4e27-8fb8-c60f7736a4d4",
	1,
	0,
	45,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("aee8ef1d-6736-4e27-8fb8-c60f7736a4d4",
	"772f9d0d-e74c-47c5-a310-30f7f77cfd2c",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("78c71557-b90b-4fa2-977a-818118622811",
	0,
	0,
	45,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("78c71557-b90b-4fa2-977a-818118622811",
	'151');
INSERT INTO V_VAL
	VALUES ("9c1fc634-5ebf-446c-96d8-e5adee8fb4fc",
	1,
	0,
	46,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("9c1fc634-5ebf-446c-96d8-e5adee8fb4fc",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da");
INSERT INTO V_VAL
	VALUES ("2647ed8b-18bb-4eb6-83ea-191780373fc2",
	1,
	0,
	46,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("2647ed8b-18bb-4eb6-83ea-191780373fc2",
	"9c1fc634-5ebf-446c-96d8-e5adee8fb4fc",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("abbbfe58-e39a-4453-966a-c6e92a727406",
	0,
	0,
	46,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("abbbfe58-e39a-4453-966a-c6e92a727406",
	'55');
INSERT INTO V_VAL
	VALUES ("70e29d04-a010-4e3a-93ff-a34037a28536",
	1,
	0,
	47,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("70e29d04-a010-4e3a-93ff-a34037a28536",
	"0a651079-74f1-40b2-87b3-e3a0a5d3f4da");
INSERT INTO V_VAL
	VALUES ("aa9d09b4-f704-4d58-8c06-5fac5d176d20",
	1,
	0,
	47,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("aa9d09b4-f704-4d58-8c06-5fac5d176d20",
	"70e29d04-a010-4e3a-93ff-a34037a28536",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("84f668a4-1dbb-4f4f-8dc3-179293a5753e",
	0,
	0,
	47,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("84f668a4-1dbb-4f4f-8dc3-179293a5753e",
	'1');
INSERT INTO V_VAL
	VALUES ("3774837c-443f-4096-a89c-48fe6c500c85",
	1,
	0,
	52,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("3774837c-443f-4096-a89c-48fe6c500c85",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9");
INSERT INTO V_VAL
	VALUES ("ee184c77-276f-445e-b738-ade2003389cb",
	1,
	0,
	52,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("ee184c77-276f-445e-b738-ade2003389cb",
	"3774837c-443f-4096-a89c-48fe6c500c85",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("a5afb07d-e2e6-4782-80f7-085466d8965a",
	0,
	0,
	52,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("a5afb07d-e2e6-4782-80f7-085466d8965a",
	'111');
INSERT INTO V_VAL
	VALUES ("b163940e-52ee-4d39-8379-2c60d10c2118",
	1,
	0,
	53,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("b163940e-52ee-4d39-8379-2c60d10c2118",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9");
INSERT INTO V_VAL
	VALUES ("6d49e868-3330-4055-b1c7-02ec67de14af",
	1,
	0,
	53,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("6d49e868-3330-4055-b1c7-02ec67de14af",
	"b163940e-52ee-4d39-8379-2c60d10c2118",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("197c4212-b740-47ba-b78f-69da2fdc8c9f",
	0,
	0,
	53,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("197c4212-b740-47ba-b78f-69da2fdc8c9f",
	'55');
INSERT INTO V_VAL
	VALUES ("0c57bc84-18ac-49ec-a57e-ca51b275bb58",
	1,
	0,
	54,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("0c57bc84-18ac-49ec-a57e-ca51b275bb58",
	"941f2a58-ff5b-4bd7-8c00-6adff0141be9");
INSERT INTO V_VAL
	VALUES ("417c40d5-6f11-4e31-b85d-1119691f1f20",
	1,
	0,
	54,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("417c40d5-6f11-4e31-b85d-1119691f1f20",
	"0c57bc84-18ac-49ec-a57e-ca51b275bb58",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("b4f7be9b-4f62-4541-aa0d-e76d664e7e2c",
	0,
	0,
	54,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("b4f7be9b-4f62-4541-aa0d-e76d664e7e2c",
	'1');
INSERT INTO V_VAL
	VALUES ("f8897b02-8480-4861-bf34-9b1a9545390d",
	1,
	0,
	59,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("f8897b02-8480-4861-bf34-9b1a9545390d",
	"405c09e2-f274-4024-bd98-ce9121dfda5f");
INSERT INTO V_VAL
	VALUES ("08696475-e4a4-49be-829f-53b59a1f8da0",
	1,
	0,
	59,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("08696475-e4a4-49be-829f-53b59a1f8da0",
	"f8897b02-8480-4861-bf34-9b1a9545390d",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("151e6eda-8088-4609-b7e3-10a641c1ef2d",
	0,
	0,
	59,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("151e6eda-8088-4609-b7e3-10a641c1ef2d",
	'71');
INSERT INTO V_VAL
	VALUES ("f4ce55cc-2354-4fcd-9be4-d710f63103e9",
	1,
	0,
	60,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("f4ce55cc-2354-4fcd-9be4-d710f63103e9",
	"405c09e2-f274-4024-bd98-ce9121dfda5f");
INSERT INTO V_VAL
	VALUES ("1a67ae42-066c-4992-9198-021234179aae",
	1,
	0,
	60,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("1a67ae42-066c-4992-9198-021234179aae",
	"f4ce55cc-2354-4fcd-9be4-d710f63103e9",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("ba014e02-ad1a-4922-953d-8609a42eaf0c",
	0,
	0,
	60,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("ba014e02-ad1a-4922-953d-8609a42eaf0c",
	'55');
INSERT INTO V_VAL
	VALUES ("7ee6ed05-f671-4a9a-9c8f-755ac46e4e1e",
	1,
	0,
	61,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("7ee6ed05-f671-4a9a-9c8f-755ac46e4e1e",
	"405c09e2-f274-4024-bd98-ce9121dfda5f");
INSERT INTO V_VAL
	VALUES ("7051209c-2f1d-4b31-95d4-63af00734c08",
	1,
	0,
	61,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("7051209c-2f1d-4b31-95d4-63af00734c08",
	"7ee6ed05-f671-4a9a-9c8f-755ac46e4e1e",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("cd942c23-0735-4673-a08b-02da5fe9423b",
	0,
	0,
	61,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("cd942c23-0735-4673-a08b-02da5fe9423b",
	'1');
INSERT INTO V_VAL
	VALUES ("07074443-ca65-4204-b1a2-49a4d1b38ce2",
	1,
	0,
	66,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("07074443-ca65-4204-b1a2-49a4d1b38ce2",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("da016fd7-ea44-4777-9880-e825bf6a00fd",
	1,
	0,
	66,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("da016fd7-ea44-4777-9880-e825bf6a00fd",
	"07074443-ca65-4204-b1a2-49a4d1b38ce2",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("9961254f-c913-46ec-b8dd-26c7aa786c59",
	0,
	0,
	66,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("9961254f-c913-46ec-b8dd-26c7aa786c59",
	'0');
INSERT INTO V_VAL
	VALUES ("f852eba0-6635-48d2-93a9-4b5d99f5c6aa",
	1,
	0,
	67,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("f852eba0-6635-48d2-93a9-4b5d99f5c6aa",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("8193eec5-92de-478f-9482-ac61387dad04",
	1,
	0,
	67,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("8193eec5-92de-478f-9482-ac61387dad04",
	"f852eba0-6635-48d2-93a9-4b5d99f5c6aa",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("a2348b4f-3fdc-4b1f-9877-d5009f0c75b7",
	0,
	0,
	67,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("a2348b4f-3fdc-4b1f-9877-d5009f0c75b7",
	'0');
INSERT INTO V_VAL
	VALUES ("ae9e2cc7-2edb-47b5-8e4b-396e1ce5506c",
	1,
	0,
	68,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("ae9e2cc7-2edb-47b5-8e4b-396e1ce5506c",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("fa307e37-7b62-449e-88b7-90bcaea625e7",
	1,
	0,
	68,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("fa307e37-7b62-449e-88b7-90bcaea625e7",
	"ae9e2cc7-2edb-47b5-8e4b-396e1ce5506c",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("3c97b929-a361-4415-9108-e10d3097a8c3",
	0,
	0,
	68,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("3c97b929-a361-4415-9108-e10d3097a8c3",
	'1');
INSERT INTO V_VAL
	VALUES ("d8820f61-f0de-4e0a-af3c-8502d6950bdd",
	1,
	0,
	73,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("d8820f61-f0de-4e0a-af3c-8502d6950bdd",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("9e270342-77a1-4152-ba26-c845854ad33a",
	1,
	0,
	73,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("9e270342-77a1-4152-ba26-c845854ad33a",
	"d8820f61-f0de-4e0a-af3c-8502d6950bdd",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_VAL
	VALUES ("324d8a38-3240-4b45-8d6d-0ff133be6538",
	0,
	0,
	73,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("324d8a38-3240-4b45-8d6d-0ff133be6538",
	'0');
INSERT INTO V_VAL
	VALUES ("fcb6b74c-f209-49cd-b8f5-ca1465023e6b",
	1,
	0,
	74,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("fcb6b74c-f209-49cd-b8f5-ca1465023e6b",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("48464143-a64f-46f3-9396-3a35c1cae5cb",
	1,
	0,
	74,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("48464143-a64f-46f3-9396-3a35c1cae5cb",
	"fcb6b74c-f209-49cd-b8f5-ca1465023e6b",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_VAL
	VALUES ("0325edad-6332-4474-aa5b-865ddaae9b0a",
	0,
	0,
	74,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("0325edad-6332-4474-aa5b-865ddaae9b0a",
	'0');
INSERT INTO V_VAL
	VALUES ("41446059-aafa-4487-bd75-69c9e86f80dc",
	1,
	0,
	75,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_IRF
	VALUES ("41446059-aafa-4487-bd75-69c9e86f80dc",
	"dc309bc6-c368-440d-84a8-d30ae0112f0d");
INSERT INTO V_VAL
	VALUES ("679f1e6b-1366-48a0-968b-253d6816f6f5",
	1,
	0,
	75,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_AVL
	VALUES ("679f1e6b-1366-48a0-968b-253d6816f6f5",
	"41446059-aafa-4487-bd75-69c9e86f80dc",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_VAL
	VALUES ("a7df811e-1cab-4836-8292-2b2de9842d92",
	0,
	0,
	75,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"6bb17639-15ff-4249-9520-ea925efce2fb");
INSERT INTO V_LIN
	VALUES ("a7df811e-1cab-4836-8292-2b2de9842d92",
	'0');
INSERT INTO V_VAR
	VALUES ("02b29c3d-ad34-4478-bf9a-fd7a86743471",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("02b29c3d-ad34-4478-bf9a-fd7a86743471",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO V_VAR
	VALUES ("0043cb8a-529a-475e-a2e5-3d5516854b24",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp1',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("0043cb8a-529a-475e-a2e5-3d5516854b24",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("af3e3276-0f8f-49db-87a4-a6d790f00db7",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp2',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("af3e3276-0f8f-49db-87a4-a6d790f00db7",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp3',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("c7e55e9c-0fa2-4ec3-9198-5f8b9ec7b37d",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("1e666150-d8fd-44a8-beee-5d8e3438f651",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp4',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("1e666150-d8fd-44a8-beee-5d8e3438f651",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("47a497cb-ad6e-4a10-a882-e9d92ca9c055",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp5',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("47a497cb-ad6e-4a10-a882-e9d92ca9c055",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("5d91ce52-2ce9-48e6-befe-ee953cb0f0c3",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp6',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("5d91ce52-2ce9-48e6-befe-ee953cb0f0c3",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("0a651079-74f1-40b2-87b3-e3a0a5d3f4da",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp7',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("0a651079-74f1-40b2-87b3-e3a0a5d3f4da",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("941f2a58-ff5b-4bd7-8c00-6adff0141be9",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp8',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("941f2a58-ff5b-4bd7-8c00-6adff0141be9",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("405c09e2-f274-4024-bd98-ce9121dfda5f",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp9',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("405c09e2-f274-4024-bd98-ce9121dfda5f",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("dc309bc6-c368-440d-84a8-d30ae0112f0d",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp10',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("dc309bc6-c368-440d-84a8-d30ae0112f0d",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("2778ac39-3a17-4232-bf2a-bcff085c1e2f",
	"6bb17639-15ff-4249-9520-ea925efce2fb",
	'wp11',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("2778ac39-3a17-4232-bf2a-bcff085c1e2f",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO PE_PE
	VALUES ("38931f73-250d-4b4f-8a21-e92c869db61a",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("38931f73-250d-4b4f-8a21-e92c869db61a",
	"00000000-0000-0000-0000-000000000000",
	'halt',
	'',
	'select any ctrl from instances of Controller;
generate Controller3:''halt'' to ctrl;
',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("9b727157-18ad-4d11-8c14-fa5923b8ebb4",
	"38931f73-250d-4b4f-8a21-e92c869db61a");
INSERT INTO ACT_ACT
	VALUES ("9b727157-18ad-4d11-8c14-fa5923b8ebb4",
	'function',
	0,
	"daf8d419-3923-4cfc-84c0-ab7e32bbfd7f",
	"00000000-0000-0000-0000-000000000000",
	0,
	'halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("daf8d419-3923-4cfc-84c0-ab7e32bbfd7f",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9b727157-18ad-4d11-8c14-fa5923b8ebb4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("60921054-10f9-4dd9-a5d0-1027d0db606b",
	"daf8d419-3923-4cfc-84c0-ab7e32bbfd7f",
	"425dc262-2de6-459a-ab5b-9808f1270f7a",
	1,
	1,
	'halt line: 1');
INSERT INTO ACT_FIO
	VALUES ("60921054-10f9-4dd9-a5d0-1027d0db606b",
	"0de02524-2702-4371-8fda-4f274b23b11b",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("425dc262-2de6-459a-ab5b-9808f1270f7a",
	"daf8d419-3923-4cfc-84c0-ab7e32bbfd7f",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'halt line: 2');
INSERT INTO E_ESS
	VALUES ("425dc262-2de6-459a-ab5b-9808f1270f7a",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	35,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("425dc262-2de6-459a-ab5b-9808f1270f7a");
INSERT INTO E_GSME
	VALUES ("425dc262-2de6-459a-ab5b-9808f1270f7a",
	"8b378763-7c1f-451d-b66d-3561c7f51373");
INSERT INTO E_GEN
	VALUES ("425dc262-2de6-459a-ab5b-9808f1270f7a",
	"0de02524-2702-4371-8fda-4f274b23b11b");
INSERT INTO V_VAR
	VALUES ("0de02524-2702-4371-8fda-4f274b23b11b",
	"daf8d419-3923-4cfc-84c0-ab7e32bbfd7f",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("0de02524-2702-4371-8fda-4f274b23b11b",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("faabd705-b6ee-4295-9cdd-82784a4bdae9",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("faabd705-b6ee-4295-9cdd-82784a4bdae9",
	"00000000-0000-0000-0000-000000000000",
	'start',
	'',
	'select any ctrl from instances of Controller;
generate Controller1:''start'' to ctrl;',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("8ef8bc4d-1bfc-4384-8ca7-cc65cf1aa6af",
	"faabd705-b6ee-4295-9cdd-82784a4bdae9");
INSERT INTO ACT_ACT
	VALUES ("8ef8bc4d-1bfc-4384-8ca7-cc65cf1aa6af",
	'function',
	0,
	"ad67630b-5f0b-4ff7-9b2c-d166de6c8b97",
	"00000000-0000-0000-0000-000000000000",
	0,
	'start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ad67630b-5f0b-4ff7-9b2c-d166de6c8b97",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8ef8bc4d-1bfc-4384-8ca7-cc65cf1aa6af",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("69a5fb8b-441f-4be4-8d72-3bfebfa093dc",
	"ad67630b-5f0b-4ff7-9b2c-d166de6c8b97",
	"9384b219-f1d2-487a-afca-3471aab2c82b",
	1,
	1,
	'start line: 1');
INSERT INTO ACT_FIO
	VALUES ("69a5fb8b-441f-4be4-8d72-3bfebfa093dc",
	"7c12d90e-2025-4159-9dd6-f7650336aeb9",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("9384b219-f1d2-487a-afca-3471aab2c82b",
	"ad67630b-5f0b-4ff7-9b2c-d166de6c8b97",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'start line: 2');
INSERT INTO E_ESS
	VALUES ("9384b219-f1d2-487a-afca-3471aab2c82b",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	35,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("9384b219-f1d2-487a-afca-3471aab2c82b");
INSERT INTO E_GSME
	VALUES ("9384b219-f1d2-487a-afca-3471aab2c82b",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5");
INSERT INTO E_GEN
	VALUES ("9384b219-f1d2-487a-afca-3471aab2c82b",
	"7c12d90e-2025-4159-9dd6-f7650336aeb9");
INSERT INTO V_VAR
	VALUES ("7c12d90e-2025-4159-9dd6-f7650336aeb9",
	"ad67630b-5f0b-4ff7-9b2c-d166de6c8b97",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("7c12d90e-2025-4159-9dd6-f7650336aeb9",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	1,
	"00000000-0000-0000-0000-000000000000",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	7);
INSERT INTO EP_PKG
	VALUES ("c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Control',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	4);
INSERT INTO O_OBJ
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	'Controller',
	1,
	'Controller',
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_NBATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_BATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	"00000000-0000-0000-0000-000000000000",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ba5eda7a-def5-0000-0000-000000000006",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ID
	VALUES (1,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ID
	VALUES (2,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO SM_ISM
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO SM_SM
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_LEVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	1,
	'start',
	0,
	'',
	'Controller1',
	'');
INSERT INTO SM_LEVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	2,
	'ready',
	0,
	'',
	'Controller2',
	'');
INSERT INTO SM_LEVT
	VALUES ("8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	3,
	'halt',
	0,
	'',
	'Controller3',
	'');
INSERT INTO SM_STATE
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'init',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("d0d2d3c5-55f7-4222-965d-b9758d968063",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8");
INSERT INTO SM_AH
	VALUES ("d0d2d3c5-55f7-4222-965d-b9758d968063",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("d0d2d3c5-55f7-4222-965d-b9758d968063",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("ff975b34-de97-492c-a2c3-66ace83c2526",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"d0d2d3c5-55f7-4222-965d-b9758d968063");
INSERT INTO ACT_ACT
	VALUES ("ff975b34-de97-492c-a2c3-66ace83c2526",
	'state',
	0,
	"bc488575-97b0-403e-a3d4-1b78813d6e3d",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("bc488575-97b0-403e-a3d4-1b78813d6e3d",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ff975b34-de97-492c-a2c3-66ace83c2526",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_STATE
	VALUES ("b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'take off',
	2,
	0);
INSERT INTO SM_CH
	VALUES ("b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("41431243-103a-4a6f-8403-1f52ffcb092f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"b96ba372-9a31-430f-b0a5-74a1d02169e3");
INSERT INTO SM_AH
	VALUES ("41431243-103a-4a6f-8403-1f52ffcb092f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("41431243-103a-4a6f-8403-1f52ffcb092f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'Port1::takeoff( alt:15);
Port1::set_heading( heading:0 );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("51120294-8850-4a1b-84d7-d8befc87e1e3",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"41431243-103a-4a6f-8403-1f52ffcb092f");
INSERT INTO ACT_ACT
	VALUES ("51120294-8850-4a1b-84d7-d8befc87e1e3",
	'state',
	0,
	"ef93836e-40a6-408e-9ae8-47df6ddc7ffc",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::take off',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ef93836e-40a6-408e-9ae8-47df6ddc7ffc",
	0,
	0,
	0,
	'Port1',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"51120294-8850-4a1b-84d7-d8befc87e1e3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("cec38063-9ace-46a7-89e5-1623074c383d",
	"ef93836e-40a6-408e-9ae8-47df6ddc7ffc",
	"280e076e-4816-4101-b8c1-7eb48aef2a78",
	1,
	1,
	'Controller::take off line: 1');
INSERT INTO ACT_IOP
	VALUES ("cec38063-9ace-46a7-89e5-1623074c383d",
	1,
	8,
	1,
	1,
	"00000000-0000-0000-0000-000000000000",
	"786f401b-dc06-4f89-95d6-805158b17282",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("280e076e-4816-4101-b8c1-7eb48aef2a78",
	"ef93836e-40a6-408e-9ae8-47df6ddc7ffc",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Controller::take off line: 2');
INSERT INTO ACT_IOP
	VALUES ("280e076e-4816-4101-b8c1-7eb48aef2a78",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("8a4545d4-eafe-4cef-b84b-5c4fc55a58e7",
	0,
	0,
	1,
	21,
	22,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"ef93836e-40a6-408e-9ae8-47df6ddc7ffc");
INSERT INTO V_LIN
	VALUES ("8a4545d4-eafe-4cef-b84b-5c4fc55a58e7",
	'15');
INSERT INTO V_PAR
	VALUES ("8a4545d4-eafe-4cef-b84b-5c4fc55a58e7",
	"cec38063-9ace-46a7-89e5-1623074c383d",
	"00000000-0000-0000-0000-000000000000",
	'alt',
	"00000000-0000-0000-0000-000000000000",
	1,
	17);
INSERT INTO V_VAL
	VALUES ("9178c06a-ddfe-4958-9a52-1e332445355a",
	0,
	0,
	2,
	29,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"ef93836e-40a6-408e-9ae8-47df6ddc7ffc");
INSERT INTO V_LIN
	VALUES ("9178c06a-ddfe-4958-9a52-1e332445355a",
	'0');
INSERT INTO V_PAR
	VALUES ("9178c06a-ddfe-4958-9a52-1e332445355a",
	"280e076e-4816-4101-b8c1-7eb48aef2a78",
	"00000000-0000-0000-0000-000000000000",
	'heading',
	"00000000-0000-0000-0000-000000000000",
	2,
	21);
INSERT INTO SM_STATE
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'land',
	3,
	0);
INSERT INTO SM_CH
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("3498a029-f4cf-4635-84ec-62909b4b5d88",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("4feb8c2f-ba0b-4cc1-a509-8eca5cc63baf",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"3498a029-f4cf-4635-84ec-62909b4b5d88");
INSERT INTO SM_AH
	VALUES ("4feb8c2f-ba0b-4cc1-a509-8eca5cc63baf",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("4feb8c2f-ba0b-4cc1-a509-8eca5cc63baf",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'Port1::land();
Port1::set_heading( heading:0 );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("9737d726-f374-4974-a946-0114fd162db5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"4feb8c2f-ba0b-4cc1-a509-8eca5cc63baf");
INSERT INTO ACT_ACT
	VALUES ("9737d726-f374-4974-a946-0114fd162db5",
	'state',
	0,
	"321722d1-52f1-4cfd-8df2-2721626975ce",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("321722d1-52f1-4cfd-8df2-2721626975ce",
	0,
	0,
	0,
	'Port1',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9737d726-f374-4974-a946-0114fd162db5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("a966572d-41be-421f-9b1f-7eea210975a9",
	"321722d1-52f1-4cfd-8df2-2721626975ce",
	"170426ef-f4a8-4f48-8ec0-a04001f9ae0f",
	1,
	1,
	'Controller::land line: 1');
INSERT INTO ACT_IOP
	VALUES ("a966572d-41be-421f-9b1f-7eea210975a9",
	1,
	8,
	1,
	1,
	"00000000-0000-0000-0000-000000000000",
	"ea4468fa-4b20-4012-8e54-d298c549ee90",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("170426ef-f4a8-4f48-8ec0-a04001f9ae0f",
	"321722d1-52f1-4cfd-8df2-2721626975ce",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Controller::land line: 2');
INSERT INTO ACT_IOP
	VALUES ("170426ef-f4a8-4f48-8ec0-a04001f9ae0f",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("665a011d-1bdb-48d7-b1dc-58ea7d841112",
	0,
	0,
	2,
	29,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"321722d1-52f1-4cfd-8df2-2721626975ce");
INSERT INTO V_LIN
	VALUES ("665a011d-1bdb-48d7-b1dc-58ea7d841112",
	'0');
INSERT INTO V_PAR
	VALUES ("665a011d-1bdb-48d7-b1dc-58ea7d841112",
	"170426ef-f4a8-4f48-8ec0-a04001f9ae0f",
	"00000000-0000-0000-0000-000000000000",
	'heading',
	"00000000-0000-0000-0000-000000000000",
	2,
	21);
INSERT INTO SM_STATE
	VALUES ("dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'go',
	4,
	0);
INSERT INTO SM_CH
	VALUES ("dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("4968c65b-d136-4e8e-9126-2e3b79c01a42",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"dbd1cf95-b31b-4e97-a87b-08726ade7ba4");
INSERT INTO SM_AH
	VALUES ("4968c65b-d136-4e8e-9126-2e3b79c01a42",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("4968c65b-d136-4e8e-9126-2e3b79c01a42",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'select one wp related by self -> Waypoint[R3.''is flying to''];
Port1::set_destination( x:wp.x, y:wp.y, z:wp.z );

select one next_wp related by wp -> Waypoint[R2.''follows''];
if (not_empty next_wp)
	relate self to next_wp across R3.''is flying to'';
else
	generate Controller3:''halt'' to self;
end if;
//Port1::set_destination( x:3, y:3, z:1 );
//Port1::set_heading( heading:0 );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("17bc08de-238a-46fa-86e5-95f5d58321b4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"4968c65b-d136-4e8e-9126-2e3b79c01a42");
INSERT INTO ACT_ACT
	VALUES ("17bc08de-238a-46fa-86e5-95f5d58321b4",
	'state',
	0,
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::go',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("397c4d82-a545-4a8d-869f-15d6bff7a195",
	1,
	0,
	0,
	'',
	'',
	'',
	7,
	1,
	4,
	37,
	0,
	0,
	4,
	46,
	4,
	49,
	0,
	0,
	0,
	"17bc08de-238a-46fa-86e5-95f5d58321b4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1829160a-340e-4186-953f-ff2664662ee3",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	1,
	1,
	'Controller::go line: 1');
INSERT INTO ACT_SEL
	VALUES ("1829160a-340e-4186-953f-ff2664662ee3",
	"10b18e85-aade-455f-9e59-87165e143d4e",
	1,
	'one',
	"b45bd1fe-6fc8-408e-a7be-3f1ab04b4338");
INSERT INTO ACT_SR
	VALUES ("1829160a-340e-4186-953f-ff2664662ee3");
INSERT INTO ACT_LNK
	VALUES ("46206fe1-351a-43bc-9392-5016e9ef1a2a",
	'''is flying to''',
	"1829160a-340e-4186-953f-ff2664662ee3",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"00000000-0000-0000-0000-000000000000",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	1,
	34,
	1,
	43,
	1,
	46);
INSERT INTO ACT_SMT
	VALUES ("4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"5a8371c4-f515-4ad3-9ffe-5cbdf902fd15",
	2,
	1,
	'Controller::go line: 2');
INSERT INTO ACT_IOP
	VALUES ("4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"0b7b0648-980a-4657-9783-453131e6af11",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5a8371c4-f515-4ad3-9ffe-5cbdf902fd15",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"72a57d8a-5f22-4bf9-8c38-cd85d8b426cd",
	4,
	1,
	'Controller::go line: 4');
INSERT INTO ACT_SEL
	VALUES ("5a8371c4-f515-4ad3-9ffe-5cbdf902fd15",
	"b8000e56-e2b6-452d-95fc-de3a6ccdcd0c",
	1,
	'one',
	"04b6804d-1f73-4188-8983-5ca4f265e699");
INSERT INTO ACT_SR
	VALUES ("5a8371c4-f515-4ad3-9ffe-5cbdf902fd15");
INSERT INTO ACT_LNK
	VALUES ("acca75ef-08c5-4da0-9edb-92ba3e93b831",
	'''follows''',
	"5a8371c4-f515-4ad3-9ffe-5cbdf902fd15",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"00000000-0000-0000-0000-000000000000",
	1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	4,
	37,
	4,
	46,
	4,
	49);
INSERT INTO ACT_SMT
	VALUES ("72a57d8a-5f22-4bf9-8c38-cd85d8b426cd",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'Controller::go line: 5');
INSERT INTO ACT_IF
	VALUES ("72a57d8a-5f22-4bf9-8c38-cd85d8b426cd",
	"f35939ae-c988-4522-8462-9c59f1031e9f",
	"f740f839-7795-4c8a-ab25-1188b9bfc7e4",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("e272b084-3fc1-49a3-9eb5-502552c8fdbb",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'Controller::go line: 7');
INSERT INTO ACT_E
	VALUES ("e272b084-3fc1-49a3-9eb5-502552c8fdbb",
	"78896b49-1c57-4563-af4b-827999b39eaf",
	"72a57d8a-5f22-4bf9-8c38-cd85d8b426cd");
INSERT INTO V_VAL
	VALUES ("b45bd1fe-6fc8-408e-a7be-3f1ab04b4338",
	0,
	0,
	1,
	26,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("b45bd1fe-6fc8-408e-a7be-3f1ab04b4338",
	"586b9e11-d7de-454f-9bd9-644658fb73cc");
INSERT INTO V_VAL
	VALUES ("2ea3f224-c856-4f72-9069-8b75261d33c1",
	0,
	0,
	2,
	27,
	28,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("2ea3f224-c856-4f72-9069-8b75261d33c1",
	"10b18e85-aade-455f-9e59-87165e143d4e");
INSERT INTO V_VAL
	VALUES ("b34961dc-855c-4bee-9236-378a18ff80b1",
	0,
	0,
	2,
	30,
	30,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_AVL
	VALUES ("b34961dc-855c-4bee-9236-378a18ff80b1",
	"2ea3f224-c856-4f72-9069-8b75261d33c1",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8");
INSERT INTO V_PAR
	VALUES ("b34961dc-855c-4bee-9236-378a18ff80b1",
	"4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	"00000000-0000-0000-0000-000000000000",
	'x',
	"ccf1d6d4-9529-43b4-afd6-1431b938f864",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("edc8c012-28b6-41fb-9e33-a086abe2a766",
	0,
	0,
	2,
	35,
	36,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("edc8c012-28b6-41fb-9e33-a086abe2a766",
	"10b18e85-aade-455f-9e59-87165e143d4e");
INSERT INTO V_VAL
	VALUES ("ccf1d6d4-9529-43b4-afd6-1431b938f864",
	0,
	0,
	2,
	38,
	38,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_AVL
	VALUES ("ccf1d6d4-9529-43b4-afd6-1431b938f864",
	"edc8c012-28b6-41fb-9e33-a086abe2a766",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70");
INSERT INTO V_PAR
	VALUES ("ccf1d6d4-9529-43b4-afd6-1431b938f864",
	"4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	"00000000-0000-0000-0000-000000000000",
	'y',
	"0c05f668-2084-47a1-81fa-1dd35ebe6f6a",
	2,
	33);
INSERT INTO V_VAL
	VALUES ("add140c5-70b1-4211-b9e4-08b32c428d42",
	0,
	0,
	2,
	43,
	44,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("add140c5-70b1-4211-b9e4-08b32c428d42",
	"10b18e85-aade-455f-9e59-87165e143d4e");
INSERT INTO V_VAL
	VALUES ("0c05f668-2084-47a1-81fa-1dd35ebe6f6a",
	0,
	0,
	2,
	46,
	46,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_AVL
	VALUES ("0c05f668-2084-47a1-81fa-1dd35ebe6f6a",
	"add140c5-70b1-4211-b9e4-08b32c428d42",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"67656cdc-d959-4d77-8bb4-853b6c086c6a");
INSERT INTO V_PAR
	VALUES ("0c05f668-2084-47a1-81fa-1dd35ebe6f6a",
	"4b7aad6b-0b76-48d8-94fe-303e3b881cf6",
	"00000000-0000-0000-0000-000000000000",
	'z',
	"00000000-0000-0000-0000-000000000000",
	2,
	41);
INSERT INTO V_VAL
	VALUES ("04b6804d-1f73-4188-8983-5ca4f265e699",
	0,
	0,
	4,
	31,
	32,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("04b6804d-1f73-4188-8983-5ca4f265e699",
	"10b18e85-aade-455f-9e59-87165e143d4e");
INSERT INTO V_VAL
	VALUES ("2b5d8a06-f297-4223-a056-f9a928395741",
	0,
	0,
	5,
	15,
	21,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_IRF
	VALUES ("2b5d8a06-f297-4223-a056-f9a928395741",
	"b8000e56-e2b6-452d-95fc-de3a6ccdcd0c");
INSERT INTO V_VAL
	VALUES ("f740f839-7795-4c8a-ab25-1188b9bfc7e4",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000001",
	"397c4d82-a545-4a8d-869f-15d6bff7a195");
INSERT INTO V_UNY
	VALUES ("f740f839-7795-4c8a-ab25-1188b9bfc7e4",
	"2b5d8a06-f297-4223-a056-f9a928395741",
	'not_empty');
INSERT INTO V_VAR
	VALUES ("10b18e85-aade-455f-9e59-87165e143d4e",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	'wp',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("10b18e85-aade-455f-9e59-87165e143d4e",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO V_VAR
	VALUES ("586b9e11-d7de-454f-9bd9-644658fb73cc",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	'self',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("586b9e11-d7de-454f-9bd9-644658fb73cc",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO V_VAR
	VALUES ("b8000e56-e2b6-452d-95fc-de3a6ccdcd0c",
	"397c4d82-a545-4a8d-869f-15d6bff7a195",
	'next_wp',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("b8000e56-e2b6-452d-95fc-de3a6ccdcd0c",
	0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO ACT_BLK
	VALUES ("f35939ae-c988-4522-8462-9c59f1031e9f",
	0,
	0,
	0,
	'''is flying to''',
	'',
	'',
	6,
	2,
	0,
	0,
	0,
	0,
	6,
	32,
	6,
	35,
	0,
	0,
	0,
	"17bc08de-238a-46fa-86e5-95f5d58321b4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("98519902-bf1e-4cbe-a6dc-48b0f0538403",
	"f35939ae-c988-4522-8462-9c59f1031e9f",
	"00000000-0000-0000-0000-000000000000",
	6,
	2,
	'Controller::go line: 6');
INSERT INTO ACT_REL
	VALUES ("98519902-bf1e-4cbe-a6dc-48b0f0538403",
	"586b9e11-d7de-454f-9bd9-644658fb73cc",
	"b8000e56-e2b6-452d-95fc-de3a6ccdcd0c",
	'''is flying to''',
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	6,
	32,
	6,
	35);
INSERT INTO ACT_BLK
	VALUES ("78896b49-1c57-4563-af4b-827999b39eaf",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	2,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"17bc08de-238a-46fa-86e5-95f5d58321b4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1f9c2ab1-0f6c-4121-a753-b313e039e78d",
	"78896b49-1c57-4563-af4b-827999b39eaf",
	"00000000-0000-0000-0000-000000000000",
	8,
	2,
	'Controller::go line: 8');
INSERT INTO E_ESS
	VALUES ("1f9c2ab1-0f6c-4121-a753-b313e039e78d",
	1,
	0,
	8,
	11,
	8,
	23,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("1f9c2ab1-0f6c-4121-a753-b313e039e78d");
INSERT INTO E_GSME
	VALUES ("1f9c2ab1-0f6c-4121-a753-b313e039e78d",
	"8b378763-7c1f-451d-b66d-3561c7f51373");
INSERT INTO E_GEN
	VALUES ("1f9c2ab1-0f6c-4121-a753-b313e039e78d",
	"586b9e11-d7de-454f-9bd9-644658fb73cc");
INSERT INTO SM_NSTXN
	VALUES ("76cf9781-1ad0-4670-8bd1-44a98e6af2ce",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"a261c91f-b6ae-4a58-8f2e-1c3e8d4c6bd8",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("03361d03-2fda-4b0c-b0b0-18a7d512255a",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"76cf9781-1ad0-4670-8bd1-44a98e6af2ce");
INSERT INTO SM_AH
	VALUES ("03361d03-2fda-4b0c-b0b0-18a7d512255a",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("03361d03-2fda-4b0c-b0b0-18a7d512255a",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("54b8e724-6d9e-448e-bcd0-79ad015bc02a",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"03361d03-2fda-4b0c-b0b0-18a7d512255a");
INSERT INTO ACT_ACT
	VALUES ("54b8e724-6d9e-448e-bcd0-79ad015bc02a",
	'transition',
	0,
	"d515e52b-3ef1-4609-be92-5ec760065fdd",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller1: start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d515e52b-3ef1-4609-be92-5ec760065fdd",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"54b8e724-6d9e-448e-bcd0-79ad015bc02a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("76cf9781-1ad0-4670-8bd1-44a98e6af2ce",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("20064294-899f-4c9a-b015-85ed8da3c1cb",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("e8e62250-4e75-44c7-a2e3-f8e81e537410",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"20064294-899f-4c9a-b015-85ed8da3c1cb");
INSERT INTO SM_AH
	VALUES ("e8e62250-4e75-44c7-a2e3-f8e81e537410",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("e8e62250-4e75-44c7-a2e3-f8e81e537410",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("b190cadf-7528-425e-8a51-28a403d5d440",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"e8e62250-4e75-44c7-a2e3-f8e81e537410");
INSERT INTO ACT_ACT
	VALUES ("b190cadf-7528-425e-8a51-28a403d5d440",
	'transition',
	0,
	"22738d54-af69-4c59-b594-98ff0602e6a3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller2: ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("22738d54-af69-4c59-b594-98ff0602e6a3",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b190cadf-7528-425e-8a51-28a403d5d440",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("20064294-899f-4c9a-b015-85ed8da3c1cb",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("5dc92cac-67f9-4fd2-ae11-7656827ce07f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("ea8bee30-54e1-47b2-9c30-274c1114e18e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"5dc92cac-67f9-4fd2-ae11-7656827ce07f");
INSERT INTO SM_AH
	VALUES ("ea8bee30-54e1-47b2-9c30-274c1114e18e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("ea8bee30-54e1-47b2-9c30-274c1114e18e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("98de70de-fba4-4914-baf1-f296d1743d97",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"ea8bee30-54e1-47b2-9c30-274c1114e18e");
INSERT INTO ACT_ACT
	VALUES ("98de70de-fba4-4914-baf1-f296d1743d97",
	'transition',
	0,
	"c69b2b22-e0a3-4065-b455-695890c67593",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller3: halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c69b2b22-e0a3-4065-b455-695890c67593",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"98de70de-fba4-4914-baf1-f296d1743d97",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("5dc92cac-67f9-4fd2-ae11-7656827ce07f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"3498a029-f4cf-4635-84ec-62909b4b5d88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("7abf2ff4-b504-4f1f-ad4e-54e298a34eab",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"b96ba372-9a31-430f-b0a5-74a1d02169e3",
	"8b378763-7c1f-451d-b66d-3561c7f51373",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("288e7acc-4dae-48b4-8417-ef442fe338da",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"7abf2ff4-b504-4f1f-ad4e-54e298a34eab");
INSERT INTO SM_AH
	VALUES ("288e7acc-4dae-48b4-8417-ef442fe338da",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("288e7acc-4dae-48b4-8417-ef442fe338da",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("cef5cd43-06fb-4837-b6f9-1f45d585776b",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"288e7acc-4dae-48b4-8417-ef442fe338da");
INSERT INTO ACT_ACT
	VALUES ("cef5cd43-06fb-4837-b6f9-1f45d585776b",
	'transition',
	0,
	"1d4f9bd1-2f1a-4640-ac4c-c4b87e42bf07",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller3: halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("1d4f9bd1-2f1a-4640-ac4c-c4b87e42bf07",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"cef5cd43-06fb-4837-b6f9-1f45d585776b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("7abf2ff4-b504-4f1f-ad4e-54e298a34eab",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"3498a029-f4cf-4635-84ec-62909b4b5d88",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("2b582c15-52a6-4c07-a74a-1a4f2fc185ab",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("8750d6e3-82f3-4a58-9f21-84ef8a2711b4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"2b582c15-52a6-4c07-a74a-1a4f2fc185ab");
INSERT INTO SM_AH
	VALUES ("8750d6e3-82f3-4a58-9f21-84ef8a2711b4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("8750d6e3-82f3-4a58-9f21-84ef8a2711b4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("4478ae69-2ca8-4c9d-b47f-4c8a586f57ce",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"8750d6e3-82f3-4a58-9f21-84ef8a2711b4");
INSERT INTO ACT_ACT
	VALUES ("4478ae69-2ca8-4c9d-b47f-4c8a586f57ce",
	'transition',
	0,
	"c8a376d1-9445-433c-bd08-64ec4d56637b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller2: ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c8a376d1-9445-433c-bd08-64ec4d56637b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4478ae69-2ca8-4c9d-b47f-4c8a586f57ce",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("2b582c15-52a6-4c07-a74a-1a4f2fc185ab",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"dbd1cf95-b31b-4e97-a87b-08726ade7ba4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	4);
INSERT INTO O_OBJ
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	'Waypoint',
	2,
	'Waypoint',
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_NBATTR
	VALUES ("2eca120e-6b50-4aaf-a21f-b5ba48524ae8",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_BATTR
	VALUES ("2eca120e-6b50-4aaf-a21f-b5ba48524ae8",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_ATTR
	VALUES ("2eca120e-6b50-4aaf-a21f-b5ba48524ae8",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"00000000-0000-0000-0000-000000000000",
	'x',
	'',
	'',
	'x',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("3a1429e3-6444-43e4-96c5-9943a13d4a70",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_BATTR
	VALUES ("3a1429e3-6444-43e4-96c5-9943a13d4a70",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_ATTR
	VALUES ("3a1429e3-6444-43e4-96c5-9943a13d4a70",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"2eca120e-6b50-4aaf-a21f-b5ba48524ae8",
	'y',
	'',
	'',
	'y',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("67656cdc-d959-4d77-8bb4-853b6c086c6a",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_BATTR
	VALUES ("67656cdc-d959-4d77-8bb4-853b6c086c6a",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_ATTR
	VALUES ("67656cdc-d959-4d77-8bb4-853b6c086c6a",
	"3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"3a1429e3-6444-43e4-96c5-9943a13d4a70",
	'z',
	'',
	'',
	'z',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_ID
	VALUES (1,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO O_ID
	VALUES (2,
	"3809e9c5-868b-4dd3-9221-69f1bf01199b");
INSERT INTO PE_PE
	VALUES ("74f6f611-d69a-4450-9784-beffdfe615ce",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("74f6f611-d69a-4450-9784-beffdfe615ce",
	2,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("74f6f611-d69a-4450-9784-beffdfe615ce");
INSERT INTO R_PART
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"7b410cd5-190d-4b75-9dfa-620173c90016",
	0,
	1,
	'is followed by ');
INSERT INTO R_RTO
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"7b410cd5-190d-4b75-9dfa-620173c90016",
	-1);
INSERT INTO R_OIR
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"7b410cd5-190d-4b75-9dfa-620173c90016",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"91243806-e3c1-4306-b6c4-2e5ee3535a3f",
	0,
	0,
	'follows');
INSERT INTO R_RTO
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"91243806-e3c1-4306-b6c4-2e5ee3535a3f",
	-1);
INSERT INTO R_OIR
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"74f6f611-d69a-4450-9784-beffdfe615ce",
	"91243806-e3c1-4306-b6c4-2e5ee3535a3f",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("5a9e39ce-470c-4fb2-be6d-6d03b7375c8f");
INSERT INTO R_PART
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"93feb4f5-666d-40f5-8510-4aa420b486b1",
	0,
	1,
	'');
INSERT INTO R_RTO
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"93feb4f5-666d-40f5-8510-4aa420b486b1",
	-1);
INSERT INTO R_OIR
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"93feb4f5-666d-40f5-8510-4aa420b486b1",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"b491cf56-b983-4e62-bec6-2f2d6e461cf7",
	0,
	1,
	'begin with');
INSERT INTO R_RTO
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"b491cf56-b983-4e62-bec6-2f2d6e461cf7",
	-1);
INSERT INTO R_OIR
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"5a9e39ce-470c-4fb2-be6d-6d03b7375c8f",
	"b491cf56-b983-4e62-bec6-2f2d6e461cf7",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	3,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("6bb5cdb7-3f80-497b-bd16-da824e0f3b25");
INSERT INTO R_PART
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"329c3d6a-3a15-4c24-bfa2-b9f1ab3f98ab",
	0,
	1,
	'');
INSERT INTO R_RTO
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"329c3d6a-3a15-4c24-bfa2-b9f1ab3f98ab",
	-1);
INSERT INTO R_OIR
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"329c3d6a-3a15-4c24-bfa2-b9f1ab3f98ab",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"6371c982-2ae1-45bb-8985-9841b2433288",
	0,
	1,
	'is flying to');
INSERT INTO R_RTO
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"6371c982-2ae1-45bb-8985-9841b2433288",
	-1);
INSERT INTO R_OIR
	VALUES ("3809e9c5-868b-4dd3-9221-69f1bf01199b",
	"6bb5cdb7-3f80-497b-bd16-da824e0f3b25",
	"6371c982-2ae1-45bb-8985-9841b2433288",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO EP_PKG
	VALUES ("0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'System',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	21);
INSERT INTO CL_IC
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	"8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'gnc::Library::MAV',
	'');
INSERT INTO CL_POR
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	"9df3483a-ab97-4ee7-8415-9b4b161408e2",
	'Port1',
	"aee86548-4fdd-4e44-b3e9-ed3ff3e556ba");
INSERT INTO CL_IIR
	VALUES ("1c1a54c7-9002-4457-8eec-f2719fd785d0",
	"93221829-0135-489c-961a-9d42c4252036",
	"aee86548-4fdd-4e44-b3e9-ed3ff3e556ba",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO CL_IP
	VALUES ("1c1a54c7-9002-4457-8eec-f2719fd785d0",
	'mavcontrol',
	'');
INSERT INTO CL_IPINS
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	"1c1a54c7-9002-4457-8eec-f2719fd785d0");
INSERT INTO PE_PE
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	21);
INSERT INTO CL_IC
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'gnc::Library::Control',
	'');
INSERT INTO CL_POR
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	"bada52a0-1256-430d-8579-634b9c323fea",
	'Port1',
	"ffde1b3d-54d8-47c5-b766-3430cfb4a967");
INSERT INTO CL_IIR
	VALUES ("94bdc6ef-8903-4e4c-9eeb-1fbfe06732ca",
	"33610dbc-6887-421d-81c6-740629675b3d",
	"ffde1b3d-54d8-47c5-b766-3430cfb4a967",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO CL_IR
	VALUES ("94bdc6ef-8903-4e4c-9eeb-1fbfe06732ca",
	"289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	'mavcontrol',
	'');
INSERT INTO PE_PE
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	22);
INSERT INTO C_SF
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	"33610dbc-6887-421d-81c6-740629675b3d",
	"93221829-0135-489c-961a-9d42c4252036",
	'',
	'MAV::Port1::mavcontrol -o)- Control::Port1::mavcontrol');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	0);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	"00000000-0000-0000-0000-000000000000",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	1);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	"00000000-0000-0000-0000-000000000000",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	2);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	"00000000-0000-0000-0000-000000000000",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	3);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	"00000000-0000-0000-0000-000000000000",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	4);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	"00000000-0000-0000-0000-000000000000",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	5);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	"00000000-0000-0000-0000-000000000000",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	6);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	"00000000-0000-0000-0000-000000000000",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	7);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	8);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	9);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	"00000000-0000-0000-0000-000000000000",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	10);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	"00000000-0000-0000-0000-000000000000",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	11);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	12);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	"00000000-0000-0000-0000-000000000000",
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	13);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	"00000000-0000-0000-0000-000000000000",
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	"ba5eda7a-def5-0000-0000-00000000000b",
	1,
	'');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	"ba5eda7a-def5-0000-0000-00000000000c",
	3,
	'');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	"00000000-0000-0000-0000-000000000000",
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	"ba5eda7a-def5-0000-0000-000000000002",
	2,
	'');
