-- root-types-contained: SystemModel_c,PackageableElement_c,DataType_c,CoreDataType_c,UserDataType_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES ("d923df31-2d4f-4454-ba3a-3347665a758b",
	'gnc',
	1);
INSERT INTO EP_PKG
	VALUES ("a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'External Entities',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("2fd70a9f-eaa7-4d40-a481-ff861310433e",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Time',
	1);
INSERT INTO S_BRG
	VALUES ("7cedef90-3ff6-47cb-865f-f2a4d5cdfb21",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'current_date',
	'',
	1,
	"ba5eda7a-def5-0000-0000-00000000000e",
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("784b6436-c6f2-4593-a644-ee36749b70e8",
	"7cedef90-3ff6-47cb-865f-f2a4d5cdfb21");
INSERT INTO ACT_ACT
	VALUES ("784b6436-c6f2-4593-a644-ee36749b70e8",
	'bridge',
	0,
	"906271f5-4f82-4685-9349-3d38fb5152e1",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::current_date',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("906271f5-4f82-4685-9349-3d38fb5152e1",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"784b6436-c6f2-4593-a644-ee36749b70e8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("885835ed-0d41-44d5-a1b5-7e8007ff883a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'create_date',
	'',
	1,
	"ba5eda7a-def5-0000-0000-00000000000e",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("e26eddec-36ab-4e36-b856-1eaa69692c14",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'second',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"8c2f8836-521b-4f47-ba97-f9c8309b52f4",
	'');
INSERT INTO S_BPARM
	VALUES ("2ed26ccd-e8f8-4e38-aac7-f825b913f96f",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'minute',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"75124bf0-c1ce-4dca-bc91-21ac16396b72",
	'');
INSERT INTO S_BPARM
	VALUES ("75124bf0-c1ce-4dca-bc91-21ac16396b72",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'hour',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"95196946-0edf-4e69-b2ad-4b20d5c78fda",
	'');
INSERT INTO S_BPARM
	VALUES ("95196946-0edf-4e69-b2ad-4b20d5c78fda",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'day',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("8c2f8836-521b-4f47-ba97-f9c8309b52f4",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'month',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"2ed26ccd-e8f8-4e38-aac7-f825b913f96f",
	'');
INSERT INTO S_BPARM
	VALUES ("e0545463-2cc1-4caf-b6f4-baff465c1370",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a",
	'year',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"e26eddec-36ab-4e36-b856-1eaa69692c14",
	'');
INSERT INTO ACT_BRB
	VALUES ("33fffa36-0d3f-4385-93cf-869258101258",
	"885835ed-0d41-44d5-a1b5-7e8007ff883a");
INSERT INTO ACT_ACT
	VALUES ("33fffa36-0d3f-4385-93cf-869258101258",
	'bridge',
	0,
	"0496a0f5-c565-4ecb-b95b-32b120ae38fa",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::create_date',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("0496a0f5-c565-4ecb-b95b-32b120ae38fa",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"33fffa36-0d3f-4385-93cf-869258101258",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("0de4654f-76f7-44f5-ad32-307f6f132e9e",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_second',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("4e33a7dd-1a67-4b85-8dbc-2b8c12bacc71",
	"0de4654f-76f7-44f5-ad32-307f6f132e9e",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("13a91416-328e-41cb-8055-7a9776cb2ca4",
	"0de4654f-76f7-44f5-ad32-307f6f132e9e");
INSERT INTO ACT_ACT
	VALUES ("13a91416-328e-41cb-8055-7a9776cb2ca4",
	'bridge',
	0,
	"01760845-9ca2-497d-82f6-8c276cec9f43",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_second',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("01760845-9ca2-497d-82f6-8c276cec9f43",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"13a91416-328e-41cb-8055-7a9776cb2ca4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("506ec051-e809-4ad3-838c-dbcce43a116c",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_minute',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("095f3f5c-db7f-4e4a-9bda-63ac8efeeab6",
	"506ec051-e809-4ad3-838c-dbcce43a116c",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("dbe7500b-903f-4ec0-982c-4dc6e448b71c",
	"506ec051-e809-4ad3-838c-dbcce43a116c");
INSERT INTO ACT_ACT
	VALUES ("dbe7500b-903f-4ec0-982c-4dc6e448b71c",
	'bridge',
	0,
	"f774142d-7037-483a-9580-d49a3f832752",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_minute',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("f774142d-7037-483a-9580-d49a3f832752",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"dbe7500b-903f-4ec0-982c-4dc6e448b71c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("d91d2b03-9a66-47ef-9dac-87b57f9266a8",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_hour',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("eeeb6b29-233f-4034-92c3-3480f65cfd43",
	"d91d2b03-9a66-47ef-9dac-87b57f9266a8",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("50c03ab5-9f77-4da7-99dd-79678bb1b4a4",
	"d91d2b03-9a66-47ef-9dac-87b57f9266a8");
INSERT INTO ACT_ACT
	VALUES ("50c03ab5-9f77-4da7-99dd-79678bb1b4a4",
	'bridge',
	0,
	"255c3666-9412-4f5a-9d06-8f6cd06d0e18",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_hour',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("255c3666-9412-4f5a-9d06-8f6cd06d0e18",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"50c03ab5-9f77-4da7-99dd-79678bb1b4a4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("05736629-401d-4624-8114-cfffe7db2ff0",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_day',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("136fa754-90f9-476a-84af-8c0f0f4c6c2a",
	"05736629-401d-4624-8114-cfffe7db2ff0",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("0fa68f33-03cb-47ca-b285-db4463ae0067",
	"05736629-401d-4624-8114-cfffe7db2ff0");
INSERT INTO ACT_ACT
	VALUES ("0fa68f33-03cb-47ca-b285-db4463ae0067",
	'bridge',
	0,
	"09e47c86-724b-49a8-9ef2-e9eca16af15b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_day',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("09e47c86-724b-49a8-9ef2-e9eca16af15b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0fa68f33-03cb-47ca-b285-db4463ae0067",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("23a621c8-1743-46d0-9f13-3f7faa7dec6a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_month',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5754c5a5-c178-4367-8077-e0151b686a96",
	"23a621c8-1743-46d0-9f13-3f7faa7dec6a",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("311f52f0-9e78-4734-851c-6d61bfefc953",
	"23a621c8-1743-46d0-9f13-3f7faa7dec6a");
INSERT INTO ACT_ACT
	VALUES ("311f52f0-9e78-4734-851c-6d61bfefc953",
	'bridge',
	0,
	"d816253b-4a8e-4990-91ac-d844ac8bf570",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_month',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("d816253b-4a8e-4990-91ac-d844ac8bf570",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"311f52f0-9e78-4734-851c-6d61bfefc953",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("22dd5f8d-8ec0-480b-aa7c-c2b3c5155230",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'get_year',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("b068413b-fb88-4844-9237-7b9648f4a69e",
	"22dd5f8d-8ec0-480b-aa7c-c2b3c5155230",
	'date',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("c403ec98-5c2c-49de-a6bf-4d29c6844f7a",
	"22dd5f8d-8ec0-480b-aa7c-c2b3c5155230");
INSERT INTO ACT_ACT
	VALUES ("c403ec98-5c2c-49de-a6bf-4d29c6844f7a",
	'bridge',
	0,
	"6e6cd4f6-234d-4a47-a6d2-61c5f4936bb7",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::get_year',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6e6cd4f6-234d-4a47-a6d2-61c5f4936bb7",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c403ec98-5c2c-49de-a6bf-4d29c6844f7a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("eccc3978-a3d3-4735-8b47-3973a041f799",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'current_clock',
	'',
	1,
	"ba5eda7a-def5-0000-0000-000000000010",
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("0557ca18-c641-4803-9b40-d08aae30b350",
	"eccc3978-a3d3-4735-8b47-3973a041f799");
INSERT INTO ACT_ACT
	VALUES ("0557ca18-c641-4803-9b40-d08aae30b350",
	'bridge',
	0,
	"5551477c-2be9-4acd-90a0-04d632351767",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::current_clock',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("5551477c-2be9-4acd-90a0-04d632351767",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0557ca18-c641-4803-9b40-d08aae30b350",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("012516b5-2372-4c49-bcac-48cf3499122a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	1,
	"ba5eda7a-def5-0000-0000-00000000000f",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fec87e8d-6d3c-4d19-9c2b-b629eefd2276",
	"012516b5-2372-4c49-bcac-48cf3499122a",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"47ecb3cc-fc05-47d4-afc1-693328b6c942",
	'');
INSERT INTO S_BPARM
	VALUES ("47ecb3cc-fc05-47d4-afc1-693328b6c942",
	"012516b5-2372-4c49-bcac-48cf3499122a",
	'event_inst',
	"ba5eda7a-def5-0000-0000-00000000000a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("4edd3b6c-e170-48a0-ae59-7839f162dac4",
	"012516b5-2372-4c49-bcac-48cf3499122a");
INSERT INTO ACT_ACT
	VALUES ("4edd3b6c-e170-48a0-ae59-7839f162dac4",
	'bridge',
	0,
	"22a4dbec-5a5c-4b6d-adf8-93bac975b582",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("22a4dbec-5a5c-4b6d-adf8-93bac975b582",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4edd3b6c-e170-48a0-ae59-7839f162dac4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	1,
	"ba5eda7a-def5-0000-0000-00000000000f",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("0006b186-f90c-446a-9b32-fbeb81f82b83",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"11f05ffe-227e-4e23-a720-4313facbac55",
	'');
INSERT INTO S_BPARM
	VALUES ("11f05ffe-227e-4e23-a720-4313facbac55",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7",
	'event_inst',
	"ba5eda7a-def5-0000-0000-00000000000a",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("ff155361-0c53-43a5-818d-ba2314b10da9",
	"49b9f9b5-3671-4cad-8867-684dfc6f2ff7");
INSERT INTO ACT_ACT
	VALUES ("ff155361-0c53-43a5-818d-ba2314b10da9",
	'bridge',
	0,
	"67dd48cf-a20b-4712-b5be-8e71ff147993",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_start_recurring',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("67dd48cf-a20b-4712-b5be-8e71ff147993",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ff155361-0c53-43a5-818d-ba2314b10da9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b2c8f339-b0a5-4e8a-b153-0267d79f5781",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000002",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("9666bafd-8990-4372-9988-4618b7b9be38",
	"b2c8f339-b0a5-4e8a-b153-0267d79f5781",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("5303b0cd-347a-4136-93be-33261ac293e5",
	"b2c8f339-b0a5-4e8a-b153-0267d79f5781");
INSERT INTO ACT_ACT
	VALUES ("5303b0cd-347a-4136-93be-33261ac293e5",
	'bridge',
	0,
	"633b4b48-ccc7-4758-9b0c-2609a3db32d3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_remaining_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("633b4b48-ccc7-4758-9b0c-2609a3db32d3",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5303b0cd-347a-4136-93be-33261ac293e5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("b06bfb31-6f55-427e-9334-14b888ff1d20",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"24f4f888-57da-472b-9a64-d4bc284b78aa",
	'');
INSERT INTO S_BPARM
	VALUES ("24f4f888-57da-472b-9a64-d4bc284b78aa",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("23b89edc-50be-4398-a6b3-e4b4cdca83d6",
	"ca97dd11-5044-44e3-8f4e-1b2a3b6f76d4");
INSERT INTO ACT_ACT
	VALUES ("23b89edc-50be-4398-a6b3-e4b4cdca83d6",
	'bridge',
	0,
	"5053a574-9cb8-44cc-8b6b-a81720e1653b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_reset_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("5053a574-9cb8-44cc-8b6b-a81720e1653b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"23b89edc-50be-4398-a6b3-e4b4cdca83d6",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("11329069-afb1-43bf-a9a3-0c9755931c05",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"005c5ae9-3661-4f79-a4e3-b6ae086be86b",
	'');
INSERT INTO S_BPARM
	VALUES ("005c5ae9-3661-4f79-a4e3-b6ae086be86b",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a",
	'microseconds',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("996a2438-236e-4fda-8a58-d5123351b0b9",
	"f0cb027c-a974-4074-a8d5-c2c83b70c67a");
INSERT INTO ACT_ACT
	VALUES ("996a2438-236e-4fda-8a58-d5123351b0b9",
	'bridge',
	0,
	"b049b84f-9a89-44d7-a43c-63030f744b49",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_add_time',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b049b84f-9a89-44d7-a43c-63030f744b49",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"996a2438-236e-4fda-8a58-d5123351b0b9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("d749e717-9081-4287-9128-876514c2a5c9",
	"2fd70a9f-eaa7-4d40-a481-ff861310433e",
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	1,
	"ba5eda7a-def5-0000-0000-000000000001",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5a8c78a4-7963-42d8-8e92-bcbecc0c513e",
	"d749e717-9081-4287-9128-876514c2a5c9",
	'timer_inst_ref',
	"ba5eda7a-def5-0000-0000-00000000000f",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("56ca418a-e355-4d9a-852e-7430505a5213",
	"d749e717-9081-4287-9128-876514c2a5c9");
INSERT INTO ACT_ACT
	VALUES ("56ca418a-e355-4d9a-852e-7430505a5213",
	'bridge',
	0,
	"782adef2-c301-4613-bc68-0fe9f074699b",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Time::timer_cancel',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("782adef2-c301-4613-bc68-0fe9f074699b",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"56ca418a-e355-4d9a-852e-7430505a5213",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	'Architecture',
	'',
	'ARCH',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Architecture',
	1);
INSERT INTO S_BRG
	VALUES ("01612056-7900-41ae-ad03-f233e1da0a84",
	"f0d72ff6-19c9-44dc-88e1-94d22801ccee",
	'shutdown',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'control stop;',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES ("bdf8b866-587f-45ee-afc2-f3afc9a769c0",
	"01612056-7900-41ae-ad03-f233e1da0a84");
INSERT INTO ACT_ACT
	VALUES ("bdf8b866-587f-45ee-afc2-f3afc9a769c0",
	'bridge',
	0,
	"0a785f9b-9b7c-4cf8-b665-7dd68af47f41",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Architecture::shutdown',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("0a785f9b-9b7c-4cf8-b665-7dd68af47f41",
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"bdf8b866-587f-45ee-afc2-f3afc9a769c0",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0b9d5df5-32ea-41d6-bd1a-d90a248c3444",
	"0a785f9b-9b7c-4cf8-b665-7dd68af47f41",
	"00000000-0000-0000-0000-000000000000",
	1,
	1,
	'Architecture::shutdown line: 1');
INSERT INTO ACT_CTL
	VALUES ("0b9d5df5-32ea-41d6-bd1a-d90a248c3444");
INSERT INTO PE_PE
	VALUES ("36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	1,
	"a0463fe9-1f1f-47dc-b337-d8cf17433a29",
	"00000000-0000-0000-0000-000000000000",
	5);
INSERT INTO S_EE
	VALUES ("36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'Logging',
	'',
	'LOG',
	"00000000-0000-0000-0000-000000000000",
	'',
	'Logging',
	1);
INSERT INTO S_BRG
	VALUES ("b65db544-13fe-459b-9436-379c46f3f884",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogSuccess',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("1b690e45-945a-4138-aaf9-971ac7b80bdb",
	"b65db544-13fe-459b-9436-379c46f3f884",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("4f98745e-0369-47a7-aadf-510b2084471d",
	"b65db544-13fe-459b-9436-379c46f3f884");
INSERT INTO ACT_ACT
	VALUES ("4f98745e-0369-47a7-aadf-510b2084471d",
	'bridge',
	0,
	"ca9d58e7-6fb3-43d6-ba3e-0978dec2ffdf",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogSuccess',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ca9d58e7-6fb3-43d6-ba3e-0978dec2ffdf",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4f98745e-0369-47a7-aadf-510b2084471d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("26845840-b5bb-49bf-8a74-624a2a16e1cb",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogFailure',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("447876ec-a5c7-4c70-992a-e5777aacf5cd",
	"26845840-b5bb-49bf-8a74-624a2a16e1cb",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("17c8e46d-2765-43da-8433-c24a45b333a3",
	"26845840-b5bb-49bf-8a74-624a2a16e1cb");
INSERT INTO ACT_ACT
	VALUES ("17c8e46d-2765-43da-8433-c24a45b333a3",
	'bridge',
	0,
	"a063b501-993c-431e-a8cb-757fd9ce66d0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogFailure',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a063b501-993c-431e-a8cb-757fd9ce66d0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"17c8e46d-2765-43da-8433-c24a45b333a3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("c4857b04-079f-4db0-947c-e1895ef20ea4",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogInfo',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("92cfb361-9539-48da-928e-44aceb487d80",
	"c4857b04-079f-4db0-947c-e1895ef20ea4",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("651326e7-d1cf-4336-bff2-71963e3a2330",
	"c4857b04-079f-4db0-947c-e1895ef20ea4");
INSERT INTO ACT_ACT
	VALUES ("651326e7-d1cf-4336-bff2-71963e3a2330",
	'bridge',
	0,
	"29e794da-bfd7-47dc-868b-f7d336e8ae7a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInfo',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("29e794da-bfd7-47dc-868b-f7d336e8ae7a",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"651326e7-d1cf-4336-bff2-71963e3a2330",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogDate',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fb65973c-ceb7-450f-8981-a8ce6822e2de",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	'd',
	"ba5eda7a-def5-0000-0000-00000000000e",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO S_BPARM
	VALUES ("da6ae748-69cb-4fd9-9355-f3beb44f4ce1",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"fb65973c-ceb7-450f-8981-a8ce6822e2de",
	'');
INSERT INTO ACT_BRB
	VALUES ("0d2bd5b8-88b8-4214-8658-d7725180942d",
	"6ed19ffe-b20e-4e1b-9dd0-93ce8b47d42b");
INSERT INTO ACT_ACT
	VALUES ("0d2bd5b8-88b8-4214-8658-d7725180942d",
	'bridge',
	0,
	"103694db-4f1b-48e4-a962-19291f28a1b1",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogDate',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("103694db-4f1b-48e4-a962-19291f28a1b1",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"0d2bd5b8-88b8-4214-8658-d7725180942d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogTime',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("fc4ab462-604f-439c-a0a2-3276f17853a0",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	't',
	"ba5eda7a-def5-0000-0000-000000000010",
	0,
	'',
	"9fe61b3c-a2ce-41ea-b42e-a05fe4c6b91b",
	'');
INSERT INTO S_BPARM
	VALUES ("9fe61b3c-a2ce-41ea-b42e-a05fe4c6b91b",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("44e96e66-a31c-4bf1-835d-ac3017a373cc",
	"b332a79e-f2af-4c5d-847d-d39ccb1153c7");
INSERT INTO ACT_ACT
	VALUES ("44e96e66-a31c-4bf1-835d-ac3017a373cc",
	'bridge',
	0,
	"239530a4-9d25-4994-a295-73bb8cca55bf",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogTime',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("239530a4-9d25-4994-a295-73bb8cca55bf",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"44e96e66-a31c-4bf1-835d-ac3017a373cc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("4d8d47cc-720d-46e5-ae28-e54cd975a427",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogReal',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("d31c8f8b-38b0-4ada-8945-5ba88d4fc6f5",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427",
	'r',
	"ba5eda7a-def5-0000-0000-000000000003",
	0,
	'',
	"060aba76-3308-4400-aa11-0843cf3c8b7a",
	'');
INSERT INTO S_BPARM
	VALUES ("060aba76-3308-4400-aa11-0843cf3c8b7a",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427",
	'message',
	"ba5eda7a-def5-0000-0000-000000000004",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("519b0302-a5f6-40ce-8466-937b16479a78",
	"4d8d47cc-720d-46e5-ae28-e54cd975a427");
INSERT INTO ACT_ACT
	VALUES ("519b0302-a5f6-40ce-8466-937b16479a78",
	'bridge',
	0,
	"46e7ccce-ade0-4581-8d5c-f6a594595577",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogReal',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("46e7ccce-ade0-4581-8d5c-f6a594595577",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"519b0302-a5f6-40ce-8466-937b16479a78",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO S_BRG
	VALUES ("b7d2a809-9794-4b40-87e1-b7c0686375e0",
	"36aedb1b-4cbf-4535-9bcb-f7b134d7e174",
	'LogInteger',
	'',
	0,
	"ba5eda7a-def5-0000-0000-000000000000",
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES ("5b5bf126-0e25-42a2-bb8e-0aa375d5b213",
	"b7d2a809-9794-4b40-87e1-b7c0686375e0",
	'message',
	"ba5eda7a-def5-0000-0000-000000000002",
	0,
	'',
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO ACT_BRB
	VALUES ("6255d3b6-9825-4252-8b6a-4edef40405a2",
	"b7d2a809-9794-4b40-87e1-b7c0686375e0");
INSERT INTO ACT_ACT
	VALUES ("6255d3b6-9825-4252-8b6a-4edef40405a2",
	'bridge',
	0,
	"a323c178-9824-4435-886a-799a8412d5de",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Logging::LogInteger',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("a323c178-9824-4435-886a-799a8412d5de",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6255d3b6-9825-4252-8b6a-4edef40405a2",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO EP_PKG
	VALUES ("0924fcd2-185c-4c76-b1c2-5ce790f1ba0a",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Interfaces',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("78776ad7-dffd-4126-8217-a913ac6e4bc8",
	1,
	"0924fcd2-185c-4c76-b1c2-5ce790f1ba0a",
	"00000000-0000-0000-0000-000000000000",
	6);
INSERT INTO C_I
	VALUES ("78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO C_EP
	VALUES ("b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'init',
	'');
INSERT INTO C_IO
	VALUES ("b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"ba5eda7a-def5-0000-0000-000000000000",
	'init',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'takeoff',
	'');
INSERT INTO C_IO
	VALUES ("7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"ba5eda7a-def5-0000-0000-000000000000",
	'takeoff',
	'',
	0,
	'',
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e");
INSERT INTO C_PP
	VALUES ("82188d43-e348-4d1f-89d7-47f817a84ae6",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"ba5eda7a-def5-0000-0000-000000000003",
	'alt',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'land',
	'');
INSERT INTO C_IO
	VALUES ("37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"ba5eda7a-def5-0000-0000-000000000000",
	'land',
	'',
	0,
	'',
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17");
INSERT INTO C_EP
	VALUES ("c53d4966-9097-4e62-8e45-bb3b7522378a",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'arm',
	'');
INSERT INTO C_IO
	VALUES ("c53d4966-9097-4e62-8e45-bb3b7522378a",
	"ba5eda7a-def5-0000-0000-000000000000",
	'arm',
	'',
	0,
	'',
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456");
INSERT INTO C_EP
	VALUES ("248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'set_destination',
	'');
INSERT INTO C_IO
	VALUES ("248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000000",
	'set_destination',
	'',
	0,
	'',
	"c53d4966-9097-4e62-8e45-bb3b7522378a");
INSERT INTO C_PP
	VALUES ("7f707e01-0f0a-48c7-afd8-8245ae5ea78d",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'x',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_PP
	VALUES ("a91a89dc-0d33-4ff1-9a4a-2367638a7031",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'y',
	'',
	0,
	'',
	"7f707e01-0f0a-48c7-afd8-8245ae5ea78d");
INSERT INTO C_PP
	VALUES ("a760ebd0-ab62-475c-b0ee-4c8528096f1d",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"ba5eda7a-def5-0000-0000-000000000003",
	'z',
	'',
	0,
	'',
	"a91a89dc-0d33-4ff1-9a4a-2367638a7031");
INSERT INTO C_EP
	VALUES ("c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'set_heading',
	'');
INSERT INTO C_IO
	VALUES ("c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"ba5eda7a-def5-0000-0000-000000000000",
	'set_heading',
	'',
	0,
	'',
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279");
INSERT INTO C_PP
	VALUES ("d4a22d73-9f5f-4533-8c78-eab99944cb1f",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"ba5eda7a-def5-0000-0000-000000000003",
	'heading',
	'',
	0,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO C_EP
	VALUES ("7576d5e0-2683-4a42-967a-ddb25a458620",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'get_heading',
	'');
INSERT INTO C_IO
	VALUES ("7576d5e0-2683-4a42-967a-ddb25a458620",
	"ba5eda7a-def5-0000-0000-000000000003",
	'get_heading',
	'',
	0,
	'',
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52");
INSERT INTO C_EP
	VALUES ("e2e61698-b9dc-4911-95c7-79872095f0dd",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	-1,
	'ready',
	'');
INSERT INTO C_IO
	VALUES ("e2e61698-b9dc-4911-95c7-79872095f0dd",
	"ba5eda7a-def5-0000-0000-000000000000",
	'ready',
	'',
	1,
	'',
	"7576d5e0-2683-4a42-967a-ddb25a458620");
INSERT INTO EP_PKG
	VALUES ("d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Library',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	1,
	"d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"00000000-0000-0000-0000-000000000000",
	2);
INSERT INTO C_C
	VALUES ("8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'MAV',
	'',
	0,
	"00000000-0000-0000-0000-000000000000",
	0,
	'');
INSERT INTO C_PO
	VALUES ("9df3483a-ab97-4ee7-8415-9b4b161408e2",
	"8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	'Port1',
	0,
	0);
INSERT INTO C_IR
	VALUES ("93221829-0135-489c-961a-9d42c4252036",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	"9df3483a-ab97-4ee7-8415-9b4b161408e2");
INSERT INTO C_P
	VALUES ("93221829-0135-489c-961a-9d42c4252036",
	'mavcontrol',
	'Unnamed Interface',
	'',
	'MAV::Port1::mavcontrol');
INSERT INTO SPR_PEP
	VALUES ("2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a",
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a",
	'init',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("a964fa55-38dc-4d60-80dd-48025206d447",
	"2cdfb96e-bbce-4f74-8ed5-32bfa6461a0a");
INSERT INTO ACT_ACT
	VALUES ("a964fa55-38dc-4d60-80dd-48025206d447",
	'interface operation',
	0,
	"b3ec5bc1-0cdc-405e-beeb-021028b041e3",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b3ec5bc1-0cdc-405e-beeb-021028b041e3",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a964fa55-38dc-4d60-80dd-48025206d447",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("17b9223c-4fbe-4528-9d24-88e8c6b169cb",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("17b9223c-4fbe-4528-9d24-88e8c6b169cb",
	'takeoff',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("819cca4a-a620-41f1-86c3-be0b989dd7a3",
	"17b9223c-4fbe-4528-9d24-88e8c6b169cb");
INSERT INTO ACT_ACT
	VALUES ("819cca4a-a620-41f1-86c3-be0b989dd7a3",
	'interface operation',
	0,
	"f4a75a42-b36d-4f2d-ab77-d60f2d9430fe",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::takeoff',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("f4a75a42-b36d-4f2d-ab77-d60f2d9430fe",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"819cca4a-a620-41f1-86c3-be0b989dd7a3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("843b9758-6f7e-434f-80e7-cbe244ffbe3f",
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("843b9758-6f7e-434f-80e7-cbe244ffbe3f",
	'land',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("87c7c962-1071-43b0-b08a-aaff42f969e3",
	"843b9758-6f7e-434f-80e7-cbe244ffbe3f");
INSERT INTO ACT_ACT
	VALUES ("87c7c962-1071-43b0-b08a-aaff42f969e3",
	'interface operation',
	0,
	"e67af14e-14cf-4c35-994c-fa31ccfc0477",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("e67af14e-14cf-4c35-994c-fa31ccfc0477",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"87c7c962-1071-43b0-b08a-aaff42f969e3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("5485bf8e-c85a-4150-857c-8bb2aec093d7",
	"c53d4966-9097-4e62-8e45-bb3b7522378a",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("5485bf8e-c85a-4150-857c-8bb2aec093d7",
	'arm',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("fbe26723-a6dd-4dbc-9e6d-818af280941c",
	"5485bf8e-c85a-4150-857c-8bb2aec093d7");
INSERT INTO ACT_ACT
	VALUES ("fbe26723-a6dd-4dbc-9e6d-818af280941c",
	'interface operation',
	0,
	"ea0a1b0a-c814-4e4e-a081-817eea030576",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::arm',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ea0a1b0a-c814-4e4e-a081-817eea030576",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"fbe26723-a6dd-4dbc-9e6d-818af280941c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("9594ac6d-f38c-4123-b2f9-00a11f9f948b",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("9594ac6d-f38c-4123-b2f9-00a11f9f948b",
	'set_destination',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("4e2a1d38-88cd-47d8-b112-7fecb043c207",
	"9594ac6d-f38c-4123-b2f9-00a11f9f948b");
INSERT INTO ACT_ACT
	VALUES ("4e2a1d38-88cd-47d8-b112-7fecb043c207",
	'interface operation',
	0,
	"47cec18d-18ba-4e54-bd2e-79bb13726a71",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_destination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("47cec18d-18ba-4e54-bd2e-79bb13726a71",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"4e2a1d38-88cd-47d8-b112-7fecb043c207",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("0754e734-d3da-4fa8-bff4-fad81e3b5d4b",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("0754e734-d3da-4fa8-bff4-fad81e3b5d4b",
	'set_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("aff52a6b-6e13-418f-8837-f0d3474b8224",
	"0754e734-d3da-4fa8-bff4-fad81e3b5d4b");
INSERT INTO ACT_ACT
	VALUES ("aff52a6b-6e13-418f-8837-f0d3474b8224",
	'interface operation',
	0,
	"fbc0b12b-1987-4783-9610-9ee5f8413a9a",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("fbc0b12b-1987-4783-9610-9ee5f8413a9a",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"aff52a6b-6e13-418f-8837-f0d3474b8224",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("5c3a02de-f488-46e9-8f8d-6c65ac369468",
	"7576d5e0-2683-4a42-967a-ddb25a458620",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("5c3a02de-f488-46e9-8f8d-6c65ac369468",
	'get_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("c659ec02-1f14-42d9-9b0e-9f302f4dd5e9",
	"5c3a02de-f488-46e9-8f8d-6c65ac369468");
INSERT INTO ACT_ACT
	VALUES ("c659ec02-1f14-42d9-9b0e-9f302f4dd5e9",
	'interface operation',
	0,
	"3c068de8-5df8-40e2-8dc2-5fbff77834ba",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::get_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("3c068de8-5df8-40e2-8dc2-5fbff77834ba",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c659ec02-1f14-42d9-9b0e-9f302f4dd5e9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_PEP
	VALUES ("c5523a0f-b436-48b9-a89f-15e0267e2379",
	"e2e61698-b9dc-4911-95c7-79872095f0dd",
	"93221829-0135-489c-961a-9d42c4252036");
INSERT INTO SPR_PO
	VALUES ("c5523a0f-b436-48b9-a89f-15e0267e2379",
	'ready',
	'',
	'',
	1,
	0);
INSERT INTO ACT_POB
	VALUES ("e1f8423d-32c3-4833-babb-1f39208e1a7a",
	"c5523a0f-b436-48b9-a89f-15e0267e2379");
INSERT INTO ACT_ACT
	VALUES ("e1f8423d-32c3-4833-babb-1f39208e1a7a",
	'interface operation',
	0,
	"ecfe387a-67c6-4638-8d5a-c990bba8ffce",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ecfe387a-67c6-4638-8d5a-c990bba8ffce",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"e1f8423d-32c3-4833-babb-1f39208e1a7a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	1,
	"d6c08bc7-df25-4898-bea8-769bd5ae2334",
	"00000000-0000-0000-0000-000000000000",
	2);
INSERT INTO C_C
	VALUES ("0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'Control',
	'',
	0,
	"00000000-0000-0000-0000-000000000000",
	0,
	'');
INSERT INTO C_PO
	VALUES ("bada52a0-1256-430d-8579-634b9c323fea",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	'Port1',
	0,
	0);
INSERT INTO C_IR
	VALUES ("33610dbc-6887-421d-81c6-740629675b3d",
	"78776ad7-dffd-4126-8217-a913ac6e4bc8",
	"00000000-0000-0000-0000-000000000000",
	"bada52a0-1256-430d-8579-634b9c323fea");
INSERT INTO C_R
	VALUES ("33610dbc-6887-421d-81c6-740629675b3d",
	'mavcontrol',
	'',
	'Unnamed Interface',
	'Control::Port1::mavcontrol');
INSERT INTO SPR_REP
	VALUES ("e84f3860-934a-4425-83e4-2c5983065d6e",
	"b00324c5-e272-4a60-96b2-1a40dbbdea3e",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("e84f3860-934a-4425-83e4-2c5983065d6e",
	'init',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("25627feb-c2b9-4217-b355-9ab913d9e7ac",
	"e84f3860-934a-4425-83e4-2c5983065d6e");
INSERT INTO ACT_ACT
	VALUES ("25627feb-c2b9-4217-b355-9ab913d9e7ac",
	'interface operation',
	0,
	"6f2f18cd-2da7-4c6e-abd8-a144d17a028d",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6f2f18cd-2da7-4c6e-abd8-a144d17a028d",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"25627feb-c2b9-4217-b355-9ab913d9e7ac",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("786f401b-dc06-4f89-95d6-805158b17282",
	"7642e709-1eb0-4ab6-86f5-a945e4e95c17",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("786f401b-dc06-4f89-95d6-805158b17282",
	'takeoff',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("bcb4c832-c325-4784-b1b2-c3338ab8b434",
	"786f401b-dc06-4f89-95d6-805158b17282");
INSERT INTO ACT_ACT
	VALUES ("bcb4c832-c325-4784-b1b2-c3338ab8b434",
	'interface operation',
	0,
	"8e6b57ba-30fa-4fa0-979c-66710d2b9847",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::takeoff',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8e6b57ba-30fa-4fa0-979c-66710d2b9847",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"bcb4c832-c325-4784-b1b2-c3338ab8b434",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("ea4468fa-4b20-4012-8e54-d298c549ee90",
	"37d0542f-1ab7-4216-b4a8-2c23dffc0456",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("ea4468fa-4b20-4012-8e54-d298c549ee90",
	'land',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("6035056c-a098-481b-b4d8-dbd652734d76",
	"ea4468fa-4b20-4012-8e54-d298c549ee90");
INSERT INTO ACT_ACT
	VALUES ("6035056c-a098-481b-b4d8-dbd652734d76",
	'interface operation',
	0,
	"b1e3604f-e556-4bf3-9f59-abf18d24c168",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b1e3604f-e556-4bf3-9f59-abf18d24c168",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6035056c-a098-481b-b4d8-dbd652734d76",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("94117eda-9f0d-4f5e-af02-0148334dd3a9",
	"c53d4966-9097-4e62-8e45-bb3b7522378a",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("94117eda-9f0d-4f5e-af02-0148334dd3a9",
	'arm',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("6c24257f-f43e-4197-a823-06a16c0f0c9c",
	"94117eda-9f0d-4f5e-af02-0148334dd3a9");
INSERT INTO ACT_ACT
	VALUES ("6c24257f-f43e-4197-a823-06a16c0f0c9c",
	'interface operation',
	0,
	"35a6d21e-65a3-4239-8acd-44152da14488",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::arm',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("35a6d21e-65a3-4239-8acd-44152da14488",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6c24257f-f43e-4197-a823-06a16c0f0c9c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("0b7b0648-980a-4657-9783-453131e6af11",
	"248f2941-48bf-4a2e-99ad-74a5d3b2f279",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("0b7b0648-980a-4657-9783-453131e6af11",
	'set_destination',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("c1d44ac8-fb4e-4c7a-b48c-9501f3855bee",
	"0b7b0648-980a-4657-9783-453131e6af11");
INSERT INTO ACT_ACT
	VALUES ("c1d44ac8-fb4e-4c7a-b48c-9501f3855bee",
	'interface operation',
	0,
	"856b4051-eb87-45fe-9e1b-ca0cc0b91dd6",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_destination',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("856b4051-eb87-45fe-9e1b-ca0cc0b91dd6",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"c1d44ac8-fb4e-4c7a-b48c-9501f3855bee",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"c4c94ad5-cb8c-4b6d-94fd-23aafcb1bc52",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("55afac66-d149-4d24-9466-0c4a6f48dcf5",
	'set_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("b5efbe76-f00a-46e9-a7dc-68696d7893f4",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5");
INSERT INTO ACT_ACT
	VALUES ("b5efbe76-f00a-46e9-a7dc-68696d7893f4",
	'interface operation',
	0,
	"8cb9e6fd-e168-4de5-ba89-930ad0f27b21",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::set_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("8cb9e6fd-e168-4de5-ba89-930ad0f27b21",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"b5efbe76-f00a-46e9-a7dc-68696d7893f4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("d3b00f4a-2ff0-4200-9566-b7eba7d85c94",
	"7576d5e0-2683-4a42-967a-ddb25a458620",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("d3b00f4a-2ff0-4200-9566-b7eba7d85c94",
	'get_heading',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("310a2c79-57a7-4e0f-81b2-d43218c32476",
	"d3b00f4a-2ff0-4200-9566-b7eba7d85c94");
INSERT INTO ACT_ACT
	VALUES ("310a2c79-57a7-4e0f-81b2-d43218c32476",
	'interface operation',
	0,
	"57066228-6409-40b4-bd5b-be64cfc39898",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::get_heading',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("57066228-6409-40b4-bd5b-be64cfc39898",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"310a2c79-57a7-4e0f-81b2-d43218c32476",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SPR_REP
	VALUES ("f864983a-f5f2-4a40-ae2f-8dbaf0842d15",
	"e2e61698-b9dc-4911-95c7-79872095f0dd",
	"33610dbc-6887-421d-81c6-740629675b3d");
INSERT INTO SPR_RO
	VALUES ("f864983a-f5f2-4a40-ae2f-8dbaf0842d15",
	'ready',
	'',
	'select any ctrl from Controller;
generate Controller2:''ready'' to ctrl;
',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES ("ec928d61-05b2-4f2d-b372-b0059a834dce",
	"f864983a-f5f2-4a40-ae2f-8dbaf0842d15");
INSERT INTO ACT_ACT
	VALUES ("ec928d61-05b2-4f2d-b372-b0059a834dce",
	'interface operation',
	0,
	"ad593f6c-24ea-45fe-aca1-a9e91ed62c2d",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Port1::mavcontrol::ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ad593f6c-24ea-45fe-aca1-a9e91ed62c2d",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	22,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"ec928d61-05b2-4f2d-b372-b0059a834dce",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("0812e9af-4327-490e-941b-2e0d313f0071",
	"ad593f6c-24ea-45fe-aca1-a9e91ed62c2d",
	"6e50861c-3ed9-47b2-88e7-84771c2724ef",
	1,
	1,
	'Port1::mavcontrol::ready line: 1');
INSERT INTO ACT_FIO
	VALUES ("0812e9af-4327-490e-941b-2e0d313f0071",
	"f626010c-2054-4d83-ab10-5062a0c04a02",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	22);
INSERT INTO ACT_SMT
	VALUES ("6e50861c-3ed9-47b2-88e7-84771c2724ef",
	"ad593f6c-24ea-45fe-aca1-a9e91ed62c2d",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Port1::mavcontrol::ready line: 2');
INSERT INTO E_ESS
	VALUES ("6e50861c-3ed9-47b2-88e7-84771c2724ef",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	22,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("6e50861c-3ed9-47b2-88e7-84771c2724ef");
INSERT INTO E_GSME
	VALUES ("6e50861c-3ed9-47b2-88e7-84771c2724ef",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c");
INSERT INTO E_GEN
	VALUES ("6e50861c-3ed9-47b2-88e7-84771c2724ef",
	"f626010c-2054-4d83-ab10-5062a0c04a02");
INSERT INTO V_VAR
	VALUES ("f626010c-2054-4d83-ab10-5062a0c04a02",
	"ad593f6c-24ea-45fe-aca1-a9e91ed62c2d",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("f626010c-2054-4d83-ab10-5062a0c04a02",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	1,
	"00000000-0000-0000-0000-000000000000",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	7);
INSERT INTO EP_PKG
	VALUES ("c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Functions',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("6da296e0-cfc3-41ea-b021-54b367d07943",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("6da296e0-cfc3-41ea-b021-54b367d07943",
	"00000000-0000-0000-0000-000000000000",
	'setup',
	'',
	'create object instance ctrl of Controller;

create object instance wp1 of Waypoint;
wp1.x = 0;
wp1.y = 0;
wp1.z = 15;
relate ctrl to wp1 across R1.''begin with'';
relate ctrl to wp1 across R3.''is flying to'';

create object instance wp2 of Waypoint;
wp2.x = 51;
wp2.y = 38;
wp2.z = 15;
relate wp1 to wp2 across R2.''follows'';

create object instance wp3 of Waypoint;
wp3.x = 131;
wp3.y = 38;
wp3.z = 15;
relate wp2 to wp3 across R2.''follows'';

create object instance wp4 of Waypoint;
wp4.x = 51;
wp4.y = 18;
wp4.z = 15;
relate wp3 to wp4 across R2.''follows'';

create object instance wp5 of Waypoint;
wp5.x = 91;
wp5.y = 18;
wp5.z = 15;
relate wp4 to wp5 across R2.''follows'';

create object instance wp6 of Waypoint;
wp6.x = 51;
wp6.y = -2;
wp6.z = 15;
relate wp5 to wp6 across R2.''follows'';

create object instance wp7 of Waypoint;
wp7.x = 131;
wp7.y = -2;
wp7.z = 15;
relate wp6 to wp7 across R2.''follows'';

create object instance wp8 of Waypoint;
wp8.x = 51;
wp8.y = -22;
wp8.z = 15;
relate wp7 to wp8 across R2.''follows'';

create object instance wp9 of Waypoint;
wp9.x = 91;
wp9.y = -22;
wp9.z = 15;
relate wp8 to wp9 across R2.''follows'';

create object instance wp10 of Waypoint;
wp10.x = 131;
wp10.y = -22;
wp10.z = 15;
relate wp9 to wp10 across R2.''follows'';

create object instance wp11 of Waypoint;
wp11.x = 0;
wp11.y = 0;
wp11.z = 15;
relate wp10 to wp11 across R2.''follows'';


',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("886fb4fd-becd-41f7-bfc8-f6361b364b39",
	"6da296e0-cfc3-41ea-b021-54b367d07943");
INSERT INTO ACT_ACT
	VALUES ("886fb4fd-becd-41f7-bfc8-f6361b364b39",
	'function',
	0,
	"055893bd-f15d-4386-a68d-f115041a8736",
	"00000000-0000-0000-0000-000000000000",
	0,
	'setup',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("055893bd-f15d-4386-a68d-f115041a8736",
	0,
	0,
	0,
	'''follows''',
	'',
	'',
	68,
	1,
	64,
	32,
	0,
	0,
	68,
	28,
	68,
	31,
	0,
	0,
	0,
	"886fb4fd-becd-41f7-bfc8-f6361b364b39",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("949c7712-a75e-4840-b6c9-e8610566f9a2",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"a604d41a-1201-48ec-9c64-69822973e4d2",
	1,
	1,
	'setup line: 1');
INSERT INTO ACT_CR
	VALUES ("949c7712-a75e-4840-b6c9-e8610566f9a2",
	"18f8fe3a-a430-431e-8236-014cb460f9b8",
	1,
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	32);
INSERT INTO ACT_SMT
	VALUES ("a604d41a-1201-48ec-9c64-69822973e4d2",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"de4f7cc8-a034-486f-87bd-8a63ce52d388",
	3,
	1,
	'setup line: 3');
INSERT INTO ACT_CR
	VALUES ("a604d41a-1201-48ec-9c64-69822973e4d2",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	3,
	31);
INSERT INTO ACT_SMT
	VALUES ("de4f7cc8-a034-486f-87bd-8a63ce52d388",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"4b3e6e15-2597-4eed-91d9-1d8be998b48d",
	4,
	1,
	'setup line: 4');
INSERT INTO ACT_AI
	VALUES ("de4f7cc8-a034-486f-87bd-8a63ce52d388",
	"4cf53f36-ca67-4ea7-8d4e-787fc6a17369",
	"deada7b3-9a78-477d-9f5c-e6d49dd6e331",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("4b3e6e15-2597-4eed-91d9-1d8be998b48d",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"5136769b-fc26-40ec-830a-a8e5c5bf1662",
	5,
	1,
	'setup line: 5');
INSERT INTO ACT_AI
	VALUES ("4b3e6e15-2597-4eed-91d9-1d8be998b48d",
	"f939d788-0d52-4e27-ab15-70018d5b3e10",
	"86c8f7e7-c696-4fc3-ae93-e8c3f49f407e",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("5136769b-fc26-40ec-830a-a8e5c5bf1662",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"8e237fe3-68b2-488f-b397-228bbf6dc1ef",
	6,
	1,
	'setup line: 6');
INSERT INTO ACT_AI
	VALUES ("5136769b-fc26-40ec-830a-a8e5c5bf1662",
	"658d08c3-eeb3-4c6b-ba49-bc81ad16c901",
	"8877b341-1aaf-42c2-bb92-d1a5439088c2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8e237fe3-68b2-488f-b397-228bbf6dc1ef",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"d015fcf4-9370-4fa7-b081-dc9e7b4c9f2b",
	7,
	1,
	'setup line: 7');
INSERT INTO ACT_REL
	VALUES ("8e237fe3-68b2-488f-b397-228bbf6dc1ef",
	"18f8fe3a-a430-431e-8236-014cb460f9b8",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07",
	'''begin with''',
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	7,
	27,
	7,
	30);
INSERT INTO ACT_SMT
	VALUES ("d015fcf4-9370-4fa7-b081-dc9e7b4c9f2b",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"768d5203-bfdd-4b2f-aa88-ac2f24b2f409",
	8,
	1,
	'setup line: 8');
INSERT INTO ACT_REL
	VALUES ("d015fcf4-9370-4fa7-b081-dc9e7b4c9f2b",
	"18f8fe3a-a430-431e-8236-014cb460f9b8",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07",
	'''is flying to''',
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	8,
	27,
	8,
	30);
INSERT INTO ACT_SMT
	VALUES ("768d5203-bfdd-4b2f-aa88-ac2f24b2f409",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"12bf8a44-4fbf-4cc2-bb57-e30959b002fb",
	10,
	1,
	'setup line: 10');
INSERT INTO ACT_CR
	VALUES ("768d5203-bfdd-4b2f-aa88-ac2f24b2f409",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	10,
	31);
INSERT INTO ACT_SMT
	VALUES ("12bf8a44-4fbf-4cc2-bb57-e30959b002fb",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"8bc33642-7e81-4e2a-b6c1-35fa0e800f88",
	11,
	1,
	'setup line: 11');
INSERT INTO ACT_AI
	VALUES ("12bf8a44-4fbf-4cc2-bb57-e30959b002fb",
	"db73609b-015c-4df5-a7f4-419adb5794eb",
	"34a3907b-4b50-491d-8b92-4b843bacc68f",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8bc33642-7e81-4e2a-b6c1-35fa0e800f88",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"c44dbbc9-2e83-4a37-9649-f2d07d5ef288",
	12,
	1,
	'setup line: 12');
INSERT INTO ACT_AI
	VALUES ("8bc33642-7e81-4e2a-b6c1-35fa0e800f88",
	"b7bbea93-78a8-4cc7-8636-43ebce6bbfba",
	"df0dd3b6-03c3-4247-ad86-a4de3c5c9586",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c44dbbc9-2e83-4a37-9649-f2d07d5ef288",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"ec13bfcf-07fe-4a73-b42f-8b784407f6cc",
	13,
	1,
	'setup line: 13');
INSERT INTO ACT_AI
	VALUES ("c44dbbc9-2e83-4a37-9649-f2d07d5ef288",
	"d3bf60f9-66ba-4f53-9c6f-f19dbe3b42ca",
	"19c86775-61f9-4561-8e46-2142c23e2976",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ec13bfcf-07fe-4a73-b42f-8b784407f6cc",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"3353f6af-2551-40a2-8013-83f5aa47a727",
	14,
	1,
	'setup line: 14');
INSERT INTO ACT_REL
	VALUES ("ec13bfcf-07fe-4a73-b42f-8b784407f6cc",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	14,
	26,
	14,
	29);
INSERT INTO ACT_SMT
	VALUES ("3353f6af-2551-40a2-8013-83f5aa47a727",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"8b63ca5e-d4ba-4cd0-b7fa-86f577cf08c1",
	16,
	1,
	'setup line: 16');
INSERT INTO ACT_CR
	VALUES ("3353f6af-2551-40a2-8013-83f5aa47a727",
	"b933a417-eaa2-40d3-94d2-f96087887d65",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	16,
	31);
INSERT INTO ACT_SMT
	VALUES ("8b63ca5e-d4ba-4cd0-b7fa-86f577cf08c1",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"692691a1-8d09-443d-b3e1-a76da88edfe9",
	17,
	1,
	'setup line: 17');
INSERT INTO ACT_AI
	VALUES ("8b63ca5e-d4ba-4cd0-b7fa-86f577cf08c1",
	"c74b4aea-bd7c-4b63-a33a-df0f89bcdac6",
	"86d13376-7ec1-4eab-b4c2-c1b40c893f16",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("692691a1-8d09-443d-b3e1-a76da88edfe9",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"72b693cd-fc84-4d66-bbe1-9c7a6e3aff41",
	18,
	1,
	'setup line: 18');
INSERT INTO ACT_AI
	VALUES ("692691a1-8d09-443d-b3e1-a76da88edfe9",
	"6e6e3641-6037-4228-a226-7c2222ae6684",
	"5e6ac942-a8e0-429c-9be9-923f5c869f00",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("72b693cd-fc84-4d66-bbe1-9c7a6e3aff41",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"a2a0990a-dede-4629-819f-b310804e7c92",
	19,
	1,
	'setup line: 19');
INSERT INTO ACT_AI
	VALUES ("72b693cd-fc84-4d66-bbe1-9c7a6e3aff41",
	"d6f4cc5f-5abd-4353-bd6d-17204e7cdad5",
	"b7f5e4cd-8ad9-458a-b676-0952446948ad",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("a2a0990a-dede-4629-819f-b310804e7c92",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"1f9920d6-6a4b-4541-9c5a-e2ca2637005a",
	20,
	1,
	'setup line: 20');
INSERT INTO ACT_REL
	VALUES ("a2a0990a-dede-4629-819f-b310804e7c92",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5",
	"b933a417-eaa2-40d3-94d2-f96087887d65",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	20,
	26,
	20,
	29);
INSERT INTO ACT_SMT
	VALUES ("1f9920d6-6a4b-4541-9c5a-e2ca2637005a",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"69463347-59a1-4167-9740-52fc9c789382",
	22,
	1,
	'setup line: 22');
INSERT INTO ACT_CR
	VALUES ("1f9920d6-6a4b-4541-9c5a-e2ca2637005a",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	22,
	31);
INSERT INTO ACT_SMT
	VALUES ("69463347-59a1-4167-9740-52fc9c789382",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"060f78ac-e2de-487c-a7b8-7fa3911398a0",
	23,
	1,
	'setup line: 23');
INSERT INTO ACT_AI
	VALUES ("69463347-59a1-4167-9740-52fc9c789382",
	"df33b5f6-25b9-4809-b6ef-1c244c8ec648",
	"b7e9052d-ec7e-4ecd-b67e-9094b5345384",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("060f78ac-e2de-487c-a7b8-7fa3911398a0",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"103c37c9-5c20-4448-b3ad-be5c8d354915",
	24,
	1,
	'setup line: 24');
INSERT INTO ACT_AI
	VALUES ("060f78ac-e2de-487c-a7b8-7fa3911398a0",
	"8c00d7df-2b61-42cb-b1bc-c65448d1e673",
	"fdc065b0-be35-4190-a50c-f8984620437a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("103c37c9-5c20-4448-b3ad-be5c8d354915",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"492a2dc5-0f86-49ca-aa7f-35e16ab45a7b",
	25,
	1,
	'setup line: 25');
INSERT INTO ACT_AI
	VALUES ("103c37c9-5c20-4448-b3ad-be5c8d354915",
	"18f0ae01-9a37-4c23-bfb9-740cacd9de94",
	"dae60b90-e9c0-41d0-9ea4-5090f9cbc6e0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("492a2dc5-0f86-49ca-aa7f-35e16ab45a7b",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"ae597ffa-2b66-416c-b89e-bc7e7e03f9ad",
	26,
	1,
	'setup line: 26');
INSERT INTO ACT_REL
	VALUES ("492a2dc5-0f86-49ca-aa7f-35e16ab45a7b",
	"b933a417-eaa2-40d3-94d2-f96087887d65",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	26,
	26,
	26,
	29);
INSERT INTO ACT_SMT
	VALUES ("ae597ffa-2b66-416c-b89e-bc7e7e03f9ad",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"131920ce-1bf7-4623-8f19-daebdd28e191",
	28,
	1,
	'setup line: 28');
INSERT INTO ACT_CR
	VALUES ("ae597ffa-2b66-416c-b89e-bc7e7e03f9ad",
	"5e63fe68-06dd-445b-a287-872e853d1639",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	28,
	31);
INSERT INTO ACT_SMT
	VALUES ("131920ce-1bf7-4623-8f19-daebdd28e191",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"f4b2207c-64c3-4fb4-aa24-3f60911f56b3",
	29,
	1,
	'setup line: 29');
INSERT INTO ACT_AI
	VALUES ("131920ce-1bf7-4623-8f19-daebdd28e191",
	"00dd7699-e447-4021-acbf-a3f3502fb7d0",
	"d17a541c-e651-4750-b29e-d6d9bc061952",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f4b2207c-64c3-4fb4-aa24-3f60911f56b3",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"48e7a606-a762-416d-b0d4-7dc9df93cde2",
	30,
	1,
	'setup line: 30');
INSERT INTO ACT_AI
	VALUES ("f4b2207c-64c3-4fb4-aa24-3f60911f56b3",
	"dbbaefcb-f98e-4e73-81f9-64d64278b027",
	"17229e1f-735f-486f-8267-ec84ced7888b",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("48e7a606-a762-416d-b0d4-7dc9df93cde2",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"f46bd8dd-b9f3-43ef-8a61-8d3b180745dc",
	31,
	1,
	'setup line: 31');
INSERT INTO ACT_AI
	VALUES ("48e7a606-a762-416d-b0d4-7dc9df93cde2",
	"ef5629d9-2b8e-40ed-a03e-e1fd09bff271",
	"caebd550-9148-44da-84c4-364bb6456d83",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("f46bd8dd-b9f3-43ef-8a61-8d3b180745dc",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"2063dd1d-8c81-49e4-b4a3-b8f9f530b554",
	32,
	1,
	'setup line: 32');
INSERT INTO ACT_REL
	VALUES ("f46bd8dd-b9f3-43ef-8a61-8d3b180745dc",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927",
	"5e63fe68-06dd-445b-a287-872e853d1639",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	32,
	26,
	32,
	29);
INSERT INTO ACT_SMT
	VALUES ("2063dd1d-8c81-49e4-b4a3-b8f9f530b554",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"6dde0630-6704-4975-a331-000f1aaa2594",
	34,
	1,
	'setup line: 34');
INSERT INTO ACT_CR
	VALUES ("2063dd1d-8c81-49e4-b4a3-b8f9f530b554",
	"2b899854-7a52-457e-9405-d68d6267b089",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	34,
	31);
INSERT INTO ACT_SMT
	VALUES ("6dde0630-6704-4975-a331-000f1aaa2594",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"77c5624f-bf8a-4481-85f3-dbeee3145c89",
	35,
	1,
	'setup line: 35');
INSERT INTO ACT_AI
	VALUES ("6dde0630-6704-4975-a331-000f1aaa2594",
	"0a25bc24-e4da-402c-b0dc-4bce96d348db",
	"f31f7a0f-7ca7-4546-82bd-db497e46a7f6",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("77c5624f-bf8a-4481-85f3-dbeee3145c89",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"c3aa9c99-cc2c-4ea1-82cf-4cc17147e3fd",
	36,
	1,
	'setup line: 36');
INSERT INTO ACT_AI
	VALUES ("77c5624f-bf8a-4481-85f3-dbeee3145c89",
	"62683c27-c26a-4c5a-8ee6-3ee4ca971534",
	"6a773429-a322-4e7e-bd5b-bcd72fd386cc",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("c3aa9c99-cc2c-4ea1-82cf-4cc17147e3fd",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"8067a1d1-24f3-435b-b944-78e09212b5dc",
	37,
	1,
	'setup line: 37');
INSERT INTO ACT_AI
	VALUES ("c3aa9c99-cc2c-4ea1-82cf-4cc17147e3fd",
	"870ed389-7c35-4d40-9b24-d29f4a90c120",
	"c99023e8-059b-45e7-903a-97c6c64ccc31",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("8067a1d1-24f3-435b-b944-78e09212b5dc",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"833927fd-4764-4be6-a468-64f30839a9c4",
	38,
	1,
	'setup line: 38');
INSERT INTO ACT_REL
	VALUES ("8067a1d1-24f3-435b-b944-78e09212b5dc",
	"5e63fe68-06dd-445b-a287-872e853d1639",
	"2b899854-7a52-457e-9405-d68d6267b089",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	38,
	26,
	38,
	29);
INSERT INTO ACT_SMT
	VALUES ("833927fd-4764-4be6-a468-64f30839a9c4",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"7230505f-c5f8-4c3f-b651-c5600ec1acd6",
	40,
	1,
	'setup line: 40');
INSERT INTO ACT_CR
	VALUES ("833927fd-4764-4be6-a468-64f30839a9c4",
	"9e40927e-4f65-45a3-967d-8332826852c9",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	40,
	31);
INSERT INTO ACT_SMT
	VALUES ("7230505f-c5f8-4c3f-b651-c5600ec1acd6",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"26a79032-5bc7-47d8-b342-82128a1331e6",
	41,
	1,
	'setup line: 41');
INSERT INTO ACT_AI
	VALUES ("7230505f-c5f8-4c3f-b651-c5600ec1acd6",
	"cc0ceb8b-2d33-4cf7-b8f3-2d75079dce15",
	"63480a46-776d-498f-aa54-c403bffde5fb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("26a79032-5bc7-47d8-b342-82128a1331e6",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"e809d619-7a1e-467c-a47e-4c7005869446",
	42,
	1,
	'setup line: 42');
INSERT INTO ACT_AI
	VALUES ("26a79032-5bc7-47d8-b342-82128a1331e6",
	"5491af06-4270-462a-9943-f139c25c10bd",
	"6c7d268b-adc2-4ce1-95d4-a631d6ed47f2",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e809d619-7a1e-467c-a47e-4c7005869446",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"e7495e85-6d7d-4530-962f-218e178cbd8e",
	43,
	1,
	'setup line: 43');
INSERT INTO ACT_AI
	VALUES ("e809d619-7a1e-467c-a47e-4c7005869446",
	"ccaea442-3e7b-450a-89d5-91ea381f1d29",
	"b68273c1-e889-4cd8-8bd0-1a787aac2385",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("e7495e85-6d7d-4530-962f-218e178cbd8e",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"9f4b4459-8211-4030-8548-28d529f10570",
	44,
	1,
	'setup line: 44');
INSERT INTO ACT_REL
	VALUES ("e7495e85-6d7d-4530-962f-218e178cbd8e",
	"2b899854-7a52-457e-9405-d68d6267b089",
	"9e40927e-4f65-45a3-967d-8332826852c9",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	44,
	26,
	44,
	29);
INSERT INTO ACT_SMT
	VALUES ("9f4b4459-8211-4030-8548-28d529f10570",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"8a9c8cce-276e-4500-9704-bdc890287b59",
	46,
	1,
	'setup line: 46');
INSERT INTO ACT_CR
	VALUES ("9f4b4459-8211-4030-8548-28d529f10570",
	"b9e09c36-cd04-4217-87d5-60c98608fbec",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	46,
	31);
INSERT INTO ACT_SMT
	VALUES ("8a9c8cce-276e-4500-9704-bdc890287b59",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"faf0241f-9d8e-4a25-8afa-e4637dd3ded3",
	47,
	1,
	'setup line: 47');
INSERT INTO ACT_AI
	VALUES ("8a9c8cce-276e-4500-9704-bdc890287b59",
	"9bbb815d-4a25-4f54-bb9e-8f3b3c7dae58",
	"02086fa3-4473-404a-8c93-1d4c7e512c67",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("faf0241f-9d8e-4a25-8afa-e4637dd3ded3",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"ebd340d4-444a-42a5-8cfa-9439594b3b91",
	48,
	1,
	'setup line: 48');
INSERT INTO ACT_AI
	VALUES ("faf0241f-9d8e-4a25-8afa-e4637dd3ded3",
	"f59578ac-a7dd-4311-bf9c-2e0792352e94",
	"0a79c303-7126-44ec-8b67-5a7ab4859cd0",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("ebd340d4-444a-42a5-8cfa-9439594b3b91",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"67cdf7d3-9857-4551-9269-c05e78f4ba39",
	49,
	1,
	'setup line: 49');
INSERT INTO ACT_AI
	VALUES ("ebd340d4-444a-42a5-8cfa-9439594b3b91",
	"78b6feb1-1b79-4804-8cec-6e55eb38eb22",
	"3bf1527c-08bf-4fcd-baaf-312f736b2b63",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("67cdf7d3-9857-4551-9269-c05e78f4ba39",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"3a94f2e5-18f9-43be-95d6-c07ace502733",
	50,
	1,
	'setup line: 50');
INSERT INTO ACT_REL
	VALUES ("67cdf7d3-9857-4551-9269-c05e78f4ba39",
	"9e40927e-4f65-45a3-967d-8332826852c9",
	"b9e09c36-cd04-4217-87d5-60c98608fbec",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	50,
	26,
	50,
	29);
INSERT INTO ACT_SMT
	VALUES ("3a94f2e5-18f9-43be-95d6-c07ace502733",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"4c9fcdc9-230f-45f8-99a6-6cfbc76bb7a2",
	52,
	1,
	'setup line: 52');
INSERT INTO ACT_CR
	VALUES ("3a94f2e5-18f9-43be-95d6-c07ace502733",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	52,
	31);
INSERT INTO ACT_SMT
	VALUES ("4c9fcdc9-230f-45f8-99a6-6cfbc76bb7a2",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"58139faa-7fed-4fa1-8f4e-b6e2995d9d6a",
	53,
	1,
	'setup line: 53');
INSERT INTO ACT_AI
	VALUES ("4c9fcdc9-230f-45f8-99a6-6cfbc76bb7a2",
	"1b036bab-4622-48a8-b808-f76e6ea565a6",
	"a8d36786-e784-46ef-a9fa-6f2f55cc800d",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("58139faa-7fed-4fa1-8f4e-b6e2995d9d6a",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"0308ca3b-ccac-4d90-a66b-db353893a4b9",
	54,
	1,
	'setup line: 54');
INSERT INTO ACT_AI
	VALUES ("58139faa-7fed-4fa1-8f4e-b6e2995d9d6a",
	"434d8e03-f138-4048-9fe7-e44f774f7ab0",
	"9f8db2ad-3bda-4ec3-82ab-9826b6931dfb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("0308ca3b-ccac-4d90-a66b-db353893a4b9",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"7dffb90f-566d-4ee6-87f9-0e69f174575b",
	55,
	1,
	'setup line: 55');
INSERT INTO ACT_AI
	VALUES ("0308ca3b-ccac-4d90-a66b-db353893a4b9",
	"a71f65de-4f49-43bc-b87b-a58f526764c4",
	"f3e5ca00-44c6-44cd-a08a-20931a1b5591",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("7dffb90f-566d-4ee6-87f9-0e69f174575b",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"ace582c0-7e0b-4618-ba2e-07431c8f2ed6",
	56,
	1,
	'setup line: 56');
INSERT INTO ACT_REL
	VALUES ("7dffb90f-566d-4ee6-87f9-0e69f174575b",
	"b9e09c36-cd04-4217-87d5-60c98608fbec",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	56,
	26,
	56,
	29);
INSERT INTO ACT_SMT
	VALUES ("ace582c0-7e0b-4618-ba2e-07431c8f2ed6",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"06655bf9-8b08-4d7b-a263-804670bd564f",
	58,
	1,
	'setup line: 58');
INSERT INTO ACT_CR
	VALUES ("ace582c0-7e0b-4618-ba2e-07431c8f2ed6",
	"596ee8c9-4375-4235-b209-15e21ec40e89",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	58,
	32);
INSERT INTO ACT_SMT
	VALUES ("06655bf9-8b08-4d7b-a263-804670bd564f",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"9d3a8e24-863b-458f-bc3d-6312bb282634",
	59,
	1,
	'setup line: 59');
INSERT INTO ACT_AI
	VALUES ("06655bf9-8b08-4d7b-a263-804670bd564f",
	"1bddcdb3-383b-4533-8db4-640a74f45098",
	"bb04ceee-53f1-4d24-999b-ca82a5f52e9c",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("9d3a8e24-863b-458f-bc3d-6312bb282634",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"79dfe720-ca2a-4ec3-b771-e13aa0a78e9f",
	60,
	1,
	'setup line: 60');
INSERT INTO ACT_AI
	VALUES ("9d3a8e24-863b-458f-bc3d-6312bb282634",
	"9a6dc418-c7a5-4919-b7d4-825ba6b8ba2e",
	"a65e450a-ed7d-4398-81f5-f1a7f9cefd45",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("79dfe720-ca2a-4ec3-b771-e13aa0a78e9f",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"56b61d51-afda-470d-a9a9-79ee19481fcf",
	61,
	1,
	'setup line: 61');
INSERT INTO ACT_AI
	VALUES ("79dfe720-ca2a-4ec3-b771-e13aa0a78e9f",
	"43eb466e-052a-4c09-aa6b-5715b0bc7f62",
	"af56c400-fc48-47eb-ad52-b931a3c9b944",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("56b61d51-afda-470d-a9a9-79ee19481fcf",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"00aeba6c-5a23-49d5-a13f-5ce1d7104b66",
	62,
	1,
	'setup line: 62');
INSERT INTO ACT_REL
	VALUES ("56b61d51-afda-470d-a9a9-79ee19481fcf",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341",
	"596ee8c9-4375-4235-b209-15e21ec40e89",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	62,
	27,
	62,
	30);
INSERT INTO ACT_SMT
	VALUES ("00aeba6c-5a23-49d5-a13f-5ce1d7104b66",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"64b367d5-b1c7-40bc-b4b3-f0920d68d08a",
	64,
	1,
	'setup line: 64');
INSERT INTO ACT_CR
	VALUES ("00aeba6c-5a23-49d5-a13f-5ce1d7104b66",
	"7e54f006-8e59-43ed-a196-633ad471d51c",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	64,
	32);
INSERT INTO ACT_SMT
	VALUES ("64b367d5-b1c7-40bc-b4b3-f0920d68d08a",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"31938f67-1fce-4ceb-8207-9386d20f1932",
	65,
	1,
	'setup line: 65');
INSERT INTO ACT_AI
	VALUES ("64b367d5-b1c7-40bc-b4b3-f0920d68d08a",
	"cc4a9e98-0c37-45b6-b40e-1671dea5d140",
	"e01eafdc-e300-4e01-bb86-79c9663c317a",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("31938f67-1fce-4ceb-8207-9386d20f1932",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"487d38ac-e345-4575-9bf5-acbe0caccc8b",
	66,
	1,
	'setup line: 66');
INSERT INTO ACT_AI
	VALUES ("31938f67-1fce-4ceb-8207-9386d20f1932",
	"3a176a77-3d56-42dc-b26c-7534520f3ce1",
	"979bc858-4b3e-41d9-ad48-abc61d31723c",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("487d38ac-e345-4575-9bf5-acbe0caccc8b",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"dc07cf13-9965-4d34-8e9e-860eb51fa267",
	67,
	1,
	'setup line: 67');
INSERT INTO ACT_AI
	VALUES ("487d38ac-e345-4575-9bf5-acbe0caccc8b",
	"5d13033f-3d91-43ea-85d0-eec731ae50a6",
	"8eb5ab36-58c4-4855-b8c3-a9d74245eacb",
	0,
	0);
INSERT INTO ACT_SMT
	VALUES ("dc07cf13-9965-4d34-8e9e-860eb51fa267",
	"055893bd-f15d-4386-a68d-f115041a8736",
	"00000000-0000-0000-0000-000000000000",
	68,
	1,
	'setup line: 68');
INSERT INTO ACT_REL
	VALUES ("dc07cf13-9965-4d34-8e9e-860eb51fa267",
	"596ee8c9-4375-4235-b209-15e21ec40e89",
	"7e54f006-8e59-43ed-a196-633ad471d51c",
	'''follows''',
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	68,
	28,
	68,
	31);
INSERT INTO V_VAL
	VALUES ("d099314f-cca9-46df-bf9d-6a0ac5d65b97",
	1,
	0,
	4,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("d099314f-cca9-46df-bf9d-6a0ac5d65b97",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07");
INSERT INTO V_VAL
	VALUES ("deada7b3-9a78-477d-9f5c-e6d49dd6e331",
	1,
	0,
	4,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("deada7b3-9a78-477d-9f5c-e6d49dd6e331",
	"d099314f-cca9-46df-bf9d-6a0ac5d65b97",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("4cf53f36-ca67-4ea7-8d4e-787fc6a17369",
	0,
	0,
	4,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("4cf53f36-ca67-4ea7-8d4e-787fc6a17369",
	'0');
INSERT INTO V_VAL
	VALUES ("3bf08fcf-8536-4516-b2d5-2031b7cd5b24",
	1,
	0,
	5,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("3bf08fcf-8536-4516-b2d5-2031b7cd5b24",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07");
INSERT INTO V_VAL
	VALUES ("86c8f7e7-c696-4fc3-ae93-e8c3f49f407e",
	1,
	0,
	5,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("86c8f7e7-c696-4fc3-ae93-e8c3f49f407e",
	"3bf08fcf-8536-4516-b2d5-2031b7cd5b24",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("f939d788-0d52-4e27-ab15-70018d5b3e10",
	0,
	0,
	5,
	9,
	9,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("f939d788-0d52-4e27-ab15-70018d5b3e10",
	'0');
INSERT INTO V_VAL
	VALUES ("89cf02f2-aabb-4397-9dbb-cc2216464482",
	1,
	0,
	6,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("89cf02f2-aabb-4397-9dbb-cc2216464482",
	"7089ffdb-e785-49e8-bdc3-0137c9415b07");
INSERT INTO V_VAL
	VALUES ("8877b341-1aaf-42c2-bb92-d1a5439088c2",
	1,
	0,
	6,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("8877b341-1aaf-42c2-bb92-d1a5439088c2",
	"89cf02f2-aabb-4397-9dbb-cc2216464482",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("658d08c3-eeb3-4c6b-ba49-bc81ad16c901",
	0,
	0,
	6,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("658d08c3-eeb3-4c6b-ba49-bc81ad16c901",
	'15');
INSERT INTO V_VAL
	VALUES ("bb955e72-4c57-43b9-aee5-5f59161ccd3f",
	1,
	0,
	11,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("bb955e72-4c57-43b9-aee5-5f59161ccd3f",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5");
INSERT INTO V_VAL
	VALUES ("34a3907b-4b50-491d-8b92-4b843bacc68f",
	1,
	0,
	11,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("34a3907b-4b50-491d-8b92-4b843bacc68f",
	"bb955e72-4c57-43b9-aee5-5f59161ccd3f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("db73609b-015c-4df5-a7f4-419adb5794eb",
	0,
	0,
	11,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("db73609b-015c-4df5-a7f4-419adb5794eb",
	'51');
INSERT INTO V_VAL
	VALUES ("53fa6819-c1c1-408c-8b25-b7c5ebefc25c",
	1,
	0,
	12,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("53fa6819-c1c1-408c-8b25-b7c5ebefc25c",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5");
INSERT INTO V_VAL
	VALUES ("df0dd3b6-03c3-4247-ad86-a4de3c5c9586",
	1,
	0,
	12,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("df0dd3b6-03c3-4247-ad86-a4de3c5c9586",
	"53fa6819-c1c1-408c-8b25-b7c5ebefc25c",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("b7bbea93-78a8-4cc7-8636-43ebce6bbfba",
	0,
	0,
	12,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("b7bbea93-78a8-4cc7-8636-43ebce6bbfba",
	'38');
INSERT INTO V_VAL
	VALUES ("bca42a25-f321-4bd0-9488-98988b4aa1c8",
	1,
	0,
	13,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("bca42a25-f321-4bd0-9488-98988b4aa1c8",
	"f9613d44-8688-432f-9a7c-8dc48f237dc5");
INSERT INTO V_VAL
	VALUES ("19c86775-61f9-4561-8e46-2142c23e2976",
	1,
	0,
	13,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("19c86775-61f9-4561-8e46-2142c23e2976",
	"bca42a25-f321-4bd0-9488-98988b4aa1c8",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("d3bf60f9-66ba-4f53-9c6f-f19dbe3b42ca",
	0,
	0,
	13,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("d3bf60f9-66ba-4f53-9c6f-f19dbe3b42ca",
	'15');
INSERT INTO V_VAL
	VALUES ("56ad840f-9537-4241-b00d-13cb14c11b0a",
	1,
	0,
	17,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("56ad840f-9537-4241-b00d-13cb14c11b0a",
	"b933a417-eaa2-40d3-94d2-f96087887d65");
INSERT INTO V_VAL
	VALUES ("86d13376-7ec1-4eab-b4c2-c1b40c893f16",
	1,
	0,
	17,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("86d13376-7ec1-4eab-b4c2-c1b40c893f16",
	"56ad840f-9537-4241-b00d-13cb14c11b0a",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("c74b4aea-bd7c-4b63-a33a-df0f89bcdac6",
	0,
	0,
	17,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("c74b4aea-bd7c-4b63-a33a-df0f89bcdac6",
	'131');
INSERT INTO V_VAL
	VALUES ("437bf437-9723-4349-8e83-bb864b7654ce",
	1,
	0,
	18,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("437bf437-9723-4349-8e83-bb864b7654ce",
	"b933a417-eaa2-40d3-94d2-f96087887d65");
INSERT INTO V_VAL
	VALUES ("5e6ac942-a8e0-429c-9be9-923f5c869f00",
	1,
	0,
	18,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("5e6ac942-a8e0-429c-9be9-923f5c869f00",
	"437bf437-9723-4349-8e83-bb864b7654ce",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("6e6e3641-6037-4228-a226-7c2222ae6684",
	0,
	0,
	18,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("6e6e3641-6037-4228-a226-7c2222ae6684",
	'38');
INSERT INTO V_VAL
	VALUES ("2f7cdfeb-99cf-4a10-9f85-4876ab33c54f",
	1,
	0,
	19,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("2f7cdfeb-99cf-4a10-9f85-4876ab33c54f",
	"b933a417-eaa2-40d3-94d2-f96087887d65");
INSERT INTO V_VAL
	VALUES ("b7f5e4cd-8ad9-458a-b676-0952446948ad",
	1,
	0,
	19,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("b7f5e4cd-8ad9-458a-b676-0952446948ad",
	"2f7cdfeb-99cf-4a10-9f85-4876ab33c54f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("d6f4cc5f-5abd-4353-bd6d-17204e7cdad5",
	0,
	0,
	19,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("d6f4cc5f-5abd-4353-bd6d-17204e7cdad5",
	'15');
INSERT INTO V_VAL
	VALUES ("35fb4e8c-a707-489e-9546-21f1169ec09e",
	1,
	0,
	23,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("35fb4e8c-a707-489e-9546-21f1169ec09e",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927");
INSERT INTO V_VAL
	VALUES ("b7e9052d-ec7e-4ecd-b67e-9094b5345384",
	1,
	0,
	23,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("b7e9052d-ec7e-4ecd-b67e-9094b5345384",
	"35fb4e8c-a707-489e-9546-21f1169ec09e",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("df33b5f6-25b9-4809-b6ef-1c244c8ec648",
	0,
	0,
	23,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("df33b5f6-25b9-4809-b6ef-1c244c8ec648",
	'51');
INSERT INTO V_VAL
	VALUES ("c5164ab1-bcf1-48b2-bc13-ff49124ef2f9",
	1,
	0,
	24,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("c5164ab1-bcf1-48b2-bc13-ff49124ef2f9",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927");
INSERT INTO V_VAL
	VALUES ("fdc065b0-be35-4190-a50c-f8984620437a",
	1,
	0,
	24,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("fdc065b0-be35-4190-a50c-f8984620437a",
	"c5164ab1-bcf1-48b2-bc13-ff49124ef2f9",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("8c00d7df-2b61-42cb-b1bc-c65448d1e673",
	0,
	0,
	24,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("8c00d7df-2b61-42cb-b1bc-c65448d1e673",
	'18');
INSERT INTO V_VAL
	VALUES ("5aca5059-1216-49c3-bfb9-b128605e6e69",
	1,
	0,
	25,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("5aca5059-1216-49c3-bfb9-b128605e6e69",
	"480c5b0b-d964-4f18-bea9-c549c1c7f927");
INSERT INTO V_VAL
	VALUES ("dae60b90-e9c0-41d0-9ea4-5090f9cbc6e0",
	1,
	0,
	25,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("dae60b90-e9c0-41d0-9ea4-5090f9cbc6e0",
	"5aca5059-1216-49c3-bfb9-b128605e6e69",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("18f0ae01-9a37-4c23-bfb9-740cacd9de94",
	0,
	0,
	25,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("18f0ae01-9a37-4c23-bfb9-740cacd9de94",
	'15');
INSERT INTO V_VAL
	VALUES ("08211610-e22a-402e-a2ed-018ad548943b",
	1,
	0,
	29,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("08211610-e22a-402e-a2ed-018ad548943b",
	"5e63fe68-06dd-445b-a287-872e853d1639");
INSERT INTO V_VAL
	VALUES ("d17a541c-e651-4750-b29e-d6d9bc061952",
	1,
	0,
	29,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("d17a541c-e651-4750-b29e-d6d9bc061952",
	"08211610-e22a-402e-a2ed-018ad548943b",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("00dd7699-e447-4021-acbf-a3f3502fb7d0",
	0,
	0,
	29,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("00dd7699-e447-4021-acbf-a3f3502fb7d0",
	'91');
INSERT INTO V_VAL
	VALUES ("9b9ef7c1-5a14-48e3-85f8-3d0f307f73f2",
	1,
	0,
	30,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("9b9ef7c1-5a14-48e3-85f8-3d0f307f73f2",
	"5e63fe68-06dd-445b-a287-872e853d1639");
INSERT INTO V_VAL
	VALUES ("17229e1f-735f-486f-8267-ec84ced7888b",
	1,
	0,
	30,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("17229e1f-735f-486f-8267-ec84ced7888b",
	"9b9ef7c1-5a14-48e3-85f8-3d0f307f73f2",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("dbbaefcb-f98e-4e73-81f9-64d64278b027",
	0,
	0,
	30,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("dbbaefcb-f98e-4e73-81f9-64d64278b027",
	'18');
INSERT INTO V_VAL
	VALUES ("c5d9365c-54a1-4720-b8b8-7a0542387faf",
	1,
	0,
	31,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("c5d9365c-54a1-4720-b8b8-7a0542387faf",
	"5e63fe68-06dd-445b-a287-872e853d1639");
INSERT INTO V_VAL
	VALUES ("caebd550-9148-44da-84c4-364bb6456d83",
	1,
	0,
	31,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("caebd550-9148-44da-84c4-364bb6456d83",
	"c5d9365c-54a1-4720-b8b8-7a0542387faf",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("ef5629d9-2b8e-40ed-a03e-e1fd09bff271",
	0,
	0,
	31,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("ef5629d9-2b8e-40ed-a03e-e1fd09bff271",
	'15');
INSERT INTO V_VAL
	VALUES ("404b11b2-f974-466c-b7e7-e066530a30c8",
	1,
	0,
	35,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("404b11b2-f974-466c-b7e7-e066530a30c8",
	"2b899854-7a52-457e-9405-d68d6267b089");
INSERT INTO V_VAL
	VALUES ("f31f7a0f-7ca7-4546-82bd-db497e46a7f6",
	1,
	0,
	35,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("f31f7a0f-7ca7-4546-82bd-db497e46a7f6",
	"404b11b2-f974-466c-b7e7-e066530a30c8",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("0a25bc24-e4da-402c-b0dc-4bce96d348db",
	0,
	0,
	35,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("0a25bc24-e4da-402c-b0dc-4bce96d348db",
	'51');
INSERT INTO V_VAL
	VALUES ("6c70c30f-4b6c-428e-9c1d-2e2e32de248f",
	1,
	0,
	36,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("6c70c30f-4b6c-428e-9c1d-2e2e32de248f",
	"2b899854-7a52-457e-9405-d68d6267b089");
INSERT INTO V_VAL
	VALUES ("6a773429-a322-4e7e-bd5b-bcd72fd386cc",
	1,
	0,
	36,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("6a773429-a322-4e7e-bd5b-bcd72fd386cc",
	"6c70c30f-4b6c-428e-9c1d-2e2e32de248f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("62683c27-c26a-4c5a-8ee6-3ee4ca971534",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_UNY
	VALUES ("62683c27-c26a-4c5a-8ee6-3ee4ca971534",
	"43fbfaf6-bef5-423c-990a-b54592b6ed77",
	'-');
INSERT INTO V_VAL
	VALUES ("43fbfaf6-bef5-423c-990a-b54592b6ed77",
	0,
	0,
	36,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("43fbfaf6-bef5-423c-990a-b54592b6ed77",
	'2');
INSERT INTO V_VAL
	VALUES ("5fb0d2cb-d7f7-4e51-9d0f-f5a78758a334",
	1,
	0,
	37,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("5fb0d2cb-d7f7-4e51-9d0f-f5a78758a334",
	"2b899854-7a52-457e-9405-d68d6267b089");
INSERT INTO V_VAL
	VALUES ("c99023e8-059b-45e7-903a-97c6c64ccc31",
	1,
	0,
	37,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("c99023e8-059b-45e7-903a-97c6c64ccc31",
	"5fb0d2cb-d7f7-4e51-9d0f-f5a78758a334",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("870ed389-7c35-4d40-9b24-d29f4a90c120",
	0,
	0,
	37,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("870ed389-7c35-4d40-9b24-d29f4a90c120",
	'15');
INSERT INTO V_VAL
	VALUES ("76e58c40-aa37-4301-b36b-ffc2d03f7c10",
	1,
	0,
	41,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("76e58c40-aa37-4301-b36b-ffc2d03f7c10",
	"9e40927e-4f65-45a3-967d-8332826852c9");
INSERT INTO V_VAL
	VALUES ("63480a46-776d-498f-aa54-c403bffde5fb",
	1,
	0,
	41,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("63480a46-776d-498f-aa54-c403bffde5fb",
	"76e58c40-aa37-4301-b36b-ffc2d03f7c10",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("cc0ceb8b-2d33-4cf7-b8f3-2d75079dce15",
	0,
	0,
	41,
	9,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("cc0ceb8b-2d33-4cf7-b8f3-2d75079dce15",
	'131');
INSERT INTO V_VAL
	VALUES ("6e91c225-af1b-44f6-a767-404e2f484a61",
	1,
	0,
	42,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("6e91c225-af1b-44f6-a767-404e2f484a61",
	"9e40927e-4f65-45a3-967d-8332826852c9");
INSERT INTO V_VAL
	VALUES ("6c7d268b-adc2-4ce1-95d4-a631d6ed47f2",
	1,
	0,
	42,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("6c7d268b-adc2-4ce1-95d4-a631d6ed47f2",
	"6e91c225-af1b-44f6-a767-404e2f484a61",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("5491af06-4270-462a-9943-f139c25c10bd",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_UNY
	VALUES ("5491af06-4270-462a-9943-f139c25c10bd",
	"64f1863c-4b40-418b-a0e5-c324c96b891a",
	'-');
INSERT INTO V_VAL
	VALUES ("64f1863c-4b40-418b-a0e5-c324c96b891a",
	0,
	0,
	42,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("64f1863c-4b40-418b-a0e5-c324c96b891a",
	'2');
INSERT INTO V_VAL
	VALUES ("9d2682de-a0fb-44bf-ad98-cf5ae4698b0d",
	1,
	0,
	43,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("9d2682de-a0fb-44bf-ad98-cf5ae4698b0d",
	"9e40927e-4f65-45a3-967d-8332826852c9");
INSERT INTO V_VAL
	VALUES ("b68273c1-e889-4cd8-8bd0-1a787aac2385",
	1,
	0,
	43,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("b68273c1-e889-4cd8-8bd0-1a787aac2385",
	"9d2682de-a0fb-44bf-ad98-cf5ae4698b0d",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("ccaea442-3e7b-450a-89d5-91ea381f1d29",
	0,
	0,
	43,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("ccaea442-3e7b-450a-89d5-91ea381f1d29",
	'15');
INSERT INTO V_VAL
	VALUES ("74f18fa2-c5bc-46ec-afd2-9c7df51107b6",
	1,
	0,
	47,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("74f18fa2-c5bc-46ec-afd2-9c7df51107b6",
	"b9e09c36-cd04-4217-87d5-60c98608fbec");
INSERT INTO V_VAL
	VALUES ("02086fa3-4473-404a-8c93-1d4c7e512c67",
	1,
	0,
	47,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("02086fa3-4473-404a-8c93-1d4c7e512c67",
	"74f18fa2-c5bc-46ec-afd2-9c7df51107b6",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("9bbb815d-4a25-4f54-bb9e-8f3b3c7dae58",
	0,
	0,
	47,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("9bbb815d-4a25-4f54-bb9e-8f3b3c7dae58",
	'51');
INSERT INTO V_VAL
	VALUES ("f374ad91-7401-4774-9dd6-3b2b6de34276",
	1,
	0,
	48,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("f374ad91-7401-4774-9dd6-3b2b6de34276",
	"b9e09c36-cd04-4217-87d5-60c98608fbec");
INSERT INTO V_VAL
	VALUES ("0a79c303-7126-44ec-8b67-5a7ab4859cd0",
	1,
	0,
	48,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("0a79c303-7126-44ec-8b67-5a7ab4859cd0",
	"f374ad91-7401-4774-9dd6-3b2b6de34276",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("f59578ac-a7dd-4311-bf9c-2e0792352e94",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_UNY
	VALUES ("f59578ac-a7dd-4311-bf9c-2e0792352e94",
	"36b2c7fc-3ee9-464b-bd1f-9ad498e695c3",
	'-');
INSERT INTO V_VAL
	VALUES ("36b2c7fc-3ee9-464b-bd1f-9ad498e695c3",
	0,
	0,
	48,
	10,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("36b2c7fc-3ee9-464b-bd1f-9ad498e695c3",
	'22');
INSERT INTO V_VAL
	VALUES ("8d544fde-8f79-4fd3-9452-c79aa38e5b56",
	1,
	0,
	49,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("8d544fde-8f79-4fd3-9452-c79aa38e5b56",
	"b9e09c36-cd04-4217-87d5-60c98608fbec");
INSERT INTO V_VAL
	VALUES ("3bf1527c-08bf-4fcd-baaf-312f736b2b63",
	1,
	0,
	49,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("3bf1527c-08bf-4fcd-baaf-312f736b2b63",
	"8d544fde-8f79-4fd3-9452-c79aa38e5b56",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("78b6feb1-1b79-4804-8cec-6e55eb38eb22",
	0,
	0,
	49,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("78b6feb1-1b79-4804-8cec-6e55eb38eb22",
	'15');
INSERT INTO V_VAL
	VALUES ("d2f47288-2245-4cf8-a8fd-a66819fb289d",
	1,
	0,
	53,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("d2f47288-2245-4cf8-a8fd-a66819fb289d",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341");
INSERT INTO V_VAL
	VALUES ("a8d36786-e784-46ef-a9fa-6f2f55cc800d",
	1,
	0,
	53,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("a8d36786-e784-46ef-a9fa-6f2f55cc800d",
	"d2f47288-2245-4cf8-a8fd-a66819fb289d",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("1b036bab-4622-48a8-b808-f76e6ea565a6",
	0,
	0,
	53,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("1b036bab-4622-48a8-b808-f76e6ea565a6",
	'91');
INSERT INTO V_VAL
	VALUES ("33c9bb78-70eb-4968-8212-159b12c544b2",
	1,
	0,
	54,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("33c9bb78-70eb-4968-8212-159b12c544b2",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341");
INSERT INTO V_VAL
	VALUES ("9f8db2ad-3bda-4ec3-82ab-9826b6931dfb",
	1,
	0,
	54,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("9f8db2ad-3bda-4ec3-82ab-9826b6931dfb",
	"33c9bb78-70eb-4968-8212-159b12c544b2",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("434d8e03-f138-4048-9fe7-e44f774f7ab0",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_UNY
	VALUES ("434d8e03-f138-4048-9fe7-e44f774f7ab0",
	"72f5d37d-925b-4079-82b9-8e409c858817",
	'-');
INSERT INTO V_VAL
	VALUES ("72f5d37d-925b-4079-82b9-8e409c858817",
	0,
	0,
	54,
	10,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("72f5d37d-925b-4079-82b9-8e409c858817",
	'22');
INSERT INTO V_VAL
	VALUES ("074aed20-defd-469b-be5d-05bc6fe414c7",
	1,
	0,
	55,
	1,
	3,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("074aed20-defd-469b-be5d-05bc6fe414c7",
	"c66afb0d-6c5e-4008-8ffc-29b174aa1341");
INSERT INTO V_VAL
	VALUES ("f3e5ca00-44c6-44cd-a08a-20931a1b5591",
	1,
	0,
	55,
	5,
	5,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("f3e5ca00-44c6-44cd-a08a-20931a1b5591",
	"074aed20-defd-469b-be5d-05bc6fe414c7",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("a71f65de-4f49-43bc-b87b-a58f526764c4",
	0,
	0,
	55,
	9,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("a71f65de-4f49-43bc-b87b-a58f526764c4",
	'15');
INSERT INTO V_VAL
	VALUES ("7b1cb090-77fc-4ea8-a4c7-b289695c09f7",
	1,
	0,
	59,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("7b1cb090-77fc-4ea8-a4c7-b289695c09f7",
	"596ee8c9-4375-4235-b209-15e21ec40e89");
INSERT INTO V_VAL
	VALUES ("bb04ceee-53f1-4d24-999b-ca82a5f52e9c",
	1,
	0,
	59,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("bb04ceee-53f1-4d24-999b-ca82a5f52e9c",
	"7b1cb090-77fc-4ea8-a4c7-b289695c09f7",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("1bddcdb3-383b-4533-8db4-640a74f45098",
	0,
	0,
	59,
	10,
	12,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("1bddcdb3-383b-4533-8db4-640a74f45098",
	'131');
INSERT INTO V_VAL
	VALUES ("51d9555b-95ee-42d3-9d6f-fec2be5663e8",
	1,
	0,
	60,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("51d9555b-95ee-42d3-9d6f-fec2be5663e8",
	"596ee8c9-4375-4235-b209-15e21ec40e89");
INSERT INTO V_VAL
	VALUES ("a65e450a-ed7d-4398-81f5-f1a7f9cefd45",
	1,
	0,
	60,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("a65e450a-ed7d-4398-81f5-f1a7f9cefd45",
	"51d9555b-95ee-42d3-9d6f-fec2be5663e8",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("9a6dc418-c7a5-4919-b7d4-825ba6b8ba2e",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_UNY
	VALUES ("9a6dc418-c7a5-4919-b7d4-825ba6b8ba2e",
	"99a60e14-1f3e-442a-8071-fb51aebb3bac",
	'-');
INSERT INTO V_VAL
	VALUES ("99a60e14-1f3e-442a-8071-fb51aebb3bac",
	0,
	0,
	60,
	11,
	12,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("99a60e14-1f3e-442a-8071-fb51aebb3bac",
	'22');
INSERT INTO V_VAL
	VALUES ("4b8d0d88-08f7-4a8e-bc40-e370084a29c1",
	1,
	0,
	61,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("4b8d0d88-08f7-4a8e-bc40-e370084a29c1",
	"596ee8c9-4375-4235-b209-15e21ec40e89");
INSERT INTO V_VAL
	VALUES ("af56c400-fc48-47eb-ad52-b931a3c9b944",
	1,
	0,
	61,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("af56c400-fc48-47eb-ad52-b931a3c9b944",
	"4b8d0d88-08f7-4a8e-bc40-e370084a29c1",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("43eb466e-052a-4c09-aa6b-5715b0bc7f62",
	0,
	0,
	61,
	10,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("43eb466e-052a-4c09-aa6b-5715b0bc7f62",
	'15');
INSERT INTO V_VAL
	VALUES ("e9d00fdd-c79a-49ec-8b46-88606e21e738",
	1,
	0,
	65,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("e9d00fdd-c79a-49ec-8b46-88606e21e738",
	"7e54f006-8e59-43ed-a196-633ad471d51c");
INSERT INTO V_VAL
	VALUES ("e01eafdc-e300-4e01-bb86-79c9663c317a",
	1,
	0,
	65,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("e01eafdc-e300-4e01-bb86-79c9663c317a",
	"e9d00fdd-c79a-49ec-8b46-88606e21e738",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_VAL
	VALUES ("cc4a9e98-0c37-45b6-b40e-1671dea5d140",
	0,
	0,
	65,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("cc4a9e98-0c37-45b6-b40e-1671dea5d140",
	'0');
INSERT INTO V_VAL
	VALUES ("5966bddc-c462-44e0-aba7-d7329ca06fb6",
	1,
	0,
	66,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("5966bddc-c462-44e0-aba7-d7329ca06fb6",
	"7e54f006-8e59-43ed-a196-633ad471d51c");
INSERT INTO V_VAL
	VALUES ("979bc858-4b3e-41d9-ad48-abc61d31723c",
	1,
	0,
	66,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("979bc858-4b3e-41d9-ad48-abc61d31723c",
	"5966bddc-c462-44e0-aba7-d7329ca06fb6",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_VAL
	VALUES ("3a176a77-3d56-42dc-b26c-7534520f3ce1",
	0,
	0,
	66,
	10,
	10,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("3a176a77-3d56-42dc-b26c-7534520f3ce1",
	'0');
INSERT INTO V_VAL
	VALUES ("8810c686-974e-43a9-a3f6-7688f0dfdab8",
	1,
	0,
	67,
	1,
	4,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_IRF
	VALUES ("8810c686-974e-43a9-a3f6-7688f0dfdab8",
	"7e54f006-8e59-43ed-a196-633ad471d51c");
INSERT INTO V_VAL
	VALUES ("8eb5ab36-58c4-4855-b8c3-a9d74245eacb",
	1,
	0,
	67,
	6,
	6,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_AVL
	VALUES ("8eb5ab36-58c4-4855-b8c3-a9d74245eacb",
	"8810c686-974e-43a9-a3f6-7688f0dfdab8",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_VAL
	VALUES ("5d13033f-3d91-43ea-85d0-eec731ae50a6",
	0,
	0,
	67,
	10,
	11,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"055893bd-f15d-4386-a68d-f115041a8736");
INSERT INTO V_LIN
	VALUES ("5d13033f-3d91-43ea-85d0-eec731ae50a6",
	'15');
INSERT INTO V_VAR
	VALUES ("18f8fe3a-a430-431e-8236-014cb460f9b8",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("18f8fe3a-a430-431e-8236-014cb460f9b8",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO V_VAR
	VALUES ("7089ffdb-e785-49e8-bdc3-0137c9415b07",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp1',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("7089ffdb-e785-49e8-bdc3-0137c9415b07",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("f9613d44-8688-432f-9a7c-8dc48f237dc5",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp2',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("f9613d44-8688-432f-9a7c-8dc48f237dc5",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("b933a417-eaa2-40d3-94d2-f96087887d65",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp3',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("b933a417-eaa2-40d3-94d2-f96087887d65",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("480c5b0b-d964-4f18-bea9-c549c1c7f927",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp4',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("480c5b0b-d964-4f18-bea9-c549c1c7f927",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("5e63fe68-06dd-445b-a287-872e853d1639",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp5',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("5e63fe68-06dd-445b-a287-872e853d1639",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("2b899854-7a52-457e-9405-d68d6267b089",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp6',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("2b899854-7a52-457e-9405-d68d6267b089",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("9e40927e-4f65-45a3-967d-8332826852c9",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp7',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("9e40927e-4f65-45a3-967d-8332826852c9",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("b9e09c36-cd04-4217-87d5-60c98608fbec",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp8',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("b9e09c36-cd04-4217-87d5-60c98608fbec",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("c66afb0d-6c5e-4008-8ffc-29b174aa1341",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp9',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("c66afb0d-6c5e-4008-8ffc-29b174aa1341",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("596ee8c9-4375-4235-b209-15e21ec40e89",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp10',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("596ee8c9-4375-4235-b209-15e21ec40e89",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("7e54f006-8e59-43ed-a196-633ad471d51c",
	"055893bd-f15d-4386-a68d-f115041a8736",
	'wp11',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("7e54f006-8e59-43ed-a196-633ad471d51c",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO PE_PE
	VALUES ("62f7363e-67a4-4984-8402-3bb54fc40536",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("62f7363e-67a4-4984-8402-3bb54fc40536",
	"00000000-0000-0000-0000-000000000000",
	'halt',
	'',
	'select any ctrl from instances of Controller;
generate Controller3:''halt'' to ctrl;',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("86557e41-5020-4d27-bd22-6a16c2ecf82a",
	"62f7363e-67a4-4984-8402-3bb54fc40536");
INSERT INTO ACT_ACT
	VALUES ("86557e41-5020-4d27-bd22-6a16c2ecf82a",
	'function',
	0,
	"1047e9ba-0d6a-4374-a85d-87155ef11f21",
	"00000000-0000-0000-0000-000000000000",
	0,
	'halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("1047e9ba-0d6a-4374-a85d-87155ef11f21",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"86557e41-5020-4d27-bd22-6a16c2ecf82a",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("3fb80369-74fc-4f24-8118-13e068041a47",
	"1047e9ba-0d6a-4374-a85d-87155ef11f21",
	"852a26b1-74d2-4f40-b7d6-f9cb48a2db61",
	1,
	1,
	'halt line: 1');
INSERT INTO ACT_FIO
	VALUES ("3fb80369-74fc-4f24-8118-13e068041a47",
	"589942aa-a041-4934-b67f-a6b8c4949e07",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("852a26b1-74d2-4f40-b7d6-f9cb48a2db61",
	"1047e9ba-0d6a-4374-a85d-87155ef11f21",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'halt line: 2');
INSERT INTO E_ESS
	VALUES ("852a26b1-74d2-4f40-b7d6-f9cb48a2db61",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	35,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("852a26b1-74d2-4f40-b7d6-f9cb48a2db61");
INSERT INTO E_GSME
	VALUES ("852a26b1-74d2-4f40-b7d6-f9cb48a2db61",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8");
INSERT INTO E_GEN
	VALUES ("852a26b1-74d2-4f40-b7d6-f9cb48a2db61",
	"589942aa-a041-4934-b67f-a6b8c4949e07");
INSERT INTO V_VAR
	VALUES ("589942aa-a041-4934-b67f-a6b8c4949e07",
	"1047e9ba-0d6a-4374-a85d-87155ef11f21",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("589942aa-a041-4934-b67f-a6b8c4949e07",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("7f60e548-d892-42d4-b3be-d3b52cf64d11",
	1,
	"c266a8d5-aa61-43f4-9d01-7e2baedb603e",
	"00000000-0000-0000-0000-000000000000",
	1);
INSERT INTO S_SYNC
	VALUES ("7f60e548-d892-42d4-b3be-d3b52cf64d11",
	"00000000-0000-0000-0000-000000000000",
	'start',
	'',
	'select any ctrl from instances of Controller;
generate Controller1:''start'' to ctrl;',
	"ba5eda7a-def5-0000-0000-000000000000",
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES ("af700c09-d3b1-481b-b19f-4785add41790",
	"7f60e548-d892-42d4-b3be-d3b52cf64d11");
INSERT INTO ACT_ACT
	VALUES ("af700c09-d3b1-481b-b19f-4785add41790",
	'function',
	0,
	"65df79e9-465c-425a-88f0-abc5ffb09a19",
	"00000000-0000-0000-0000-000000000000",
	0,
	'start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("65df79e9-465c-425a-88f0-abc5ffb09a19",
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	1,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"af700c09-d3b1-481b-b19f-4785add41790",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("6d76ce4d-2885-4cfa-9a28-27bf49e1504b",
	"65df79e9-465c-425a-88f0-abc5ffb09a19",
	"0548b77f-15fe-4375-9b2b-14bc5b18afb9",
	1,
	1,
	'start line: 1');
INSERT INTO ACT_FIO
	VALUES ("6d76ce4d-2885-4cfa-9a28-27bf49e1504b",
	"05141e40-bf48-48fb-b803-e9e11a9f6e0f",
	1,
	'any',
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	35);
INSERT INTO ACT_SMT
	VALUES ("0548b77f-15fe-4375-9b2b-14bc5b18afb9",
	"65df79e9-465c-425a-88f0-abc5ffb09a19",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'start line: 2');
INSERT INTO E_ESS
	VALUES ("0548b77f-15fe-4375-9b2b-14bc5b18afb9",
	1,
	0,
	2,
	10,
	2,
	22,
	1,
	35,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("0548b77f-15fe-4375-9b2b-14bc5b18afb9");
INSERT INTO E_GSME
	VALUES ("0548b77f-15fe-4375-9b2b-14bc5b18afb9",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5");
INSERT INTO E_GEN
	VALUES ("0548b77f-15fe-4375-9b2b-14bc5b18afb9",
	"05141e40-bf48-48fb-b803-e9e11a9f6e0f");
INSERT INTO V_VAR
	VALUES ("05141e40-bf48-48fb-b803-e9e11a9f6e0f",
	"65df79e9-465c-425a-88f0-abc5ffb09a19",
	'ctrl',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("05141e40-bf48-48fb-b803-e9e11a9f6e0f",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO PE_PE
	VALUES ("c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	1,
	"00000000-0000-0000-0000-000000000000",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	7);
INSERT INTO EP_PKG
	VALUES ("c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'Control',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	4);
INSERT INTO O_OBJ
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	'Controller',
	1,
	'Controller',
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_NBATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_BATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ATTR
	VALUES ("0e7f33c3-b2c2-41b2-a377-a79d4a667cad",
	"44c11680-c695-4cd0-8c5c-49bc06b14528",
	"00000000-0000-0000-0000-000000000000",
	'current_state',
	'',
	'',
	'current_state',
	0,
	"ba5eda7a-def5-0000-0000-000000000006",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ID
	VALUES (1,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO O_ID
	VALUES (2,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO SM_ISM
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507",
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO SM_SM
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507",
	'',
	0);
INSERT INTO SM_MOORE
	VALUES ("c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_LEVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	1,
	'start',
	0,
	'',
	'Controller1',
	'');
INSERT INTO SM_LEVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	2,
	'ready',
	0,
	'',
	'Controller2',
	'');
INSERT INTO SM_LEVT
	VALUES ("e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEVT
	VALUES ("e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_EVT
	VALUES ("e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	3,
	'halt',
	0,
	'',
	'Controller3',
	'');
INSERT INTO SM_STATE
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'init',
	1,
	0);
INSERT INTO SM_SEME
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("7f911223-94da-4dfd-9f31-ded59eac4395",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"f1e26a98-2d35-4146-ba56-ee3c2166a6dd");
INSERT INTO SM_AH
	VALUES ("7f911223-94da-4dfd-9f31-ded59eac4395",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("7f911223-94da-4dfd-9f31-ded59eac4395",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("9a64b223-2131-46b3-b381-75a806de2b22",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"7f911223-94da-4dfd-9f31-ded59eac4395");
INSERT INTO ACT_ACT
	VALUES ("9a64b223-2131-46b3-b381-75a806de2b22",
	'state',
	0,
	"b0747797-1b91-416b-936a-8cc496454f40",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::init',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("b0747797-1b91-416b-936a-8cc496454f40",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"9a64b223-2131-46b3-b381-75a806de2b22",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_STATE
	VALUES ("314351a0-a57f-4d06-b408-47b9fcf31282",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'take off',
	2,
	0);
INSERT INTO SM_CH
	VALUES ("314351a0-a57f-4d06-b408-47b9fcf31282",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("314351a0-a57f-4d06-b408-47b9fcf31282",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("314351a0-a57f-4d06-b408-47b9fcf31282",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("314351a0-a57f-4d06-b408-47b9fcf31282",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("9aaba8a8-b239-47c8-b17d-6bd0697d8c91",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"314351a0-a57f-4d06-b408-47b9fcf31282");
INSERT INTO SM_AH
	VALUES ("9aaba8a8-b239-47c8-b17d-6bd0697d8c91",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("9aaba8a8-b239-47c8-b17d-6bd0697d8c91",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'Port1::takeoff( alt:15 );
Port1::set_heading( heading:0 );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("8f6822d7-8dc3-4b17-becc-515eec433944",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"9aaba8a8-b239-47c8-b17d-6bd0697d8c91");
INSERT INTO ACT_ACT
	VALUES ("8f6822d7-8dc3-4b17-becc-515eec433944",
	'state',
	0,
	"c49a2910-6683-4958-94e8-6285192db16e",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::take off',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("c49a2910-6683-4958-94e8-6285192db16e",
	0,
	0,
	0,
	'Port1',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"8f6822d7-8dc3-4b17-becc-515eec433944",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("09a51abe-8521-4f5c-8c8c-93de8646f3a2",
	"c49a2910-6683-4958-94e8-6285192db16e",
	"5637f418-16e5-4afb-adb9-8b86983d1edb",
	1,
	1,
	'Controller::take off line: 1');
INSERT INTO ACT_IOP
	VALUES ("09a51abe-8521-4f5c-8c8c-93de8646f3a2",
	1,
	8,
	1,
	1,
	"00000000-0000-0000-0000-000000000000",
	"786f401b-dc06-4f89-95d6-805158b17282",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5637f418-16e5-4afb-adb9-8b86983d1edb",
	"c49a2910-6683-4958-94e8-6285192db16e",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Controller::take off line: 2');
INSERT INTO ACT_IOP
	VALUES ("5637f418-16e5-4afb-adb9-8b86983d1edb",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("cb534754-2c2b-4aa2-9640-902ee4ee2f59",
	0,
	0,
	1,
	21,
	22,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"c49a2910-6683-4958-94e8-6285192db16e");
INSERT INTO V_LIN
	VALUES ("cb534754-2c2b-4aa2-9640-902ee4ee2f59",
	'15');
INSERT INTO V_PAR
	VALUES ("cb534754-2c2b-4aa2-9640-902ee4ee2f59",
	"09a51abe-8521-4f5c-8c8c-93de8646f3a2",
	"00000000-0000-0000-0000-000000000000",
	'alt',
	"00000000-0000-0000-0000-000000000000",
	1,
	17);
INSERT INTO V_VAL
	VALUES ("eb5f9f2e-3c71-4a38-898d-64de3478241a",
	0,
	0,
	2,
	29,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"c49a2910-6683-4958-94e8-6285192db16e");
INSERT INTO V_LIN
	VALUES ("eb5f9f2e-3c71-4a38-898d-64de3478241a",
	'0');
INSERT INTO V_PAR
	VALUES ("eb5f9f2e-3c71-4a38-898d-64de3478241a",
	"5637f418-16e5-4afb-adb9-8b86983d1edb",
	"00000000-0000-0000-0000-000000000000",
	'heading',
	"00000000-0000-0000-0000-000000000000",
	2,
	21);
INSERT INTO SM_STATE
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'land',
	3,
	0);
INSERT INTO SM_CH
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_CH
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("34fe9fb8-c593-4428-9e30-aa94f1470ce5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"27b6e60c-7819-43b4-9a1b-d1c21e678360");
INSERT INTO SM_AH
	VALUES ("34fe9fb8-c593-4428-9e30-aa94f1470ce5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("34fe9fb8-c593-4428-9e30-aa94f1470ce5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'Port1::land();
Port1::set_heading( heading:0);',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("a31f4073-bc65-4ac1-85b6-f308712f6f00",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"34fe9fb8-c593-4428-9e30-aa94f1470ce5");
INSERT INTO ACT_ACT
	VALUES ("a31f4073-bc65-4ac1-85b6-f308712f6f00",
	'state',
	0,
	"98e441ce-07f7-4564-9513-42e1c5a18b9c",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::land',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("98e441ce-07f7-4564-9513-42e1c5a18b9c",
	0,
	0,
	0,
	'Port1',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"a31f4073-bc65-4ac1-85b6-f308712f6f00",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("1b4b0cb9-df82-418a-987c-8d167a294919",
	"98e441ce-07f7-4564-9513-42e1c5a18b9c",
	"c96c2c7e-2134-474b-8ce1-cf16fea880e7",
	1,
	1,
	'Controller::land line: 1');
INSERT INTO ACT_IOP
	VALUES ("1b4b0cb9-df82-418a-987c-8d167a294919",
	1,
	8,
	1,
	1,
	"00000000-0000-0000-0000-000000000000",
	"ea4468fa-4b20-4012-8e54-d298c549ee90",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("c96c2c7e-2134-474b-8ce1-cf16fea880e7",
	"98e441ce-07f7-4564-9513-42e1c5a18b9c",
	"00000000-0000-0000-0000-000000000000",
	2,
	1,
	'Controller::land line: 2');
INSERT INTO ACT_IOP
	VALUES ("c96c2c7e-2134-474b-8ce1-cf16fea880e7",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"55afac66-d149-4d24-9466-0c4a6f48dcf5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO V_VAL
	VALUES ("6371c228-1adb-4ae3-b4f6-2b0fa8aca3d9",
	0,
	0,
	2,
	29,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000002",
	"98e441ce-07f7-4564-9513-42e1c5a18b9c");
INSERT INTO V_LIN
	VALUES ("6371c228-1adb-4ae3-b4f6-2b0fa8aca3d9",
	'0');
INSERT INTO V_PAR
	VALUES ("6371c228-1adb-4ae3-b4f6-2b0fa8aca3d9",
	"c96c2c7e-2134-474b-8ce1-cf16fea880e7",
	"00000000-0000-0000-0000-000000000000",
	'heading',
	"00000000-0000-0000-0000-000000000000",
	2,
	21);
INSERT INTO SM_STATE
	VALUES ("74681218-cacb-4f57-812f-e3ab0da5a669",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'go',
	4,
	0);
INSERT INTO SM_CH
	VALUES ("74681218-cacb-4f57-812f-e3ab0da5a669",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000",
	'');
INSERT INTO SM_SEME
	VALUES ("74681218-cacb-4f57-812f-e3ab0da5a669",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("74681218-cacb-4f57-812f-e3ab0da5a669",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_SEME
	VALUES ("74681218-cacb-4f57-812f-e3ab0da5a669",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_MOAH
	VALUES ("27d3efc5-800f-46c1-aff2-e4e03dfa85f9",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"74681218-cacb-4f57-812f-e3ab0da5a669");
INSERT INTO SM_AH
	VALUES ("27d3efc5-800f-46c1-aff2-e4e03dfa85f9",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("27d3efc5-800f-46c1-aff2-e4e03dfa85f9",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'select one wp related by self->Waypoint[R3.''is flying to''];
Port1::set_destination( x:wp.x, y:wp.y, z:wp.z );

select one next_wp related by wp->Waypoint[R2.''follows''];
if(not empty next_wp)
	relate self to next_wp across R3.''is flying to'';
else
	generate Controller3:''halt'' to self;
end if;
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES ("6e2bd009-aec1-438b-b5ca-3edf9315d6ed",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"27d3efc5-800f-46c1-aff2-e4e03dfa85f9");
INSERT INTO ACT_ACT
	VALUES ("6e2bd009-aec1-438b-b5ca-3edf9315d6ed",
	'state',
	0,
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller::go',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("272299cb-0077-430e-8a5e-a1346bf038fa",
	1,
	0,
	0,
	'',
	'',
	'',
	7,
	1,
	4,
	35,
	0,
	0,
	4,
	44,
	4,
	47,
	0,
	0,
	0,
	"6e2bd009-aec1-438b-b5ca-3edf9315d6ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("4c952f3b-d76b-40bf-ace2-7410f2be11a3",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	1,
	1,
	'Controller::go line: 1');
INSERT INTO ACT_SEL
	VALUES ("4c952f3b-d76b-40bf-ace2-7410f2be11a3",
	"384c1ee2-1e3f-4727-ab8c-c2861049f487",
	1,
	'one',
	"d11598fd-92a2-46ca-bda4-91a1c7113826");
INSERT INTO ACT_SR
	VALUES ("4c952f3b-d76b-40bf-ace2-7410f2be11a3");
INSERT INTO ACT_LNK
	VALUES ("801af0bc-bcd0-47ee-9637-f44d6780c658",
	'''is flying to''',
	"4c952f3b-d76b-40bf-ace2-7410f2be11a3",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"00000000-0000-0000-0000-000000000000",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	1,
	32,
	1,
	41,
	1,
	44);
INSERT INTO ACT_SMT
	VALUES ("618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"d9fcf33a-224c-4685-b77d-950be5d6d165",
	2,
	1,
	'Controller::go line: 2');
INSERT INTO ACT_IOP
	VALUES ("618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	2,
	8,
	2,
	1,
	"00000000-0000-0000-0000-000000000000",
	"0b7b0648-980a-4657-9783-453131e6af11",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("d9fcf33a-224c-4685-b77d-950be5d6d165",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"adbb8e0c-d6f5-423f-8b63-bc52002ccd69",
	4,
	1,
	'Controller::go line: 4');
INSERT INTO ACT_SEL
	VALUES ("d9fcf33a-224c-4685-b77d-950be5d6d165",
	"f821ea5b-28ed-4d47-b297-6871d6ccdb13",
	1,
	'one',
	"366a50b8-2253-48fd-9acc-61ab63b83129");
INSERT INTO ACT_SR
	VALUES ("d9fcf33a-224c-4685-b77d-950be5d6d165");
INSERT INTO ACT_LNK
	VALUES ("515a2e38-68bd-49c4-8620-70af3b1c6af0",
	'''follows''',
	"d9fcf33a-224c-4685-b77d-950be5d6d165",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"00000000-0000-0000-0000-000000000000",
	1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	4,
	35,
	4,
	44,
	4,
	47);
INSERT INTO ACT_SMT
	VALUES ("adbb8e0c-d6f5-423f-8b63-bc52002ccd69",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"00000000-0000-0000-0000-000000000000",
	5,
	1,
	'Controller::go line: 5');
INSERT INTO ACT_IF
	VALUES ("adbb8e0c-d6f5-423f-8b63-bc52002ccd69",
	"95830496-bbce-4c0f-8900-055cc239830e",
	"40eaa6b0-18bc-4021-bf20-a7007844cca3",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("5881153d-de00-4152-8e0c-2c510fe8bb3e",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	"00000000-0000-0000-0000-000000000000",
	7,
	1,
	'Controller::go line: 7');
INSERT INTO ACT_E
	VALUES ("5881153d-de00-4152-8e0c-2c510fe8bb3e",
	"3b409944-2c1e-40bc-adc1-033393b325a3",
	"adbb8e0c-d6f5-423f-8b63-bc52002ccd69");
INSERT INTO V_VAL
	VALUES ("d11598fd-92a2-46ca-bda4-91a1c7113826",
	0,
	0,
	1,
	26,
	29,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("d11598fd-92a2-46ca-bda4-91a1c7113826",
	"70cebb1a-6b88-47b1-b677-f611a330fe14");
INSERT INTO V_VAL
	VALUES ("60d42553-64a7-4815-8856-2f3c12cc5e25",
	0,
	0,
	2,
	27,
	28,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("60d42553-64a7-4815-8856-2f3c12cc5e25",
	"384c1ee2-1e3f-4727-ab8c-c2861049f487");
INSERT INTO V_VAL
	VALUES ("e75a62e0-8475-499d-ad21-7cc97c8bc0d2",
	0,
	0,
	2,
	30,
	30,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_AVL
	VALUES ("e75a62e0-8475-499d-ad21-7cc97c8bc0d2",
	"60d42553-64a7-4815-8856-2f3c12cc5e25",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2");
INSERT INTO V_PAR
	VALUES ("e75a62e0-8475-499d-ad21-7cc97c8bc0d2",
	"618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	"00000000-0000-0000-0000-000000000000",
	'x',
	"5932d389-2882-4ab3-9b89-cabc3ff6e973",
	2,
	25);
INSERT INTO V_VAL
	VALUES ("5f096812-e00b-4f76-b5f9-8355b8e1d19b",
	0,
	0,
	2,
	35,
	36,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("5f096812-e00b-4f76-b5f9-8355b8e1d19b",
	"384c1ee2-1e3f-4727-ab8c-c2861049f487");
INSERT INTO V_VAL
	VALUES ("5932d389-2882-4ab3-9b89-cabc3ff6e973",
	0,
	0,
	2,
	38,
	38,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_AVL
	VALUES ("5932d389-2882-4ab3-9b89-cabc3ff6e973",
	"5f096812-e00b-4f76-b5f9-8355b8e1d19b",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5");
INSERT INTO V_PAR
	VALUES ("5932d389-2882-4ab3-9b89-cabc3ff6e973",
	"618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	"00000000-0000-0000-0000-000000000000",
	'y',
	"ae242045-5e2d-498c-b19c-3ffdfd88bfee",
	2,
	33);
INSERT INTO V_VAL
	VALUES ("a4ecdcae-7383-4961-a2bb-fa676edeb706",
	0,
	0,
	2,
	43,
	44,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("a4ecdcae-7383-4961-a2bb-fa676edeb706",
	"384c1ee2-1e3f-4727-ab8c-c2861049f487");
INSERT INTO V_VAL
	VALUES ("ae242045-5e2d-498c-b19c-3ffdfd88bfee",
	0,
	0,
	2,
	46,
	46,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_AVL
	VALUES ("ae242045-5e2d-498c-b19c-3ffdfd88bfee",
	"a4ecdcae-7383-4961-a2bb-fa676edeb706",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"a39a7029-e086-4f27-8eb9-de54a0f2e79f");
INSERT INTO V_PAR
	VALUES ("ae242045-5e2d-498c-b19c-3ffdfd88bfee",
	"618fb535-0a82-4d31-9f8d-2b9b1ebc4e30",
	"00000000-0000-0000-0000-000000000000",
	'z',
	"00000000-0000-0000-0000-000000000000",
	2,
	41);
INSERT INTO V_VAL
	VALUES ("366a50b8-2253-48fd-9acc-61ab63b83129",
	0,
	0,
	4,
	31,
	32,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("366a50b8-2253-48fd-9acc-61ab63b83129",
	"384c1ee2-1e3f-4727-ab8c-c2861049f487");
INSERT INTO V_VAL
	VALUES ("0a9df033-c335-48df-9941-e1098468181d",
	0,
	0,
	5,
	14,
	20,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000008",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_IRF
	VALUES ("0a9df033-c335-48df-9941-e1098468181d",
	"f821ea5b-28ed-4d47-b297-6871d6ccdb13");
INSERT INTO V_VAL
	VALUES ("96f5b422-5f1b-4db9-b8ea-ceeac1fef7ae",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000001",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_UNY
	VALUES ("96f5b422-5f1b-4db9-b8ea-ceeac1fef7ae",
	"0a9df033-c335-48df-9941-e1098468181d",
	'empty');
INSERT INTO V_VAL
	VALUES ("40eaa6b0-18bc-4021-bf20-a7007844cca3",
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	"ba5eda7a-def5-0000-0000-000000000001",
	"272299cb-0077-430e-8a5e-a1346bf038fa");
INSERT INTO V_UNY
	VALUES ("40eaa6b0-18bc-4021-bf20-a7007844cca3",
	"96f5b422-5f1b-4db9-b8ea-ceeac1fef7ae",
	'not');
INSERT INTO V_VAR
	VALUES ("384c1ee2-1e3f-4727-ab8c-c2861049f487",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	'wp',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("384c1ee2-1e3f-4727-ab8c-c2861049f487",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO V_VAR
	VALUES ("70cebb1a-6b88-47b1-b677-f611a330fe14",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	'self',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("70cebb1a-6b88-47b1-b677-f611a330fe14",
	0,
	"44c11680-c695-4cd0-8c5c-49bc06b14528");
INSERT INTO V_VAR
	VALUES ("f821ea5b-28ed-4d47-b297-6871d6ccdb13",
	"272299cb-0077-430e-8a5e-a1346bf038fa",
	'next_wp',
	1,
	"ba5eda7a-def5-0000-0000-000000000008");
INSERT INTO V_INT
	VALUES ("f821ea5b-28ed-4d47-b297-6871d6ccdb13",
	0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO ACT_BLK
	VALUES ("95830496-bbce-4c0f-8900-055cc239830e",
	0,
	0,
	0,
	'''is flying to''',
	'',
	'',
	6,
	2,
	0,
	0,
	0,
	0,
	6,
	32,
	6,
	35,
	0,
	0,
	0,
	"6e2bd009-aec1-438b-b5ca-3edf9315d6ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("351891fc-0866-4a32-a1bd-7b95a8669f4a",
	"95830496-bbce-4c0f-8900-055cc239830e",
	"00000000-0000-0000-0000-000000000000",
	6,
	2,
	'Controller::go line: 6');
INSERT INTO ACT_REL
	VALUES ("351891fc-0866-4a32-a1bd-7b95a8669f4a",
	"70cebb1a-6b88-47b1-b677-f611a330fe14",
	"f821ea5b-28ed-4d47-b297-6871d6ccdb13",
	'''is flying to''',
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	6,
	32,
	6,
	35);
INSERT INTO ACT_BLK
	VALUES ("3b409944-2c1e-40bc-adc1-033393b325a3",
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	2,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"6e2bd009-aec1-438b-b5ca-3edf9315d6ed",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_SMT
	VALUES ("fb99dc7d-9ec9-4403-8519-beadaf9db3c0",
	"3b409944-2c1e-40bc-adc1-033393b325a3",
	"00000000-0000-0000-0000-000000000000",
	8,
	2,
	'Controller::go line: 8');
INSERT INTO E_ESS
	VALUES ("fb99dc7d-9ec9-4403-8519-beadaf9db3c0",
	1,
	0,
	8,
	11,
	8,
	23,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES ("fb99dc7d-9ec9-4403-8519-beadaf9db3c0");
INSERT INTO E_GSME
	VALUES ("fb99dc7d-9ec9-4403-8519-beadaf9db3c0",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8");
INSERT INTO E_GEN
	VALUES ("fb99dc7d-9ec9-4403-8519-beadaf9db3c0",
	"70cebb1a-6b88-47b1-b677-f611a330fe14");
INSERT INTO SM_NSTXN
	VALUES ("b5b9a9ad-1a2c-4109-84f5-d34f56a6c86f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"f1e26a98-2d35-4146-ba56-ee3c2166a6dd",
	"26caf769-2f00-4ee1-8664-83ff862aa1c5",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("796e73bb-3792-4eef-89c8-ae728e47d5f7",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"b5b9a9ad-1a2c-4109-84f5-d34f56a6c86f");
INSERT INTO SM_AH
	VALUES ("796e73bb-3792-4eef-89c8-ae728e47d5f7",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("796e73bb-3792-4eef-89c8-ae728e47d5f7",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("88a6de13-8d09-4334-882a-35d6cc74648b",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"796e73bb-3792-4eef-89c8-ae728e47d5f7");
INSERT INTO ACT_ACT
	VALUES ("88a6de13-8d09-4334-882a-35d6cc74648b",
	'transition',
	0,
	"6f025a1f-cbde-462d-9229-50c4dbf1a538",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller1: start',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("6f025a1f-cbde-462d-9229-50c4dbf1a538",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"88a6de13-8d09-4334-882a-35d6cc74648b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("b5b9a9ad-1a2c-4109-84f5-d34f56a6c86f",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"314351a0-a57f-4d06-b408-47b9fcf31282",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("e64392fd-6454-4f0d-abd0-a996c8381a2e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"314351a0-a57f-4d06-b408-47b9fcf31282",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("f2475340-ec2d-44b1-bba2-07c722883e10",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"e64392fd-6454-4f0d-abd0-a996c8381a2e");
INSERT INTO SM_AH
	VALUES ("f2475340-ec2d-44b1-bba2-07c722883e10",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("f2475340-ec2d-44b1-bba2-07c722883e10",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("aaffd330-2da7-4d06-b11e-3c65369abfc4",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"f2475340-ec2d-44b1-bba2-07c722883e10");
INSERT INTO ACT_ACT
	VALUES ("aaffd330-2da7-4d06-b11e-3c65369abfc4",
	'transition',
	0,
	"ffa8305b-07c0-4f95-a742-0d1da67cf024",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller3: halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("ffa8305b-07c0-4f95-a742-0d1da67cf024",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"aaffd330-2da7-4d06-b11e-3c65369abfc4",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("e64392fd-6454-4f0d-abd0-a996c8381a2e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("f1535f1f-370d-457a-9b5b-744bca7a4085",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"314351a0-a57f-4d06-b408-47b9fcf31282",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("bafce273-643e-4d80-bfaf-9f40e8e18f15",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"f1535f1f-370d-457a-9b5b-744bca7a4085");
INSERT INTO SM_AH
	VALUES ("bafce273-643e-4d80-bfaf-9f40e8e18f15",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("bafce273-643e-4d80-bfaf-9f40e8e18f15",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("389ff0c0-820a-4ebc-a52d-6a3710ad829b",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"bafce273-643e-4d80-bfaf-9f40e8e18f15");
INSERT INTO ACT_ACT
	VALUES ("389ff0c0-820a-4ebc-a52d-6a3710ad829b",
	'transition',
	0,
	"32a20351-4e21-4008-b411-d28c2e8b4e73",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller2: ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("32a20351-4e21-4008-b411-d28c2e8b4e73",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"389ff0c0-820a-4ebc-a52d-6a3710ad829b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("f1535f1f-370d-457a-9b5b-744bca7a4085",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"74681218-cacb-4f57-812f-e3ab0da5a669",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("e8deb027-f54b-48ca-9c6f-d4034414cee7",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"74681218-cacb-4f57-812f-e3ab0da5a669",
	"e6a75ef6-2f12-4af7-b6dc-a204e6dd66e8",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("0498fba8-c5e5-476a-bb8e-1b39be41782d",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"e8deb027-f54b-48ca-9c6f-d4034414cee7");
INSERT INTO SM_AH
	VALUES ("0498fba8-c5e5-476a-bb8e-1b39be41782d",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("0498fba8-c5e5-476a-bb8e-1b39be41782d",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("5cca3395-7fea-4241-8dad-c6c252fabcf3",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"0498fba8-c5e5-476a-bb8e-1b39be41782d");
INSERT INTO ACT_ACT
	VALUES ("5cca3395-7fea-4241-8dad-c6c252fabcf3",
	'transition',
	0,
	"03429509-f1ad-4dcf-a280-b45b01fe68aa",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller3: halt',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("03429509-f1ad-4dcf-a280-b45b01fe68aa",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"5cca3395-7fea-4241-8dad-c6c252fabcf3",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("e8deb027-f54b-48ca-9c6f-d4034414cee7",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"27b6e60c-7819-43b4-9a1b-d1c21e678360",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_NSTXN
	VALUES ("2b4197a3-d5a8-4843-a300-46bca802131c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"74681218-cacb-4f57-812f-e3ab0da5a669",
	"b8dcfa69-53b7-440a-8ceb-a235f197459c",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TAH
	VALUES ("ecd13203-ee57-470a-a630-189de12f290e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"2b4197a3-d5a8-4843-a300-46bca802131c");
INSERT INTO SM_AH
	VALUES ("ecd13203-ee57-470a-a630-189de12f290e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507");
INSERT INTO SM_ACT
	VALUES ("ecd13203-ee57-470a-a630-189de12f290e",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES ("65996527-7686-4ccf-b27c-b8939932c22d",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"ecd13203-ee57-470a-a630-189de12f290e");
INSERT INTO ACT_ACT
	VALUES ("65996527-7686-4ccf-b27c-b8939932c22d",
	'transition',
	0,
	"60d09b29-5f5b-4823-9fdb-54c5899d77c0",
	"00000000-0000-0000-0000-000000000000",
	0,
	'Controller2: ready',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO ACT_BLK
	VALUES ("60d09b29-5f5b-4823-9fdb-54c5899d77c0",
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"65996527-7686-4ccf-b27c-b8939932c22d",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO SM_TXN
	VALUES ("2b4197a3-d5a8-4843-a300-46bca802131c",
	"c0c74364-95af-42df-a665-9e2fd1a7f507",
	"74681218-cacb-4f57-812f-e3ab0da5a669",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	4);
INSERT INTO O_OBJ
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	'Waypoint',
	2,
	'Waypoint',
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO O_NBATTR
	VALUES ("7d11658e-334c-45cd-b59e-a264438f8fb2",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_BATTR
	VALUES ("7d11658e-334c-45cd-b59e-a264438f8fb2",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_ATTR
	VALUES ("7d11658e-334c-45cd-b59e-a264438f8fb2",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"00000000-0000-0000-0000-000000000000",
	'x',
	'',
	'',
	'x',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("83e5bb7f-3439-40e4-9441-fbe56bf733e5",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_BATTR
	VALUES ("83e5bb7f-3439-40e4-9441-fbe56bf733e5",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_ATTR
	VALUES ("83e5bb7f-3439-40e4-9441-fbe56bf733e5",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"7d11658e-334c-45cd-b59e-a264438f8fb2",
	'y',
	'',
	'',
	'y',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_NBATTR
	VALUES ("a39a7029-e086-4f27-8eb9-de54a0f2e79f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_BATTR
	VALUES ("a39a7029-e086-4f27-8eb9-de54a0f2e79f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_ATTR
	VALUES ("a39a7029-e086-4f27-8eb9-de54a0f2e79f",
	"6248fd88-7e3e-4f89-957e-a82cef34c946",
	"83e5bb7f-3439-40e4-9441-fbe56bf733e5",
	'z',
	'',
	'',
	'z',
	0,
	"ba5eda7a-def5-0000-0000-000000000003",
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_ID
	VALUES (1,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO O_ID
	VALUES (2,
	"6248fd88-7e3e-4f89-957e-a82cef34c946");
INSERT INTO PE_PE
	VALUES ("5ca89535-bd88-41a4-a989-3ef467506fbf",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("5ca89535-bd88-41a4-a989-3ef467506fbf",
	1,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("5ca89535-bd88-41a4-a989-3ef467506fbf");
INSERT INTO R_PART
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"dac03cf5-2644-42c0-a979-40d468dfcbdd",
	0,
	0,
	'');
INSERT INTO R_RTO
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"dac03cf5-2644-42c0-a979-40d468dfcbdd",
	-1);
INSERT INTO R_OIR
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"dac03cf5-2644-42c0-a979-40d468dfcbdd",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"4ad2383f-dc89-476c-a160-764448955256",
	0,
	1,
	'begin with');
INSERT INTO R_RTO
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"4ad2383f-dc89-476c-a160-764448955256",
	-1);
INSERT INTO R_OIR
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"5ca89535-bd88-41a4-a989-3ef467506fbf",
	"4ad2383f-dc89-476c-a160-764448955256",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("d5dbce16-be48-4971-809f-1e4f3ec4b806",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("d5dbce16-be48-4971-809f-1e4f3ec4b806",
	2,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("d5dbce16-be48-4971-809f-1e4f3ec4b806");
INSERT INTO R_PART
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"664fa76b-e0ca-41b2-b74f-c13620653c86",
	0,
	0,
	'follows');
INSERT INTO R_RTO
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"664fa76b-e0ca-41b2-b74f-c13620653c86",
	-1);
INSERT INTO R_OIR
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"664fa76b-e0ca-41b2-b74f-c13620653c86",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"cb021ee4-2f87-4eea-8a43-547861e730b9",
	0,
	1,
	'is followed by');
INSERT INTO R_RTO
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"cb021ee4-2f87-4eea-8a43-547861e730b9",
	-1);
INSERT INTO R_OIR
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"d5dbce16-be48-4971-809f-1e4f3ec4b806",
	"cb021ee4-2f87-4eea-8a43-547861e730b9",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO PE_PE
	VALUES ("b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	1,
	"c7bc1f0d-acc5-45cd-afb5-da93bea1c897",
	"00000000-0000-0000-0000-000000000000",
	9);
INSERT INTO R_REL
	VALUES ("b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	3,
	'',
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_SIMP
	VALUES ("b9ef235f-a534-468d-a18b-d8b6e8d8f69a");
INSERT INTO R_PART
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"e20cf210-55d3-4cbb-811a-70be805336bc",
	0,
	1,
	'');
INSERT INTO R_RTO
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"e20cf210-55d3-4cbb-811a-70be805336bc",
	-1);
INSERT INTO R_OIR
	VALUES ("44c11680-c695-4cd0-8c5c-49bc06b14528",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"e20cf210-55d3-4cbb-811a-70be805336bc",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO R_PART
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"60251c1f-77e0-4287-b181-7495e1b03a1b",
	0,
	1,
	'is flying to');
INSERT INTO R_RTO
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"60251c1f-77e0-4287-b181-7495e1b03a1b",
	-1);
INSERT INTO R_OIR
	VALUES ("6248fd88-7e3e-4f89-957e-a82cef34c946",
	"b9ef235f-a534-468d-a18b-d8b6e8d8f69a",
	"60251c1f-77e0-4287-b181-7495e1b03a1b",
	"00000000-0000-0000-0000-000000000000");
INSERT INTO EP_PKG
	VALUES ("0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	"d923df31-2d4f-4454-ba3a-3347665a758b",
	'System',
	'',
	0);
INSERT INTO PE_PE
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	21);
INSERT INTO CL_IC
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	"8564596e-96e2-44e8-b970-aaa1a7d3b8bc",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'gnc::Library::MAV',
	'');
INSERT INTO CL_POR
	VALUES ("e2fb02b0-82c3-4b4a-bff8-10cc058eb3c1",
	"9df3483a-ab97-4ee7-8415-9b4b161408e2",
	'Port1',
	"aee86548-4fdd-4e44-b3e9-ed3ff3e556ba");
INSERT INTO CL_IIR
	VALUES ("1c1a54c7-9002-4457-8eec-f2719fd785d0",
	"93221829-0135-489c-961a-9d42c4252036",
	"aee86548-4fdd-4e44-b3e9-ed3ff3e556ba",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO CL_IP
	VALUES ("1c1a54c7-9002-4457-8eec-f2719fd785d0",
	'mavcontrol',
	'');
INSERT INTO CL_IPINS
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	"1c1a54c7-9002-4457-8eec-f2719fd785d0");
INSERT INTO PE_PE
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	21);
INSERT INTO CL_IC
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	"0d80503a-3f90-42a8-a2a9-2f52ccd4308f",
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	0,
	'',
	'gnc::Library::Control',
	'');
INSERT INTO CL_POR
	VALUES ("cffb1f34-17cc-4d13-a039-a12d622c8c8f",
	"bada52a0-1256-430d-8579-634b9c323fea",
	'Port1',
	"ffde1b3d-54d8-47c5-b766-3430cfb4a967");
INSERT INTO CL_IIR
	VALUES ("94bdc6ef-8903-4e4c-9eeb-1fbfe06732ca",
	"33610dbc-6887-421d-81c6-740629675b3d",
	"ffde1b3d-54d8-47c5-b766-3430cfb4a967",
	"00000000-0000-0000-0000-000000000000",
	'mavcontrol',
	'');
INSERT INTO CL_IR
	VALUES ("94bdc6ef-8903-4e4c-9eeb-1fbfe06732ca",
	"289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	'mavcontrol',
	'');
INSERT INTO PE_PE
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	1,
	"0a660bb5-dd76-44f4-9dea-3657b7b31a56",
	"00000000-0000-0000-0000-000000000000",
	22);
INSERT INTO C_SF
	VALUES ("289ca3e9-52ea-4ef6-95f3-c1b9a693f732",
	"33610dbc-6887-421d-81c6-740629675b3d",
	"93221829-0135-489c-961a-9d42c4252036",
	'',
	'MAV::Port1::mavcontrol -o)- Control::Port1::mavcontrol');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000000",
	0);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	"00000000-0000-0000-0000-000000000000",
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000001",
	1);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	"00000000-0000-0000-0000-000000000000",
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000002",
	2);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	"00000000-0000-0000-0000-000000000000",
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000003",
	3);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	"00000000-0000-0000-0000-000000000000",
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000004",
	4);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	"00000000-0000-0000-0000-000000000000",
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000005",
	5);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	"00000000-0000-0000-0000-000000000000",
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000006",
	6);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	"00000000-0000-0000-0000-000000000000",
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000007",
	7);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000008",
	8);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000009",
	9);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	"00000000-0000-0000-0000-000000000000",
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000a",
	10);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	"00000000-0000-0000-0000-000000000000",
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000b",
	11);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000c",
	12);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	"00000000-0000-0000-0000-000000000000",
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000d",
	13);
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	"00000000-0000-0000-0000-000000000000",
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000e",
	"ba5eda7a-def5-0000-0000-00000000000b",
	1,
	'');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	"00000000-0000-0000-0000-000000000000",
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-00000000000f",
	"ba5eda7a-def5-0000-0000-00000000000c",
	3,
	'');
INSERT INTO PE_PE
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	1,
	"00000000-0000-0000-0000-000000000000",
	"00000000-0000-0000-0000-000000000000",
	3);
INSERT INTO S_DT
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	"00000000-0000-0000-0000-000000000000",
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES ("ba5eda7a-def5-0000-0000-000000000010",
	"ba5eda7a-def5-0000-0000-000000000002",
	2,
	'');
