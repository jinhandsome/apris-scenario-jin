INSERT INTO O_OBJ VALUES ( "00000000-0000-0000-0000-0000000000be",'Controller',1,'Controller','',"00000000-0000-0000-0000-000000000000" );
INSERT INTO O_OBJ VALUES ( "00000000-0000-0000-0000-0000000000ca",'Waypoint',2,'Waypoint','',"00000000-0000-0000-0000-000000000000" );
INSERT INTO O_ATTR VALUES ( "00000000-0000-0000-0000-000000000183","00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-000000000000",'current_state','','','current_state',0,"00000000-0000-0000-0000-000000000184",'','' );
INSERT INTO O_ATTR VALUES ( "00000000-0000-0000-0000-000000000151","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-000000000000",'x','','','x',0,"00000000-0000-0000-0000-00000000006d",'','' );
INSERT INTO O_ATTR VALUES ( "00000000-0000-0000-0000-000000000153","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-000000000151",'y','','','y',0,"00000000-0000-0000-0000-00000000006d",'','' );
INSERT INTO O_ATTR VALUES ( "00000000-0000-0000-0000-000000000155","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-000000000153",'z','','','z',0,"00000000-0000-0000-0000-00000000006d",'','' );
INSERT INTO O_ID VALUES ( 0,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO O_ID VALUES ( 1,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO O_ID VALUES ( 2,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO O_ID VALUES ( 0,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_ID VALUES ( 1,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_ID VALUES ( 2,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_BATTR VALUES ( "00000000-0000-0000-0000-000000000183","00000000-0000-0000-0000-0000000000be" );
INSERT INTO O_BATTR VALUES ( "00000000-0000-0000-0000-000000000151","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_BATTR VALUES ( "00000000-0000-0000-0000-000000000153","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_BATTR VALUES ( "00000000-0000-0000-0000-000000000155","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_NBATTR VALUES ( "00000000-0000-0000-0000-000000000183","00000000-0000-0000-0000-0000000000be" );
INSERT INTO O_NBATTR VALUES ( "00000000-0000-0000-0000-000000000151","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_NBATTR VALUES ( "00000000-0000-0000-0000-000000000153","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO O_NBATTR VALUES ( "00000000-0000-0000-0000-000000000155","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-00000000004f",0 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-00000000003f",1 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-00000000000a",2 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-00000000006d",3 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-000000000056",4 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001d7",5 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-000000000184",6 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001d8",7 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000000c0",8 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001d9",9 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-000000000032",10 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001da",11 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001db",12 );
INSERT INTO S_CDT VALUES ( "00000000-0000-0000-0000-0000000001dc",13 );
INSERT INTO S_UDT VALUES ( "00000000-0000-0000-0000-000000000005","00000000-0000-0000-0000-0000000001da",1,'' );
INSERT INTO S_UDT VALUES ( "00000000-0000-0000-0000-00000000002f","00000000-0000-0000-0000-0000000001db",3,'' );
INSERT INTO S_UDT VALUES ( "00000000-0000-0000-0000-00000000002b","00000000-0000-0000-0000-00000000000a",2,'' );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000004","00000000-0000-0000-0000-000000000003",'current_date','',1,"00000000-0000-0000-0000-000000000005",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000008","00000000-0000-0000-0000-000000000003",'create_date','',1,"00000000-0000-0000-0000-000000000005",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000012","00000000-0000-0000-0000-000000000003",'get_second','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000016","00000000-0000-0000-0000-000000000003",'get_minute','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000001a","00000000-0000-0000-0000-000000000003",'get_hour','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000001e","00000000-0000-0000-0000-000000000003",'get_day','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000022","00000000-0000-0000-0000-000000000003",'get_month','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000026","00000000-0000-0000-0000-000000000003",'get_year','',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000002a","00000000-0000-0000-0000-000000000003",'current_clock','',1,"00000000-0000-0000-0000-00000000002b",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000003",'timer_start','This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',1,"00000000-0000-0000-0000-00000000002f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000003",'timer_start_recurring','This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',1,"00000000-0000-0000-0000-00000000002f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000003a","00000000-0000-0000-0000-000000000003",'timer_remaining_time','Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',1,"00000000-0000-0000-0000-00000000000a",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000003e","00000000-0000-0000-0000-000000000003",'timer_reset_time','This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',1,"00000000-0000-0000-0000-00000000003f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000044","00000000-0000-0000-0000-000000000003",'timer_add_time','This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',1,"00000000-0000-0000-0000-00000000003f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000049","00000000-0000-0000-0000-000000000003",'timer_cancel','This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',1,"00000000-0000-0000-0000-00000000003f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000004e","00000000-0000-0000-0000-00000000004d",'shutdown','',0,"00000000-0000-0000-0000-00000000004f",'control stop;',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000054","00000000-0000-0000-0000-000000000053",'LogSuccess','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000059","00000000-0000-0000-0000-000000000053",'LogFailure','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000005d","00000000-0000-0000-0000-000000000053",'LogInfo','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000061","00000000-0000-0000-0000-000000000053",'LogDate','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000066","00000000-0000-0000-0000-000000000053",'LogTime','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-00000000006b","00000000-0000-0000-0000-000000000053",'LogReal','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BRG VALUES ( "00000000-0000-0000-0000-000000000071","00000000-0000-0000-0000-000000000053",'LogInteger','',0,"00000000-0000-0000-0000-00000000004f",'',1,'',0 );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000009","00000000-0000-0000-0000-000000000008",'second',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-00000000000b",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000000c","00000000-0000-0000-0000-000000000008",'minute',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-00000000000d",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000000d","00000000-0000-0000-0000-000000000008",'hour',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-00000000000e",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000000e","00000000-0000-0000-0000-000000000008",'day',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000000b","00000000-0000-0000-0000-000000000008",'month',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-00000000000c",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000000f","00000000-0000-0000-0000-000000000008",'year',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000009",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000013","00000000-0000-0000-0000-000000000012",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000017","00000000-0000-0000-0000-000000000016",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000001b","00000000-0000-0000-0000-00000000001a",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000001f","00000000-0000-0000-0000-00000000001e",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000023","00000000-0000-0000-0000-000000000022",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000027","00000000-0000-0000-0000-000000000026",'date',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000030","00000000-0000-0000-0000-00000000002e",'microseconds',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000031",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-00000000002e",'event_inst',"00000000-0000-0000-0000-000000000032",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000036","00000000-0000-0000-0000-000000000035",'microseconds',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000037",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000037","00000000-0000-0000-0000-000000000035",'event_inst',"00000000-0000-0000-0000-000000000032",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000003b","00000000-0000-0000-0000-00000000003a",'timer_inst_ref',"00000000-0000-0000-0000-00000000002f",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000040","00000000-0000-0000-0000-00000000003e",'timer_inst_ref',"00000000-0000-0000-0000-00000000002f",0,'',"00000000-0000-0000-0000-000000000041",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000041","00000000-0000-0000-0000-00000000003e",'microseconds',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000045","00000000-0000-0000-0000-000000000044",'timer_inst_ref',"00000000-0000-0000-0000-00000000002f",0,'',"00000000-0000-0000-0000-000000000046",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000046","00000000-0000-0000-0000-000000000044",'microseconds',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000004a","00000000-0000-0000-0000-000000000049",'timer_inst_ref',"00000000-0000-0000-0000-00000000002f",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000055","00000000-0000-0000-0000-000000000054",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000005a","00000000-0000-0000-0000-000000000059",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000005e","00000000-0000-0000-0000-00000000005d",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000062","00000000-0000-0000-0000-000000000061",'d',"00000000-0000-0000-0000-000000000005",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000063","00000000-0000-0000-0000-000000000061",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000062",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000067","00000000-0000-0000-0000-000000000066",'t',"00000000-0000-0000-0000-00000000002b",0,'',"00000000-0000-0000-0000-000000000068",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000068","00000000-0000-0000-0000-000000000066",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000006c","00000000-0000-0000-0000-00000000006b",'r',"00000000-0000-0000-0000-00000000006d",0,'',"00000000-0000-0000-0000-00000000006e",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-00000000006e","00000000-0000-0000-0000-00000000006b",'message',"00000000-0000-0000-0000-000000000056",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO S_BPARM VALUES ( "00000000-0000-0000-0000-000000000072","00000000-0000-0000-0000-000000000071",'message',"00000000-0000-0000-0000-00000000000a",0,'',"00000000-0000-0000-0000-000000000000",'' );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-000000000002","00000000-0000-0000-0000-000000000001","00000000-0000-0000-0000-000000000001",'External Entities','',0 );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-000000000075","00000000-0000-0000-0000-000000000001","00000000-0000-0000-0000-000000000001",'Interfaces','',0 );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-000000000084","00000000-0000-0000-0000-000000000001","00000000-0000-0000-0000-000000000001",'Library','',0 );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-0000000000c1","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000001",'Functions','',0 );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000001",'Control','',0 );
INSERT INTO EP_PKG VALUES ( "00000000-0000-0000-0000-0000000001cf","00000000-0000-0000-0000-000000000001","00000000-0000-0000-0000-000000000001",'System','',0 );
INSERT INTO S_SYNC VALUES ( "00000000-0000-0000-0000-0000000000c2","00000000-0000-0000-0000-000000000000",'setup','','create object instance ctrl of Controller;
//generate Controller1:''start'' to ctrl;
create object instance wp1 of Waypoint;
wp1.x = 51;
wp1.y = 35;
wp1.z = 15;
relate ctrl to wp1 across R1.''begin with'';
relate ctrl to wp1 across R3.''is flying to'';

create object instance wp2 of Waypoint;
wp2.x = 131;
wp2.y = 35;
wp2.z = 15;
relate wp1 to wp2 across R2.''follows'';

create object instance wp3 of Waypoint;
wp3.x = 91;
wp3.y = 20;
wp3.z = 15;

relate wp2 to wp3 across R2.''follows'';

create object instance wp4 of Waypoint;
wp4.x = 51;
wp4.y = 20;
wp4.z = 15;

relate wp3 to wp4 across R2.''follows'';

create object instance wp5 of Waypoint;
wp5.x = 51;
wp5.y = 75;
wp5.z = 1;

relate wp4 to wp5 across R2.''follows'';

create object instance wp6 of Waypoint;
wp6.x = 151;
wp6.y = 75;
wp6.z = 1;

relate wp5 to wp6 across R2.''follows'';

create object instance wp7 of Waypoint;
wp7.x = 151;
wp7.y = 55;
wp7.z = 1;

relate wp6 to wp7 across R2.''follows'';

create object instance wp8 of Waypoint;
wp8.x = 111;
wp8.y = 55;
wp8.z = 1;

relate wp7 to wp8 across R2.''follows'';

create object instance wp9 of Waypoint;
wp9.x = 71;
wp9.y = 55;
wp9.z = 1;

relate wp8 to wp9 across R2.''follows'';

create object instance wp10 of Waypoint;
wp10.x = 0;
wp10.y = 0;
wp10.z = 1;

relate wp9 to wp10 across R2.''follows'';

create object instance wp11 of Waypoint;
wp10.x = 0;
wp10.y = 0;
wp10.z = 0;

relate wp10 to wp11 across R2.''follows'';













',"00000000-0000-0000-0000-00000000004f",1,'',0 );
INSERT INTO S_SYNC VALUES ( "00000000-0000-0000-0000-000000000174","00000000-0000-0000-0000-000000000000",'halt','','select any ctrl from instances of Controller;
generate Controller3:''halt'' to ctrl;
',"00000000-0000-0000-0000-00000000004f",1,'',0 );
INSERT INTO S_SYNC VALUES ( "00000000-0000-0000-0000-00000000017b","00000000-0000-0000-0000-000000000000",'start','','select any ctrl from instances of Controller;
generate Controller1:''start'' to ctrl;',"00000000-0000-0000-0000-00000000004f",1,'',0 );
INSERT INTO S_SYS VALUES ( "00000000-0000-0000-0000-000000000001",'gnc',1 );
INSERT INTO TE_CI VALUES ( "00000000-0000-0000-0000-000000000030",'MAV','iMAV','',"00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-0000000001d0" );
INSERT INTO TE_CI VALUES ( "00000000-0000-0000-0000-000000000034",'Control','iControl','',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-0000000001d4" );
INSERT INTO TE_OIR VALUES ( 'Waypoint_R3_is_flying_to','form','','is_flying_to',0,1,"00000000-0000-0000-0000-0000000001ce","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d7" );
INSERT INTO TE_OIR VALUES ( 'Controller_R3','part','','',0,0,"00000000-0000-0000-0000-0000000001cd","00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d7" );
INSERT INTO TE_OIR VALUES ( 'Waypoint_R1_begin_with','form','','begin_with',0,0,"00000000-0000-0000-0000-0000000001cc","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d5" );
INSERT INTO TE_OIR VALUES ( 'Controller_R1','part','','',0,0,"00000000-0000-0000-0000-0000000001cb","00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d5" );
INSERT INTO TE_OIR VALUES ( 'Waypoint_R2_follows','form','','follows',0,1,"00000000-0000-0000-0000-0000000001ca","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4" );
INSERT INTO TE_OIR VALUES ( 'Waypoint_R2_is_followed_by_','part','','is_followed_by_',0,0,"00000000-0000-0000-0000-0000000001c9","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4" );
INSERT INTO TE_SYS VALUES ( 1,'','',32,0,0,0,0,0,0,0,0,0,0,0,0,0,128,128,0,0,'','gnc','sc_interface',0,0,0,0,0,"00000000-0000-0000-0000-000000000001" );
INSERT INTO TE_DISP VALUES ( 1,1,'main','dispatcher','','' );
INSERT INTO TE_QUEUE VALUES ( 1,1,1,'Self Queue',0,0 );
INSERT INTO TE_QUEUE VALUES ( 2,1,2,'NonSelf Queue',0,0 );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000ef",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Port1_ready','void',0,"00000000-0000-0000-0000-000000000000",'','  Control_Controller * ctrl=0;
  /* SELECT any ctrl FROM INSTANCES OF Controller */
  XTUML_OAL_STMT_TRACE( 1, "SELECT any ctrl FROM INSTANCES OF Controller" );
  ctrl = (Control_Controller *) Escher_SetGetAny( &pG_Control_Controller_extent.active );
  /* GENERATE Controller2:ready() TO ctrl */
  XTUML_OAL_STMT_TRACE( 1, "GENERATE Controller2:ready() TO ctrl" );
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( ctrl, &Control_Controllerevent2c );
    Escher_SendEvent( e );
  }
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000f2",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Port1_get_heading','r_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000f5",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' const r_t ',' const r_t p_heading ','r_t p_heading;
',', p_heading','%f',' p_heading','','    e->p_heading = p_heading;','    e->p_heading = p_heading;','','Control_Port1_set_heading','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000f8",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' const r_t, const r_t, const r_t ',' const r_t p_x, const r_t p_y, const r_t p_z ','r_t p_x;
r_t p_y;
r_t p_z;
',', p_x, p_y, p_z','%f,%f,%f',' p_x, p_y, p_z','','    e->p_x = p_x;    e->p_y = p_y;    e->p_z = p_z;','    e->p_x = p_x;    e->p_y = p_y;    e->p_z = p_z;','','Control_Port1_set_destination','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000fb",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Port1_arm','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000000fe",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Port1_land','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000101",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' const r_t ',' const r_t p_alt ','r_t p_alt;
',', p_alt','%f',' p_alt','','    e->p_alt = p_alt;','    e->p_alt = p_alt;','','Control_Port1_takeoff','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000104",'TE_MACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Port1_init','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000107",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' void ','','','','','','','','','','MAV_Port1_ready','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-00000000010a",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' void ','','','','','','','','','','MAV_Port1_get_heading','r_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-00000000010d",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' const r_t ',' const r_t p_heading ','r_t p_heading;
',', p_heading','%f',' p_heading','','    e->p_heading = p_heading;','    e->p_heading = p_heading;','','MAV_Port1_set_heading','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000111",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' const r_t, const r_t, const r_t ',' const r_t p_x, const r_t p_y, const r_t p_z ','r_t p_x;
r_t p_y;
r_t p_z;
',', p_x, p_y, p_z','%f,%f,%f',' p_x, p_y, p_z','','    e->p_x = p_x;    e->p_y = p_y;    e->p_z = p_z;','    e->p_x = p_x;    e->p_y = p_y;    e->p_z = p_z;','','MAV_Port1_set_destination','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000117",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' void ','','','','','','','','','','MAV_Port1_arm','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-00000000011a",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' void ','','','','','','','','','','MAV_Port1_land','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-00000000011d",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' const r_t ',' const r_t p_alt ','r_t p_alt;
',', p_alt','%f',' p_alt','','    e->p_alt = p_alt;','    e->p_alt = p_alt;','','MAV_Port1_takeoff','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-000000000121",'TE_MACT',"00000000-0000-0000-0000-00000000002e",0,0,1,' void ','','','','','','','','','','MAV_Port1_init','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001b6",'S_SYNC',"00000000-0000-0000-0000-00000000002c",0,1,1,' void ','','','','','','','','','','Control_start','void',0,"00000000-0000-0000-0000-000000000000",'','  Control_Controller * ctrl=0;
  /* SELECT any ctrl FROM INSTANCES OF Controller */
  XTUML_OAL_STMT_TRACE( 1, "SELECT any ctrl FROM INSTANCES OF Controller" );
  ctrl = (Control_Controller *) Escher_SetGetAny( &pG_Control_Controller_extent.active );
  /* GENERATE Controller1:start() TO ctrl */
  XTUML_OAL_STMT_TRACE( 1, "GENERATE Controller1:start() TO ctrl" );
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( ctrl, &Control_Controllerevent1c );
    Escher_SendEvent( e );
  }
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001b7",'S_SYNC',"00000000-0000-0000-0000-00000000002c",0,1,1,' void ','','','','','','','','','','Control_halt','void',0,"00000000-0000-0000-0000-000000000000",'','  Control_Controller * ctrl=0;
  /* SELECT any ctrl FROM INSTANCES OF Controller */
  XTUML_OAL_STMT_TRACE( 1, "SELECT any ctrl FROM INSTANCES OF Controller" );
  ctrl = (Control_Controller *) Escher_SetGetAny( &pG_Control_Controller_extent.active );
  /* GENERATE Controller3:halt() TO ctrl */
  XTUML_OAL_STMT_TRACE( 1, "GENERATE Controller3:halt() TO ctrl" );
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( ctrl, &Control_Controllerevent3c );
    Escher_SendEvent( e );
  }
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001b8",'S_SYNC',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_setup','void',0,"00000000-0000-0000-0000-000000000000",'','  Control_Waypoint * wp11;Control_Waypoint * wp10;Control_Waypoint * wp9;Control_Waypoint * wp8;Control_Waypoint * wp7;Control_Waypoint * wp6;Control_Waypoint * wp5;Control_Waypoint * wp4;Control_Waypoint * wp3;Control_Waypoint * wp2;Control_Waypoint * wp1;Control_Controller * ctrl;
  /* CREATE OBJECT INSTANCE ctrl OF Controller */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE ctrl OF Controller" );
  ctrl = (Control_Controller *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Controller_CLASS_NUMBER );
  /* CREATE OBJECT INSTANCE wp1 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp1 OF Waypoint" );
  wp1 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp1.x = 51 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp1.x = 51" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp1, "Waypoint", "wp1.x" ))->x = 51;
  /* ASSIGN wp1.y = 35 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp1.y = 35" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp1, "Waypoint", "wp1.y" ))->y = 35;
  /* ASSIGN wp1.z = 15 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp1.z = 15" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp1, "Waypoint", "wp1.z" ))->z = 15;
  /* RELATE ctrl TO wp1 ACROSS R1 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE ctrl TO wp1 ACROSS R1" );
  Control_Waypoint_R1_Link_begin_with( ctrl, wp1 );
  /* RELATE ctrl TO wp1 ACROSS R3 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE ctrl TO wp1 ACROSS R3" );
  Control_Waypoint_R3_Link_is_flying_to( ctrl, wp1 );
  /* CREATE OBJECT INSTANCE wp2 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp2 OF Waypoint" );
  wp2 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp2.x = 131 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp2.x = 131" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp2, "Waypoint", "wp2.x" ))->x = 131;
  /* ASSIGN wp2.y = 35 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp2.y = 35" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp2, "Waypoint", "wp2.y" ))->y = 35;
  /* ASSIGN wp2.z = 15 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp2.z = 15" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp2, "Waypoint", "wp2.z" ))->z = 15;
  /* RELATE wp1 TO wp2 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp1 TO wp2 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp1, wp2 );
  /* CREATE OBJECT INSTANCE wp3 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp3 OF Waypoint" );
  wp3 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp3.x = 91 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp3.x = 91" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp3, "Waypoint", "wp3.x" ))->x = 91;
  /* ASSIGN wp3.y = 20 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp3.y = 20" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp3, "Waypoint", "wp3.y" ))->y = 20;
  /* ASSIGN wp3.z = 15 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp3.z = 15" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp3, "Waypoint", "wp3.z" ))->z = 15;
  /* RELATE wp2 TO wp3 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp2 TO wp3 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp2, wp3 );
  /* CREATE OBJECT INSTANCE wp4 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp4 OF Waypoint" );
  wp4 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp4.x = 51 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp4.x = 51" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp4, "Waypoint", "wp4.x" ))->x = 51;
  /* ASSIGN wp4.y = 20 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp4.y = 20" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp4, "Waypoint", "wp4.y" ))->y = 20;
  /* ASSIGN wp4.z = 15 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp4.z = 15" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp4, "Waypoint", "wp4.z" ))->z = 15;
  /* RELATE wp3 TO wp4 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp3 TO wp4 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp3, wp4 );
  /* CREATE OBJECT INSTANCE wp5 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp5 OF Waypoint" );
  wp5 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp5.x = 51 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp5.x = 51" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp5, "Waypoint", "wp5.x" ))->x = 51;
  /* ASSIGN wp5.y = 75 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp5.y = 75" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp5, "Waypoint", "wp5.y" ))->y = 75;
  /* ASSIGN wp5.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp5.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp5, "Waypoint", "wp5.z" ))->z = 1;
  /* RELATE wp4 TO wp5 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp4 TO wp5 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp4, wp5 );
  /* CREATE OBJECT INSTANCE wp6 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp6 OF Waypoint" );
  wp6 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp6.x = 151 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp6.x = 151" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp6, "Waypoint", "wp6.x" ))->x = 151;
  /* ASSIGN wp6.y = 75 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp6.y = 75" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp6, "Waypoint", "wp6.y" ))->y = 75;
  /* ASSIGN wp6.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp6.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp6, "Waypoint", "wp6.z" ))->z = 1;
  /* RELATE wp5 TO wp6 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp5 TO wp6 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp5, wp6 );
  /* CREATE OBJECT INSTANCE wp7 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp7 OF Waypoint" );
  wp7 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp7.x = 151 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp7.x = 151" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp7, "Waypoint", "wp7.x" ))->x = 151;
  /* ASSIGN wp7.y = 55 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp7.y = 55" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp7, "Waypoint", "wp7.y" ))->y = 55;
  /* ASSIGN wp7.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp7.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp7, "Waypoint", "wp7.z" ))->z = 1;
  /* RELATE wp6 TO wp7 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp6 TO wp7 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp6, wp7 );
  /* CREATE OBJECT INSTANCE wp8 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp8 OF Waypoint" );
  wp8 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp8.x = 111 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp8.x = 111" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp8, "Waypoint", "wp8.x" ))->x = 111;
  /* ASSIGN wp8.y = 55 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp8.y = 55" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp8, "Waypoint", "wp8.y" ))->y = 55;
  /* ASSIGN wp8.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp8.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp8, "Waypoint", "wp8.z" ))->z = 1;
  /* RELATE wp7 TO wp8 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp7 TO wp8 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp7, wp8 );
  /* CREATE OBJECT INSTANCE wp9 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp9 OF Waypoint" );
  wp9 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp9.x = 71 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp9.x = 71" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp9, "Waypoint", "wp9.x" ))->x = 71;
  /* ASSIGN wp9.y = 55 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp9.y = 55" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp9, "Waypoint", "wp9.y" ))->y = 55;
  /* ASSIGN wp9.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp9.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp9, "Waypoint", "wp9.z" ))->z = 1;
  /* RELATE wp8 TO wp9 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp8 TO wp9 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp8, wp9 );
  /* CREATE OBJECT INSTANCE wp10 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp10 OF Waypoint" );
  wp10 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp10.x = 0 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.x = 0" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.x" ))->x = 0;
  /* ASSIGN wp10.y = 0 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.y = 0" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.y" ))->y = 0;
  /* ASSIGN wp10.z = 1 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.z = 1" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.z" ))->z = 1;
  /* RELATE wp9 TO wp10 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp9 TO wp10 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp9, wp10 );
  /* CREATE OBJECT INSTANCE wp11 OF Waypoint */
  XTUML_OAL_STMT_TRACE( 1, "CREATE OBJECT INSTANCE wp11 OF Waypoint" );
  wp11 = (Control_Waypoint *) Escher_CreateInstance( Control_DOMAIN_ID, Control_Waypoint_CLASS_NUMBER );
  /* ASSIGN wp10.x = 0 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.x = 0" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.x" ))->x = 0;
  /* ASSIGN wp10.y = 0 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.y = 0" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.y" ))->y = 0;
  /* ASSIGN wp10.z = 0 */
  XTUML_OAL_STMT_TRACE( 1, "ASSIGN wp10.z = 0" );
  ((Control_Waypoint *)xtUML_detect_empty_handle( wp10, "Waypoint", "wp10.z" ))->z = 0;
  /* RELATE wp10 TO wp11 ACROSS R2 */
  XTUML_OAL_STMT_TRACE( 1, "RELATE wp10 TO wp11 ACROSS R2" );
  Control_Waypoint_R2_Link_follows( wp10, wp11 );
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001c0",'SM_ACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Controller_act1','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001c3",'SM_ACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Controller_act2','void',0,"00000000-0000-0000-0000-000000000000",'','  /* Port1::takeoff(alt:15) */
  XTUML_OAL_STMT_TRACE( 1, "Port1::takeoff(alt:15)" );
  Control_Port1_takeoff( 15 );
  /* Port1::set_heading(heading:0) */
  XTUML_OAL_STMT_TRACE( 1, "Port1::set_heading(heading:0)" );
  Control_Port1_set_heading( 0 );
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001c6",'SM_ACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Controller_act3','void',0,"00000000-0000-0000-0000-000000000000",'','  /* Port1::land() */
  XTUML_OAL_STMT_TRACE( 1, "Port1::land()" );
  Control_Port1_land();
  /* Port1::set_heading(heading:0) */
  XTUML_OAL_STMT_TRACE( 1, "Port1::set_heading(heading:0)" );
  Control_Port1_set_heading( 0 );
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001c9",'SM_ACT',"00000000-0000-0000-0000-00000000002c",0,0,1,' void ','','','','','','','','','','Control_Controller_act4','void',0,"00000000-0000-0000-0000-000000000000",'','  Control_Waypoint * next_wp=0;Control_Waypoint * wp=0;
  /* SELECT one wp RELATED BY self->Waypoint[R3.is flying to] */
  XTUML_OAL_STMT_TRACE( 1, "SELECT one wp RELATED BY self->Waypoint[R3.is flying to]" );
  wp = ( 0 != self ) ? self->Waypoint_R3_is_flying_to : 0;
  /* Port1::set_destination(x:wp.x, y:wp.y, z:wp.z) */
  XTUML_OAL_STMT_TRACE( 1, "Port1::set_destination(x:wp.x, y:wp.y, z:wp.z)" );
  Control_Port1_set_destination( ((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.x" ))->x, ((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.y" ))->y, ((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.z" ))->z );
  /* SELECT one next_wp RELATED BY wp->Waypoint[R2.follows] */
  XTUML_OAL_STMT_TRACE( 1, "SELECT one next_wp RELATED BY wp->Waypoint[R2.follows]" );
  next_wp = ( 0 != wp ) ? wp->Waypoint_R2_follows : 0;
  /* IF ( not_empty next_wp ) */
  XTUML_OAL_STMT_TRACE( 1, "IF ( not_empty next_wp )" );
  if ( ( 0 != next_wp ) ) {
    /* RELATE self TO next_wp ACROSS R3 */
    XTUML_OAL_STMT_TRACE( 2, "RELATE self TO next_wp ACROSS R3" );
    Control_Waypoint_R3_Link_is_flying_to( self, next_wp );
  }
  else {
    /* GENERATE Controller3:halt() TO self */
    XTUML_OAL_STMT_TRACE( 2, "GENERATE Controller3:halt() TO self" );
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( self, &Control_Controllerevent3c );
      Escher_SendSelfEvent( e );
    }
  }
' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001ce",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' void ','','','','','','','','','','TIM_current_date','Escher_Date_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001d0",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' const i_t, const i_t, const i_t, const i_t, const i_t, const i_t ',' const i_t p_day, const i_t p_hour, const i_t p_minute, const i_t p_month, const i_t p_second, const i_t p_year ','i_t p_day;
i_t p_hour;
i_t p_minute;
i_t p_month;
i_t p_second;
i_t p_year;
',', p_day, p_hour, p_minute, p_month, p_second, p_year','%d,%d,%d,%d,%d,%d',' p_day, p_hour, p_minute, p_month, p_second, p_year','','    e->p_day = p_day;    e->p_hour = p_hour;    e->p_minute = p_minute;    e->p_month = p_month;    e->p_second = p_second;    e->p_year = p_year;','    e->p_day = p_day;    e->p_hour = p_hour;    e->p_minute = p_minute;    e->p_month = p_month;    e->p_second = p_second;    e->p_year = p_year;','','TIM_create_date','Escher_Date_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001d2",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_second','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001d4",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_minute','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001d6",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_hour','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001d8",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_day','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001da",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_month','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001dc",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t ',' Escher_Date_t p_date ','Escher_Date_t p_date;
',', p_date','%d',' p_date','','    e->p_date = p_date;','    e->p_date = p_date;','','TIM_get_year','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001de",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' void ','','','','','','','','','','TIM_current_clock','Escher_TimeStamp_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001e0",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_xtUMLEvent_t *, const i_t ',' Escher_xtUMLEvent_t * p_event_inst, const i_t p_microseconds ','Escher_xtUMLEvent_t * p_event_inst;
i_t p_microseconds;
',', p_event_inst, p_microseconds','%p,%d',' p_event_inst, p_microseconds','','    e->p_event_inst = p_event_inst;    e->p_microseconds = p_microseconds;','    e->p_event_inst = p_event_inst;    e->p_microseconds = p_microseconds;','','TIM_timer_start','Escher_Timer_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001e2",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_xtUMLEvent_t *, const i_t ',' Escher_xtUMLEvent_t * p_event_inst, const i_t p_microseconds ','Escher_xtUMLEvent_t * p_event_inst;
i_t p_microseconds;
',', p_event_inst, p_microseconds','%p,%d',' p_event_inst, p_microseconds','','    e->p_event_inst = p_event_inst;    e->p_microseconds = p_microseconds;','    e->p_event_inst = p_event_inst;    e->p_microseconds = p_microseconds;','','TIM_timer_start_recurring','Escher_Timer_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001e4",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Timer_t ',' Escher_Timer_t p_timer_inst_ref ','Escher_Timer_t p_timer_inst_ref;
',', p_timer_inst_ref','%d',' p_timer_inst_ref','','    e->p_timer_inst_ref = p_timer_inst_ref;','    e->p_timer_inst_ref = p_timer_inst_ref;','','TIM_timer_remaining_time','i_t',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001e6",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' const i_t, Escher_Timer_t ',' const i_t p_microseconds, Escher_Timer_t p_timer_inst_ref ','i_t p_microseconds;
Escher_Timer_t p_timer_inst_ref;
',', p_microseconds, p_timer_inst_ref','%d,%d',' p_microseconds, p_timer_inst_ref','','    e->p_microseconds = p_microseconds;    e->p_timer_inst_ref = p_timer_inst_ref;','    e->p_microseconds = p_microseconds;    e->p_timer_inst_ref = p_timer_inst_ref;','','TIM_timer_reset_time','bool',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001e8",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' const i_t, Escher_Timer_t ',' const i_t p_microseconds, Escher_Timer_t p_timer_inst_ref ','i_t p_microseconds;
Escher_Timer_t p_timer_inst_ref;
',', p_microseconds, p_timer_inst_ref','%d,%d',' p_microseconds, p_timer_inst_ref','','    e->p_microseconds = p_microseconds;    e->p_timer_inst_ref = p_timer_inst_ref;','    e->p_microseconds = p_microseconds;    e->p_timer_inst_ref = p_timer_inst_ref;','','TIM_timer_add_time','bool',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001ea",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Timer_t ',' Escher_Timer_t p_timer_inst_ref ','Escher_Timer_t p_timer_inst_ref;
',', p_timer_inst_ref','%d',' p_timer_inst_ref','','    e->p_timer_inst_ref = p_timer_inst_ref;','    e->p_timer_inst_ref = p_timer_inst_ref;','','TIM_timer_cancel','bool',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001ec",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' void ','','','','','','','','','','ARCH_shutdown','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001ee",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' c_t[ESCHER_SYS_MAX_STRING_LEN] ',' c_t p_message[ESCHER_SYS_MAX_STRING_LEN] ','c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
','','[]',' p_message','','    Escher_strcpy( e->p_message, p_message );','    Escher_strcpy( e->p_message, p_message );','','LOG_LogSuccess','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001f0",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' c_t[ESCHER_SYS_MAX_STRING_LEN] ',' c_t p_message[ESCHER_SYS_MAX_STRING_LEN] ','c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
','','[]',' p_message','','    Escher_strcpy( e->p_message, p_message );','    Escher_strcpy( e->p_message, p_message );','','LOG_LogFailure','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001f2",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' c_t[ESCHER_SYS_MAX_STRING_LEN] ',' c_t p_message[ESCHER_SYS_MAX_STRING_LEN] ','c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
','','[]',' p_message','','    Escher_strcpy( e->p_message, p_message );','    Escher_strcpy( e->p_message, p_message );','','LOG_LogInfo','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001f4",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' Escher_Date_t, c_t[ESCHER_SYS_MAX_STRING_LEN] ',' Escher_Date_t p_d, c_t p_message[ESCHER_SYS_MAX_STRING_LEN] ','Escher_Date_t p_d;
c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
',', p_d','%d,[]',' p_d, p_message','','    e->p_d = p_d;    Escher_strcpy( e->p_message, p_message );','    e->p_d = p_d;    Escher_strcpy( e->p_message, p_message );','','LOG_LogDate','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001f6",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' c_t[ESCHER_SYS_MAX_STRING_LEN], const Escher_TimeStamp_t ',' c_t p_message[ESCHER_SYS_MAX_STRING_LEN], const Escher_TimeStamp_t p_t ','c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
Escher_TimeStamp_t p_t;
',', p_t','[],%d',' p_message, p_t','','    Escher_strcpy( e->p_message, p_message );    e->p_t = p_t;','    Escher_strcpy( e->p_message, p_message );    e->p_t = p_t;','','LOG_LogTime','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001f8",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' c_t[ESCHER_SYS_MAX_STRING_LEN], const r_t ',' c_t p_message[ESCHER_SYS_MAX_STRING_LEN], const r_t p_r ','c_t p_message[ESCHER_SYS_MAX_STRING_LEN];
r_t p_r;
',', p_r','[],%f',' p_message, p_r','','    Escher_strcpy( e->p_message, p_message );    e->p_r = p_r;','    Escher_strcpy( e->p_message, p_message );    e->p_r = p_r;','','LOG_LogReal','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_ABA VALUES ( "00000000-0000-0000-0000-0000000001fa",'S_BRG',"00000000-0000-0000-0000-000000000000",0,0,1,' const i_t ',' const i_t p_message ','i_t p_message;
',', p_message','%d',' p_message','','    e->p_message = p_message;','    e->p_message = p_message;','','LOG_LogInteger','void',0,"00000000-0000-0000-0000-000000000000",'','' );
INSERT INTO TE_C VALUES ( "00000000-0000-0000-0000-00000000002c",'Control','',0,1,1,1,0,0,1,0,'Control_classes',30,0,0,1,1,0,0,0,0,0,'Control',1,1,0,1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000004e",'','','"Controller","Waypoint"',"00000000-0000-0000-0000-00000000004a" );
INSERT INTO TE_C VALUES ( "00000000-0000-0000-0000-00000000002e",'MAV','',0,1,1,1,0,0,1,0,'MAV_classes',0,0,0,1,1,0,0,0,0,0,'MAV',1,0,0,1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000085","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",'','','',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_EE VALUES ( 'Logging','LOG','LOG','',0,'LOG_bridge','LOG_bridge.h',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000053","00000000-0000-0000-0000-000000000052","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_EE VALUES ( 'Architecture','ARCH','ARCH','',0,'ARCH_bridge','ARCH_bridge.h',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000004d","00000000-0000-0000-0000-000000000054","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_EE VALUES ( 'Time','TIM','TIM','The Time external entity provides date, timestamp, and timer related operations.',0,'TIM_bridge','TIM_bridge.h',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000003","00000000-0000-0000-0000-000000000056","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000038",'timestamp',2,1,'Escher_TimeStamp_t','gnc_sys_types.h','CTOR','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002b" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000039",'inst_ref<Timer>',12,1,'Escher_Timer_t','gnc_sys_types.h','0','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002f" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003a",'date',11,1,'Escher_Date_t','gnc_sys_types.h','CTOR','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000005" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003b",'component_ref',13,0,'','gnc_sys_types.h','','',0,'gnc','%x',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001dc" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003c",'inst_ref<Mapping>',12,0,'i_t','gnc_sys_types.h','0','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001db" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003d",'inst<Mapping>',11,0,'','gnc_sys_types.h','','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001da" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003e",'inst<Event>',10,1,'Escher_xtUMLEvent_t *','gnc_sys_types.h','0','',0,'gnc','%p',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000032" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-00000000003f",'inst_ref_set<Object>',9,0,'Escher_ObjectSet_s *','gnc_sys_types.h','','',0,'gnc','%p',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001d9" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000040",'inst_ref<Object>',8,0,'void *','gnc_sys_types.h','','',0,'gnc','%p',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000c0" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000041",'same_as<Base_Attribute>',7,0,'','gnc_sys_types.h','','',0,'gnc','%p',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001d8" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000042",'state<State_Model>',6,0,'','gnc_sys_types.h','','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000184" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000043",'unique_id',5,0,'Escher_UniqueID_t','gnc_sys_types.h','0','',0,'gnc','%s',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001d7" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000044",'string',4,1,'c_t','gnc_sys_types.h','CTOR','',0,'gnc','%s',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000056" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000045",'real',3,1,'r_t','gnc_sys_types.h','0.0','',0,'gnc','%f',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000006d" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000046",'integer',2,1,'i_t','gnc_sys_types.h','0','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000a" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000047",'boolean',1,0,'bool','gnc_sys_types.h','false','',0,'gnc','%d',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000003f" );
INSERT INTO TE_DT VALUES ( "00000000-0000-0000-0000-000000000048",'void',0,0,'void','gnc_sys_types.h','0','',0,'gnc','',0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000004f" );
INSERT INTO TE_ACT VALUES ( "00000000-0000-0000-0000-0000000001c0",'Control_Controller_act1',0,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000187" );
INSERT INTO TE_ACT VALUES ( "00000000-0000-0000-0000-0000000001c3",'Control_Controller_act2',0,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018b" );
INSERT INTO TE_ACT VALUES ( "00000000-0000-0000-0000-0000000001c6",'Control_Controller_act3',0,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000193" );
INSERT INTO TE_ACT VALUES ( "00000000-0000-0000-0000-0000000001c9",'Control_Controller_act4',0,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000019a" );
INSERT INTO TE_SYNC VALUES ( 'start',0,0,0,1,0,"00000000-0000-0000-0000-0000000001b6",'Control_start','Control_start','Control_start_deferred',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-00000000017b","00000000-0000-0000-0000-00000000004c","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_SYNC VALUES ( 'halt',0,0,0,1,0,"00000000-0000-0000-0000-0000000001b7",'Control_halt','Control_halt','Control_halt_deferred',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000174","00000000-0000-0000-0000-00000000004e","00000000-0000-0000-0000-000000000050" );
INSERT INTO TE_SYNC VALUES ( 'setup',0,1,0,1,0,"00000000-0000-0000-0000-0000000001b8",'Control_setup','Control_setup','Control_setup_deferred',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-0000000000c2","00000000-0000-0000-0000-000000000050","00000000-0000-0000-0000-00000000004c" );
INSERT INTO R_REL VALUES ( "00000000-0000-0000-0000-0000000000e4",2,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO R_REL VALUES ( "00000000-0000-0000-0000-0000000000d5",1,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO R_REL VALUES ( "00000000-0000-0000-0000-0000000000d7",3,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','current_date','TIM_current_date',"00000000-0000-0000-0000-0000000001ce","00000000-0000-0000-0000-000000000004","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','create_date','TIM_create_date',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000008","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_second','TIM_get_second',"00000000-0000-0000-0000-0000000001d2","00000000-0000-0000-0000-000000000012","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_minute','TIM_get_minute',"00000000-0000-0000-0000-0000000001d4","00000000-0000-0000-0000-000000000016","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_hour','TIM_get_hour',"00000000-0000-0000-0000-0000000001d6","00000000-0000-0000-0000-00000000001a","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_day','TIM_get_day',"00000000-0000-0000-0000-0000000001d8","00000000-0000-0000-0000-00000000001e","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_month','TIM_get_month',"00000000-0000-0000-0000-0000000001da","00000000-0000-0000-0000-000000000022","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','get_year','TIM_get_year',"00000000-0000-0000-0000-0000000001dc","00000000-0000-0000-0000-000000000026","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','current_clock','TIM_current_clock',"00000000-0000-0000-0000-0000000001de","00000000-0000-0000-0000-00000000002a","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_start','TIM_timer_start',"00000000-0000-0000-0000-0000000001e0","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_start_recurring','TIM_timer_start_recurring',"00000000-0000-0000-0000-0000000001e2","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_remaining_time','TIM_timer_remaining_time',"00000000-0000-0000-0000-0000000001e4","00000000-0000-0000-0000-00000000003a","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_reset_time','TIM_timer_reset_time',"00000000-0000-0000-0000-0000000001e6","00000000-0000-0000-0000-00000000003e","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_add_time','TIM_timer_add_time',"00000000-0000-0000-0000-0000000001e8","00000000-0000-0000-0000-000000000044","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Time','TIM','timer_cancel','TIM_timer_cancel',"00000000-0000-0000-0000-0000000001ea","00000000-0000-0000-0000-000000000049","00000000-0000-0000-0000-000000000003" );
INSERT INTO TE_BRG VALUES ( 'Architecture','ARCH','shutdown','ARCH_shutdown',"00000000-0000-0000-0000-0000000001ec","00000000-0000-0000-0000-00000000004e","00000000-0000-0000-0000-00000000004d" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogSuccess','LOG_LogSuccess',"00000000-0000-0000-0000-0000000001ee","00000000-0000-0000-0000-000000000054","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogFailure','LOG_LogFailure',"00000000-0000-0000-0000-0000000001f0","00000000-0000-0000-0000-000000000059","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogInfo','LOG_LogInfo',"00000000-0000-0000-0000-0000000001f2","00000000-0000-0000-0000-00000000005d","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogDate','LOG_LogDate',"00000000-0000-0000-0000-0000000001f4","00000000-0000-0000-0000-000000000061","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogTime','LOG_LogTime',"00000000-0000-0000-0000-0000000001f6","00000000-0000-0000-0000-000000000066","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogReal','LOG_LogReal',"00000000-0000-0000-0000-0000000001f8","00000000-0000-0000-0000-00000000006b","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_BRG VALUES ( 'Logging','LOG','LogInteger','LOG_LogInteger',"00000000-0000-0000-0000-0000000001fa","00000000-0000-0000-0000-000000000071","00000000-0000-0000-0000-000000000053" );
INSERT INTO TE_PARM VALUES ( 'A0xtumlsret','',0,'','',"00000000-0000-0000-0000-000000000057","00000000-0000-0000-0000-000000000000",'A0xtumlsret',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000c8","00000000-0000-0000-0000-000000000000",'p_message',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001fa","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000072" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000c9","00000000-0000-0000-0000-0000000000ca",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001f8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000006e" );
INSERT INTO TE_PARM VALUES ( 'r','',1,'','',"00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-000000000000",'p_r',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001f8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000006c" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000cb","00000000-0000-0000-0000-0000000000cc",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001f6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000068" );
INSERT INTO TE_PARM VALUES ( 't','',1,'','',"00000000-0000-0000-0000-0000000000cc","00000000-0000-0000-0000-000000000000",'p_t',0,"00000000-0000-0000-0000-000000000038",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001f6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000067" );
INSERT INTO TE_PARM VALUES ( 'message','',1,'','',"00000000-0000-0000-0000-0000000000cd","00000000-0000-0000-0000-000000000000",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001f4","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000063" );
INSERT INTO TE_PARM VALUES ( 'd','',0,'','',"00000000-0000-0000-0000-0000000000ce","00000000-0000-0000-0000-0000000000cd",'p_d',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001f4","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000062" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000cf","00000000-0000-0000-0000-000000000000",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001f2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000005e" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000d0","00000000-0000-0000-0000-000000000000",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001f0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000005a" );
INSERT INTO TE_PARM VALUES ( 'message','',0,'','',"00000000-0000-0000-0000-0000000000d1","00000000-0000-0000-0000-000000000000",'p_message',0,"00000000-0000-0000-0000-000000000044",1,"00000000-0000-0000-0000-000000000000",'[ESCHER_SYS_MAX_STRING_LEN]',"00000000-0000-0000-0000-0000000001ee","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000055" );
INSERT INTO TE_PARM VALUES ( 'timer_inst_ref','',0,'','',"00000000-0000-0000-0000-0000000000d2","00000000-0000-0000-0000-000000000000",'p_timer_inst_ref',0,"00000000-0000-0000-0000-000000000039",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001ea","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000004a" );
INSERT INTO TE_PARM VALUES ( 'microseconds','',0,'','',"00000000-0000-0000-0000-0000000000d3","00000000-0000-0000-0000-0000000000d4",'p_microseconds',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000046" );
INSERT INTO TE_PARM VALUES ( 'timer_inst_ref','',1,'','',"00000000-0000-0000-0000-0000000000d4","00000000-0000-0000-0000-000000000000",'p_timer_inst_ref',0,"00000000-0000-0000-0000-000000000039",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000045" );
INSERT INTO TE_PARM VALUES ( 'microseconds','',0,'','',"00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000000d6",'p_microseconds',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000041" );
INSERT INTO TE_PARM VALUES ( 'timer_inst_ref','',1,'','',"00000000-0000-0000-0000-0000000000d6","00000000-0000-0000-0000-000000000000",'p_timer_inst_ref',0,"00000000-0000-0000-0000-000000000039",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000040" );
INSERT INTO TE_PARM VALUES ( 'timer_inst_ref','',0,'','',"00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-000000000000",'p_timer_inst_ref',0,"00000000-0000-0000-0000-000000000039",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e4","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000003b" );
INSERT INTO TE_PARM VALUES ( 'event_inst','',0,'','',"00000000-0000-0000-0000-0000000000d8","00000000-0000-0000-0000-0000000000d9",'p_event_inst',0,"00000000-0000-0000-0000-00000000003e",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000037" );
INSERT INTO TE_PARM VALUES ( 'microseconds','',1,'','',"00000000-0000-0000-0000-0000000000d9","00000000-0000-0000-0000-000000000000",'p_microseconds',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000036" );
INSERT INTO TE_PARM VALUES ( 'event_inst','',0,'','',"00000000-0000-0000-0000-0000000000da","00000000-0000-0000-0000-0000000000db",'p_event_inst',0,"00000000-0000-0000-0000-00000000003e",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000031" );
INSERT INTO TE_PARM VALUES ( 'microseconds','',1,'','',"00000000-0000-0000-0000-0000000000db","00000000-0000-0000-0000-000000000000",'p_microseconds',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001e0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000030" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000dc","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001dc","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000027" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000dd","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001da","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000023" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000de","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000001f" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000df","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000001b" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000e0","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d4","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000017" );
INSERT INTO TE_PARM VALUES ( 'date','',0,'','',"00000000-0000-0000-0000-0000000000e1","00000000-0000-0000-0000-000000000000",'p_date',0,"00000000-0000-0000-0000-00000000003a",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000013" );
INSERT INTO TE_PARM VALUES ( 'year','',5,'','',"00000000-0000-0000-0000-0000000000e2","00000000-0000-0000-0000-000000000000",'p_year',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000f" );
INSERT INTO TE_PARM VALUES ( 'month','',3,'','',"00000000-0000-0000-0000-0000000000e3","00000000-0000-0000-0000-0000000000e7",'p_month',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000b" );
INSERT INTO TE_PARM VALUES ( 'day','',0,'','',"00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000000e5",'p_day',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000e" );
INSERT INTO TE_PARM VALUES ( 'hour','',1,'','',"00000000-0000-0000-0000-0000000000e5","00000000-0000-0000-0000-0000000000e6",'p_hour',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000d" );
INSERT INTO TE_PARM VALUES ( 'minute','',2,'','',"00000000-0000-0000-0000-0000000000e6","00000000-0000-0000-0000-0000000000e3",'p_minute',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000000c" );
INSERT INTO TE_PARM VALUES ( 'second','',4,'','',"00000000-0000-0000-0000-0000000000e7","00000000-0000-0000-0000-0000000000e2",'p_second',0,"00000000-0000-0000-0000-000000000046",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000009" );
INSERT INTO TE_PARM VALUES ( 'heading','',0,'0','heading:0',"00000000-0000-0000-0000-0000000000e8","00000000-0000-0000-0000-000000000000",'p_heading',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000000f5","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000081","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'z','',2,'','',"00000000-0000-0000-0000-0000000000e9","00000000-0000-0000-0000-000000000000",'p_z',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000000f8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000007f","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'y','',1,'','',"00000000-0000-0000-0000-0000000000ea","00000000-0000-0000-0000-0000000000e9",'p_y',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000000f8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000007e","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'x','',0,'((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.x" ))->x, ((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.y" ))->y, ((Control_Waypoint *)xtUML_detect_empty_handle( wp, "Waypoint", "wp.z" ))->z','x:wp.x, y:wp.y, z:wp.z',"00000000-0000-0000-0000-0000000000eb","00000000-0000-0000-0000-0000000000ea",'p_x',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-0000000000f8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000007d","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'alt','',0,'15','alt:15',"00000000-0000-0000-0000-0000000000ec","00000000-0000-0000-0000-000000000000",'p_alt',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-000000000101","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000079","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'heading','',0,'','',"00000000-0000-0000-0000-00000000010e","00000000-0000-0000-0000-000000000000",'p_heading',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-00000000010d","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'x','',0,'','',"00000000-0000-0000-0000-000000000112","00000000-0000-0000-0000-000000000113",'p_x',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-000000000111","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'y','',1,'','',"00000000-0000-0000-0000-000000000113","00000000-0000-0000-0000-000000000114",'p_y',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-000000000111","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'z','',2,'','',"00000000-0000-0000-0000-000000000114","00000000-0000-0000-0000-000000000000",'p_z',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-000000000111","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PARM VALUES ( 'alt','',0,'','',"00000000-0000-0000-0000-00000000011e","00000000-0000-0000-0000-000000000000",'p_alt',0,"00000000-0000-0000-0000-000000000045",0,"00000000-0000-0000-0000-000000000000",'',"00000000-0000-0000-0000-00000000011d","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Waypoint_AnyWhere1',0,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Waypoint_AnyWhere2',1,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Waypoint_AnyWhere3',2,"00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Controller_AnyWhere1',0,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Controller_AnyWhere2',1,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO TE_WHERE VALUES ( 0,'Control_Controller_AnyWhere3',2,"00000000-0000-0000-0000-0000000000be" );
INSERT INTO TE_ATTR VALUES ( "00000000-0000-0000-0000-0000000001b9",1,1,1,0,0,'','x','x','',1,0,"00000000-0000-0000-0000-000000000000",'','Control_Waypoint','r_t',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000151","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_ATTR VALUES ( "00000000-0000-0000-0000-0000000001ba",1,1,1,0,0,'','y','y','',1,0,"00000000-0000-0000-0000-000000000000",'','Control_Waypoint','r_t',"00000000-0000-0000-0000-0000000001b9","00000000-0000-0000-0000-000000000153","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_ATTR VALUES ( "00000000-0000-0000-0000-0000000001bb",1,1,1,0,0,'','z','z','',1,0,"00000000-0000-0000-0000-000000000000",'','Control_Waypoint','r_t',"00000000-0000-0000-0000-0000000001ba","00000000-0000-0000-0000-000000000155","00000000-0000-0000-0000-0000000000ca" );
INSERT INTO TE_ATTR VALUES ( "00000000-0000-0000-0000-0000000001bc",0,0,0,0,0,'','current_state','current_state','',1,0,"00000000-0000-0000-0000-000000000000",'','Control_Controller','',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000183","00000000-0000-0000-0000-0000000000be" );
INSERT INTO TE_REL VALUES ( 3,1,0,1,0,0,"00000000-0000-0000-0000-0000000000d7" );
INSERT INTO TE_REL VALUES ( 1,1,0,0,0,0,"00000000-0000-0000-0000-0000000000d5" );
INSERT INTO TE_REL VALUES ( 2,1,0,1,0,0,"00000000-0000-0000-0000-0000000000e4" );
INSERT INTO TE_EVT VALUES ( "00000000-0000-0000-0000-0000000001ca",'start',1,'Control_Controllerevent1','CONTROL_CONTROLLEREVENT1NUM',0,1,1,0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-0000000001bd","00000000-0000-0000-0000-0000000001cb" );
INSERT INTO TE_EVT VALUES ( "00000000-0000-0000-0000-0000000001cb",'ready',2,'Control_Controllerevent2','CONTROL_CONTROLLEREVENT2NUM',1,1,1,0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-0000000001bd","00000000-0000-0000-0000-0000000001cc" );
INSERT INTO TE_EVT VALUES ( "00000000-0000-0000-0000-0000000001cc",'halt',3,'Control_Controllerevent3','CONTROL_CONTROLLEREVENT3NUM',2,1,1,0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-0000000001bd","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_STATE VALUES ( "00000000-0000-0000-0000-0000000001be",'init','Control_Controller_STATE_1',1,1,0,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-0000000001c1" );
INSERT INTO TE_STATE VALUES ( "00000000-0000-0000-0000-0000000001c1",'take off','Control_Controller_STATE_2',2,2,1,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-0000000001c4" );
INSERT INTO TE_STATE VALUES ( "00000000-0000-0000-0000-0000000001c4",'land','Control_Controller_STATE_3',3,3,2,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-0000000001c7" );
INSERT INTO TE_STATE VALUES ( "00000000-0000-0000-0000-0000000001c7",'go','Control_Controller_STATE_4',4,4,3,"00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001c9","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001ca","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cb","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cc","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001cd","00000000-0000-0000-0000-000000000000" );
INSERT INTO R_OIR VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001ce","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_PO VALUES ( "00000000-0000-0000-0000-000000000031",'Port1','Port1','mavcontrol','','','',1,0,0,0,"00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000076","00000000-0000-0000-0000-000000000086","00000000-0000-0000-0000-000000000116" );
INSERT INTO TE_PO VALUES ( "00000000-0000-0000-0000-000000000035",'Port1','Port1','mavcontrol','','','',0,0,0,0,"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000076","00000000-0000-0000-0000-0000000000a1","00000000-0000-0000-0000-0000000000fa" );
INSERT INTO TE_SM VALUES ( "00000000-0000-0000-0000-0000000001bd",1,'Control_Controller_STATE_1','Control_Controller_StateEventMatrix','Control_Controller_acts','StateAction_t','Control_Controller_Events_u','Control_Controller_xacts',0,'state_name_strings',4,3,"00000000-0000-0000-0000-000000000185",'Control_Controller',"00000000-0000-0000-0000-0000000001be","00000000-0000-0000-0000-0000000001ca",'"init","take off","land","go"','"start","ready","halt"',0 );
INSERT INTO TE_CLASS VALUES ( "00000000-0000-0000-0000-000000000049",'Waypoint',2,'Waypoint','','Control_Waypoint','Control_Waypoint_CB',0,0,0,0,0,20,0,1,0,0,1,0,0,'Control_Waypoint_class','Control_Waypoint_CLASS_NUMBER','Control_Waypoint_CLASS_NUMBER_CB','Control_Waypoint_LinkCentral','','','%f,%f,%f',',
    self->x,
    self->y,
    self->z',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_CLASS VALUES ( "00000000-0000-0000-0000-00000000004a",'Controller',1,'Controller','','Control_Controller','Control_Controller_CB',1,0,0,0,0,10,0,1,0,0,1,0,0,'Control_Controller_class','Control_Controller_CLASS_NUMBER','Control_Controller_CLASS_NUMBER_CB','Control_Controller_LinkCentral','Control_Controller_Dispatch','','%d',',
    self->current_state',"00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-000000000049" );
INSERT INTO TE_PREFIX VALUES ( 'Escher_','','Escher_','','ESCHER_','Escher_','','','','Escher_','pport_','rport_','channel_' );
INSERT INTO TE_SET VALUES ( 'SYS_MAX_CONTAINERS','Escher_Iterator_s','Escher_SetFactoryInit','Escher_InitSet','Escher_CopySet','Escher_ClearSet','Escher_SetUnion','Escher_SetIntersection','Escher_SetDifference','Escher_SetSymmetricDifference','Escher_SetInsertElement','Escher_SetInsertInstance','Escher_SetInsertBlock','Escher_SetRemoveElement','Escher_SetRemoveInstance','Escher_SetCardinality','Escher_SetContains','Escher_SetEquality','Escher_SetIsEmpty','Escher_SetGetAny','Escher_IteratorReset','Escher_IteratorNext','Escher_ObjectSet_s','Escher_SetElement_s','','' );
INSERT INTO TE_PERSIST VALUES ( 'sys_persist','','ESCHER_PERSIST_INST_CACHE_DEPTH','ESCHER_PERSIST_LINK_CACHE_DEPTH','check_mark_post','','Escher_link_t','','Escher_PersistFactoryInit','Escher_PersistenceCommit','Escher_PersistenceRestore','Escher_PersistDelete','domainnum','Escher_DomainNumber_t','classnum','Escher_ClassNumber_t','index','Escher_InstanceIndex_t','InstanceIdentifier_t','instance_identifier','s1_t','persist_dirty',1,0 );
INSERT INTO R_RTO VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001c9",-1 );
INSERT INTO R_RTO VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cb",-1 );
INSERT INTO R_RTO VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001cd",-1 );
INSERT INTO TE_EQ VALUES ( 'EVENT_IS_IGNORED','EVENT_CANT_HAPPEN','Escher_systemxtUMLevents','Escher_xtUML_event_pool','Escher_xtUMLEventConstant_t','Escher_xtUMLEvent_t','mc_event_base','ESCHER_SYS_MAX_XTUML_EVENTS','ESCHER_SYS_MAX_SELF_EVENTS','ESCHER_SYS_MAX_NONSELF_EVENTS','Escher_NewxtUMLEvent','Escher_AllocatextUMLEvent','Escher_DeletextUMLEvent','Escher_ModifyxtUMLEvent','Escher_SendSelfEvent','Escher_SendEvent','Escher_EventSearchAndDestroy','Escher_run_flag','e','' );
INSERT INTO TE_ILB VALUES ( '','ESCHER_SYS_MAX_INTERLEAVED_BRIDGES','ESCHER_SYS_MAX_INTERLEAVED_BRIDGE_DATA','InterleaveBridge','InterleaveBridgeDone','GetILBData','DispatchInterleaveBridge' );
INSERT INTO TE_THREAD VALUES ( 'sys_thread','Escher_thread_create','Escher_mutex_lock','Escher_mutex_unlock','Escher_nonbusy_wait','Escher_nonbusy_wake','Escher_thread_shutdown',0,'POSIX',0,1,'' );
INSERT INTO TE_FILE VALUES ( 'h','c','o','gnc_sys_main','sys_xtuml','sys_events','sys_nvs','NVS_bridge','sys_sets','gnc_sys_types','sys_thread','sys_trace','TIM_bridge','sys_user_co','','sys_persist','sys_xtumlload','sysc_interfaces','RegDefs','.','_ch','_ch','_ch','_ch','.','bridge.mark','system.mark','datatype.mark','event.mark','class.mark','domain.mark','sys_functions.arc','mc3020/arc','.' );
INSERT INTO TE_CALLOUT VALUES ( 'sys_user_co','UserInitializationCallout','UserPreOoaInitializationCallout','UserPostOoaInitializationCallout','UserBackgroundProcessingCallout','UserEventCantHappenCallout','UserPreShutdownCallout','UserPostShutdownCallout','UserEventNoInstanceCallout','UserEventFreeListEmptyCallout','UserEmptyHandleDetectedCallout','UserObjectPoolEmptyCallout','UserNodeListEmptyCallout','UserInterleavedBridgeOverflowCallout','UserSelfEventQueueEmptyCallout','UserNonSelfEventQueueEmptyCallout','UserPersistenceErrorCallout' );
INSERT INTO TE_STRING VALUES ( 'Escher_memset','Escher_memmove','Escher_strcpy','Escher_stradd','Escher_strlen','Escher_strcmp','Escher_strget','Escher_itoa','Escher_atoi','ESCHER_SYS_MAX_STRING_LEN','ESCHER_DEBUG_BUFFER_DEPTH','Escher_u128touuid','Escher_uuidtou128' );
INSERT INTO TE_TRACE VALUES ( 'COMP_MSG_START_TRACE','COMP_MSG_END_TRACE','STATE_TXN_START_TRACE','STATE_TXN_END_TRACE','STATE_TXN_IG_TRACE','STATE_TXN_CH_TRACE','OAL_ACTION_TRACE' );
INSERT INTO TE_COPYRIGHT VALUES ( 'your copyright statement can go here (from te_copyright.body)' );
INSERT INTO TE_DMA VALUES ( 'sys_memory','Escher_malloc','Escher_free',0 );
INSERT INTO TE_CONTAINER VALUES ( '' );
INSERT INTO R_RGO VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001ce" );
INSERT INTO R_RGO VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cc" );
INSERT INTO R_RGO VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001ca" );
INSERT INTO TE_DLIST VALUES ( '','Escher_SetRemoveDlistNode' );
INSERT INTO TE_SLIST VALUES ( '','Escher_SetRemoveNode' );
INSERT INTO TE_TARGET VALUES ( 'C','#ifdef	__cplusplus
extern	"C"	{
#endif','#ifdef	__cplusplus
}
#endif','main' );
INSERT INTO R_SIMP VALUES ( "00000000-0000-0000-0000-0000000000e4" );
INSERT INTO R_SIMP VALUES ( "00000000-0000-0000-0000-0000000000d5" );
INSERT INTO R_SIMP VALUES ( "00000000-0000-0000-0000-0000000000d7" );
INSERT INTO TE_RELINFO VALUES ( "00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,0,'',0,0,0,0 );
INSERT INTO TE_RELSTORE VALUES ( '','','',0,'','self' );
INSERT INTO TE_INSTANCE VALUES ( 'Escher_CreateInstance','Escher_CreatePersistent','Escher_DeleteInstance','Escher_DeletePersistent','self','Escher_GetSelf','Escher_InstanceBase_t','Escher_iHandle_t','Escher_ClassFactoryInit','Escher_Object_s','ESCHER_SYS_MAX_OBJECT_EXTENT','ESCHER_SYS_MAX_ASSOCIATION_EXTENT','ESCHER_SYS_MAX_TRANSIENT_EXTENT','current_state','','Escher_GetDCI','Escher_GetEventDispatcher','Escher_GetThreadAssignment','' );
INSERT INTO TE_TIM VALUES ( 'ESCHER_SYS_MAX_XTUML_TIMERS',1,1,0,'ETimer_t','','' );
INSERT INTO TE_TYPEMAP VALUES ( 'Escher_InstanceIndex_t','u2_t','Escher_ClassSize_t','Escher_size_t','Escher_ClassNumber_t','u2_t','Escher_StateNumber_t','u1_t','Escher_DomainNumber_t','u1_t','Escher_EventNumber_t','u1_t','Escher_EventPriority_t','u1_t','Escher_EventFlags_t','u1_t','Escher_PolyEventRC_t','u1_t','Escher_SEMcell_t','u1_t','','','' );
INSERT INTO TE_EXTENT VALUES ( 'Escher_ObjectSet_s','Escher_Extent_t','active','inactive','','Escher_ClassSize_t','size','Escher_StateNumber_t','initial_state','Escher_SetElement_s*','container','Escher_iHandle_t','pool','Escher_InstanceIndex_t','population','Escher_ClassSize_t','size_no_rel','link_function' );
INSERT INTO TE_PAR VALUES ( 'z',0,'',2,"00000000-0000-0000-0000-0000000001b0","00000000-0000-0000-0000-0000000000e9" );
INSERT INTO TE_PAR VALUES ( 'y',0,'',1,"00000000-0000-0000-0000-0000000001ae","00000000-0000-0000-0000-0000000000ea" );
INSERT INTO TE_PAR VALUES ( 'x',0,'',0,"00000000-0000-0000-0000-0000000001ad","00000000-0000-0000-0000-0000000000eb" );
INSERT INTO TE_PAR VALUES ( 'heading',0,'',0,"00000000-0000-0000-0000-000000000198","00000000-0000-0000-0000-0000000000e8" );
INSERT INTO TE_PAR VALUES ( 'heading',0,'',0,"00000000-0000-0000-0000-000000000191","00000000-0000-0000-0000-0000000000e8" );
INSERT INTO TE_PAR VALUES ( 'alt',0,'',0,"00000000-0000-0000-0000-000000000190","00000000-0000-0000-0000-0000000000ec" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000ef","00000000-0000-0000-0000-0000000000ee",'Control_Port1_ready','','Control_Port1_ready','Control','','Port1','mavcontrol','ready',1,0,'SPR_RO',0,0,4,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000b8","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000f7" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000f2","00000000-0000-0000-0000-0000000000f1",'Control_Port1_get_heading','','Control_Port1_get_heading','Control','','Port1','mavcontrol','get_heading',0,0,'SPR_RO',0,0,1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000b5","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000103" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000f5","00000000-0000-0000-0000-0000000000f4",'Control_Port1_set_heading','','Control_Port1_set_heading','Control','heading:0','Port1','mavcontrol','set_heading',0,0,'SPR_RO',0,0,6,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000b2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000100" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000f8","00000000-0000-0000-0000-0000000000f7",'Control_Port1_set_destination','','Control_Port1_set_destination','Control','x:wp.x, y:wp.y, z:wp.z','Port1','mavcontrol','set_destination',0,0,'SPR_RO',0,0,5,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000af","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000f4" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000fb","00000000-0000-0000-0000-0000000000fa",'Control_Port1_arm','','Control_Port1_arm','Control','','Port1','mavcontrol','arm',0,0,'SPR_RO',0,0,0,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000ac","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000f1" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-0000000000fe","00000000-0000-0000-0000-0000000000fd",'Control_Port1_land','','Control_Port1_land','Control','','Port1','mavcontrol','land',0,0,'SPR_RO',0,0,3,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a9","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000ee" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000101","00000000-0000-0000-0000-000000000100",'Control_Port1_takeoff','','Control_Port1_takeoff','Control','alt:15','Port1','mavcontrol','takeoff',0,0,'SPR_RO',0,0,7,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000104","00000000-0000-0000-0000-000000000103",'Control_Port1_init','','Control_Port1_init','Control','','Port1','mavcontrol','init',0,0,'SPR_RO',0,0,2,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a3","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002c","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000fd" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000107","00000000-0000-0000-0000-000000000106",'MAV_Port1_ready','','MAV_Port1_ready','MAV','','Port1','mavcontrol','ready',1,1,'SPR_PO',0,0,4,"00000000-0000-0000-0000-00000000009d","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000110" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-00000000010a","00000000-0000-0000-0000-000000000109",'MAV_Port1_get_heading','','MAV_Port1_get_heading','MAV','','Port1','mavcontrol','get_heading',0,1,'SPR_PO',0,0,1,"00000000-0000-0000-0000-00000000009a","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000120" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-00000000010d","00000000-0000-0000-0000-00000000010c",'MAV_Port1_set_heading','','MAV_Port1_set_heading','MAV','','Port1','mavcontrol','set_heading',0,1,'SPR_PO',0,0,6,"00000000-0000-0000-0000-000000000097","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000011c" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000111","00000000-0000-0000-0000-000000000110",'MAV_Port1_set_destination','','MAV_Port1_set_destination','MAV','','Port1','mavcontrol','set_destination',0,1,'SPR_PO',0,0,5,"00000000-0000-0000-0000-000000000094","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000010c" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000117","00000000-0000-0000-0000-000000000116",'MAV_Port1_arm','','MAV_Port1_arm','MAV','','Port1','mavcontrol','arm',0,1,'SPR_PO',0,0,0,"00000000-0000-0000-0000-000000000091","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000109" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-00000000011a","00000000-0000-0000-0000-000000000119",'MAV_Port1_land','','MAV_Port1_land','MAV','','Port1','mavcontrol','land',0,1,'SPR_PO',0,0,3,"00000000-0000-0000-0000-00000000008e","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000106" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-00000000011d","00000000-0000-0000-0000-00000000011c",'MAV_Port1_takeoff','','MAV_Port1_takeoff','MAV','','Port1','mavcontrol','takeoff',0,1,'SPR_PO',0,0,7,"00000000-0000-0000-0000-00000000008b","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_MACT VALUES ( "00000000-0000-0000-0000-000000000121","00000000-0000-0000-0000-000000000120",'MAV_Port1_init','','MAV_Port1_init','MAV','','Port1','mavcontrol','init',0,1,'SPR_PO',0,0,2,"00000000-0000-0000-0000-000000000088","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000002e","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000119" );
INSERT INTO R_PART VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001c9",0,1,'is followed by ' );
INSERT INTO R_PART VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cb",0,1,'' );
INSERT INTO R_PART VALUES ( "00000000-0000-0000-0000-0000000000be","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001cd",0,1,'' );
INSERT INTO TE_IIR VALUES ( "00000000-0000-0000-0000-000000000032",'MAV','Port1','mavcontrol',0,'','',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000087","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_IIR VALUES ( "00000000-0000-0000-0000-000000000033",'','Port1','mavcontrol',0,'','',"00000000-0000-0000-0000-0000000001d2","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000031","00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_IIR VALUES ( "00000000-0000-0000-0000-000000000036",'Control','Port1','mavcontrol',0,'','',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a2","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000032" );
INSERT INTO TE_IIR VALUES ( "00000000-0000-0000-0000-000000000037",'','Port1','mavcontrol',0,'','',"00000000-0000-0000-0000-0000000001d6","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000035","00000000-0000-0000-0000-000000000033" );
INSERT INTO TE_DCI VALUES ( "00000000-0000-0000-0000-00000000002e",'MAV_CLASS_NUMBERS','MAV_CLASS_U','MAV_task_numbers','MAV_TASK_NUMBERS','MAV_MAX_CLASS_NUMBERS','MAV_STATE_MODELS','MAV_CLASS_INFO_INIT','MAV_class_info' );
INSERT INTO TE_DCI VALUES ( "00000000-0000-0000-0000-00000000002c",'Control_CLASS_NUMBERS','Control_CLASS_U','Control_task_numbers','Control_TASK_NUMBERS','Control_MAX_CLASS_NUMBERS','Control_STATE_MODELS','Control_CLASS_INFO_INIT','Control_class_info' );
INSERT INTO TE_CIA VALUES ( 'domain_class_info','Escher_Extent_t','active_count','domain_class_count','Escher_ClassNumber_t' );
INSERT INTO R_FORM VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d7","00000000-0000-0000-0000-0000000001ce",0,1,'is flying to' );
INSERT INTO R_FORM VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000d5","00000000-0000-0000-0000-0000000001cc",0,1,'begin with' );
INSERT INTO R_FORM VALUES ( "00000000-0000-0000-0000-0000000000ca","00000000-0000-0000-0000-0000000000e4","00000000-0000-0000-0000-0000000001ca",0,0,'follows' );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001c8","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001c4","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001c0","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001bc","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001b8","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001aa","00000000-0000-0000-0000-0000000001b4",'','',2,'    ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000001a7","00000000-0000-0000-0000-0000000001b3",'','',2,'    ',"00000000-0000-0000-0000-000000000000" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000019c","00000000-0000-0000-0000-00000000019d",'Control_Waypoint * next_wp=0;Control_Waypoint * wp=0;','',1,'  ',"00000000-0000-0000-0000-0000000001c9" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000195","00000000-0000-0000-0000-000000000196",'','',1,'  ',"00000000-0000-0000-0000-0000000001c6" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000018d","00000000-0000-0000-0000-00000000018e",'','',1,'  ',"00000000-0000-0000-0000-0000000001c3" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000189","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001c0" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000017d","00000000-0000-0000-0000-00000000017e",'Control_Controller * ctrl=0;','',1,'  ',"00000000-0000-0000-0000-0000000001b6" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000176","00000000-0000-0000-0000-000000000177",'Control_Controller * ctrl=0;','',1,'  ',"00000000-0000-0000-0000-0000000001b7" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000c4","00000000-0000-0000-0000-0000000000c5",'Control_Waypoint * wp11;Control_Waypoint * wp10;Control_Waypoint * wp9;Control_Waypoint * wp8;Control_Waypoint * wp7;Control_Waypoint * wp6;Control_Waypoint * wp5;Control_Waypoint * wp4;Control_Waypoint * wp3;Control_Waypoint * wp2;Control_Waypoint * wp1;Control_Controller * ctrl;','',1,'  ',"00000000-0000-0000-0000-0000000001b8" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000ba","00000000-0000-0000-0000-0000000000bb",'Control_Controller * ctrl=0;','',1,'  ',"00000000-0000-0000-0000-0000000000ef" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000b7","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000000f2" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000b4","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000000f5" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000b1","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000000f8" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000ae","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000000fb" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000ab","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000000fe" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000a8","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000101" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-0000000000a5","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000104" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000009f","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000107" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000009c","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-00000000010a" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000099","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-00000000010d" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000096","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000111" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000093","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000117" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000090","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-00000000011a" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000008d","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-00000000011d" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000008a","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-000000000121" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000074","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001fa" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000070","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001f8" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000006a","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001f6" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000065","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001f4" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000060","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001f2" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000005c","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001f0" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000058","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001ee" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000051","00000000-0000-0000-0000-000000000052",'','',1,'  ',"00000000-0000-0000-0000-0000000001ec" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000004c","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001ea" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000048","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001e8" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000043","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001e6" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000003d","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001e4" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000039","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001e2" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000034","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001e0" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000002d","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001de" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000029","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001dc" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000025","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001da" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000021","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001d8" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-00000000001d","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001d6" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000019","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001d4" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000015","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001d2" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000011","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001d0" );
INSERT INTO TE_BLK VALUES ( "00000000-0000-0000-0000-000000000007","00000000-0000-0000-0000-000000000000",'','',1,'  ',"00000000-0000-0000-0000-0000000001ce" );
INSERT INTO TE_LNK VALUES ( "00000000-0000-0000-0000-0000000001a2",0,'follows',2,'->Waypoint[R2.follows]','',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001a6",'Waypoint_R2_follows','iWaypoint_R2_follows','wp','Control_Waypoint',1,1,'form' );
INSERT INTO TE_LNK VALUES ( "00000000-0000-0000-0000-0000000001a3",0,'is flying to',3,'->Waypoint[R3.is flying to]','',"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001a1",'Waypoint_R3_is_flying_to','iWaypoint_R3_is_flying_to','self','Control_Waypoint',1,1,'form' );
INSERT INTO TE_ASSIGN VALUES ( 0,0,'','',2,'((Control_Waypoint *)xtUML_detect_empty_handle( wp1, "Waypoint", "wp1.x" ))->x','51',"00000000-0000-0000-0000-000000000013",0 );
INSERT INTO TE_BRIDGE VALUES ( '','',"00000000-0000-0000-0000-000000000029" );
INSERT INTO TE_CREATE_EVENT VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','','','',"00000000-0000-0000-0000-00000000001a" );
INSERT INTO TE_CREATE_INSTANCE VALUES ( "00000000-0000-0000-0000-000000000000",0,'','',"00000000-0000-0000-0000-000000000014" );
INSERT INTO TE_DELETE_INSTANCE VALUES ( "00000000-0000-0000-0000-000000000000",'',0,"00000000-0000-0000-0000-000000000019" );
INSERT INTO TE_ELIF VALUES ( '',"00000000-0000-0000-0000-000000000018" );
INSERT INTO TE_EVENT_PARAMETERS VALUES ( '','','','',"00000000-0000-0000-0000-000000000022" );
INSERT INTO TE_FOR VALUES ( 0,'','','',"00000000-0000-0000-0000-000000000015" );
INSERT INTO TE_FUNCTION VALUES ( '','',"00000000-0000-0000-0000-00000000002a" );
INSERT INTO TE_GENERATE VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','',"00000000-0000-0000-0000-000000000023" );
INSERT INTO TE_GENERATE_CREATOR_EVENT VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','',"00000000-0000-0000-0000-000000000024" );
INSERT INTO TE_GENERATE_PRECREATED_EVENT VALUES ( 0,'',"00000000-0000-0000-0000-000000000021" );
INSERT INTO TE_GENERATE_TO_CLASS VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','',"00000000-0000-0000-0000-000000000025" );
INSERT INTO TE_IF VALUES ( '',"00000000-0000-0000-0000-000000000016" );
INSERT INTO TE_IOP VALUES ( '','',"00000000-0000-0000-0000-000000000027" );
INSERT INTO TE_OPERATION VALUES ( 0,'','','',"00000000-0000-0000-0000-000000000028" );
INSERT INTO TE_RELATE VALUES ( "00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,0,'','','',"00000000-0000-0000-0000-00000000001b" );
INSERT INTO TE_RELATE_USING VALUES ( "00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,0,'','','','','','',"00000000-0000-0000-0000-00000000001c" );
INSERT INTO TE_RETURN VALUES ( '','','',"00000000-0000-0000-0000-00000000002b" );
INSERT INTO TE_SELECT VALUES ( "00000000-0000-0000-0000-000000000000",1,'Control_Controller','Controller','','any','ctrl',"00000000-0000-0000-0000-00000000001f" );
INSERT INTO TE_SELECT_RELATED VALUES ( "00000000-0000-0000-0000-0000000001a2","00000000-0000-0000-0000-0000000001a2","00000000-0000-0000-0000-0000000001a5","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-00000000019f","00000000-0000-0000-0000-000000000000",0,'','','one',1,'next_wp','next_wp',0,'wp','wp','Control_Waypoint' );
INSERT INTO TE_SELECT_RELATED VALUES ( "00000000-0000-0000-0000-00000000019d","00000000-0000-0000-0000-0000000001a3","00000000-0000-0000-0000-0000000001a0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000001ab","00000000-0000-0000-0000-000000000000",0,'','','one',1,'wp','wp',0,'self','self','Control_Controller' );
INSERT INTO TE_SELECT_WHERE VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','','','','',0,0,"00000000-0000-0000-0000-000000000020" );
INSERT INTO TE_SGN VALUES ( "00000000-0000-0000-0000-000000000000",0,'','','','',"00000000-0000-0000-0000-000000000026" );
INSERT INTO TE_UNRELATE VALUES ( "00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,0,'','','',"00000000-0000-0000-0000-00000000001d" );
INSERT INTO TE_UNRELATE_USING VALUES ( "00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,0,'','','','','','',"00000000-0000-0000-0000-00000000001e" );
INSERT INTO TE_WHILE VALUES ( '',"00000000-0000-0000-0000-000000000017" );
INSERT INTO S_EE VALUES ( "00000000-0000-0000-0000-000000000003",'Time','The Time external entity provides date, timestamp, and timer related operations.','TIM',"00000000-0000-0000-0000-000000000000",'','Time',1 );
INSERT INTO S_EE VALUES ( "00000000-0000-0000-0000-00000000004d",'Architecture','','ARCH',"00000000-0000-0000-0000-000000000000",'','Architecture',1 );
INSERT INTO S_EE VALUES ( "00000000-0000-0000-0000-000000000053",'Logging','','LOG',"00000000-0000-0000-0000-000000000000",'','Logging',1 );
INSERT INTO C_C VALUES ( "00000000-0000-0000-0000-000000000085","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",'MAV','',0,"00000000-0000-0000-0000-000000000000",0,'' );
INSERT INTO C_C VALUES ( "00000000-0000-0000-0000-0000000000a0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",'Control','',0,"00000000-0000-0000-0000-000000000000",0,'' );
INSERT INTO C_I VALUES ( "00000000-0000-0000-0000-000000000076","00000000-0000-0000-0000-000000000000",'mavcontrol','' );
INSERT INTO C_P VALUES ( "00000000-0000-0000-0000-000000000087",'mavcontrol','Unnamed Interface','','MAV::Port1::mavcontrol' );
INSERT INTO C_R VALUES ( "00000000-0000-0000-0000-0000000000a2",'mavcontrol','','Unnamed Interface','Control::Port1::mavcontrol' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-000000000077","00000000-0000-0000-0000-000000000076",-1,'init','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-000000000078","00000000-0000-0000-0000-000000000076",-1,'takeoff','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-00000000007a","00000000-0000-0000-0000-000000000076",-1,'land','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-00000000007b","00000000-0000-0000-0000-000000000076",-1,'arm','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-000000000076",-1,'set_destination','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-000000000080","00000000-0000-0000-0000-000000000076",-1,'set_heading','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-000000000082","00000000-0000-0000-0000-000000000076",-1,'get_heading','' );
INSERT INTO C_EP VALUES ( "00000000-0000-0000-0000-000000000083","00000000-0000-0000-0000-000000000076",-1,'ready','' );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-000000000077","00000000-0000-0000-0000-00000000004f",'init','',0,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-000000000078","00000000-0000-0000-0000-00000000004f",'takeoff','',0,'',"00000000-0000-0000-0000-000000000077" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-00000000007a","00000000-0000-0000-0000-00000000004f",'land','',0,'',"00000000-0000-0000-0000-000000000078" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-00000000007b","00000000-0000-0000-0000-00000000004f",'arm','',0,'',"00000000-0000-0000-0000-00000000007a" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-00000000004f",'set_destination','',0,'',"00000000-0000-0000-0000-00000000007b" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-000000000080","00000000-0000-0000-0000-00000000004f",'set_heading','',0,'',"00000000-0000-0000-0000-00000000007c" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-000000000082","00000000-0000-0000-0000-00000000006d",'get_heading','',0,'',"00000000-0000-0000-0000-000000000080" );
INSERT INTO C_IO VALUES ( "00000000-0000-0000-0000-000000000083","00000000-0000-0000-0000-00000000004f",'ready','',1,'',"00000000-0000-0000-0000-000000000082" );
INSERT INTO C_SF VALUES ( "00000000-0000-0000-0000-0000000001d3","00000000-0000-0000-0000-0000000000a2","00000000-0000-0000-0000-000000000087",'','MAV::Port1::mavcontrol -o)- Control::Port1::mavcontrol' );
INSERT INTO C_PP VALUES ( "00000000-0000-0000-0000-000000000079","00000000-0000-0000-0000-000000000078","00000000-0000-0000-0000-00000000006d",'alt','',0,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO C_PP VALUES ( "00000000-0000-0000-0000-00000000007d","00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-00000000006d",'x','',0,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO C_PP VALUES ( "00000000-0000-0000-0000-00000000007e","00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-00000000006d",'y','',0,'',"00000000-0000-0000-0000-00000000007d" );
INSERT INTO C_PP VALUES ( "00000000-0000-0000-0000-00000000007f","00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-00000000006d",'z','',0,'',"00000000-0000-0000-0000-00000000007e" );
INSERT INTO C_PP VALUES ( "00000000-0000-0000-0000-000000000081","00000000-0000-0000-0000-000000000080","00000000-0000-0000-0000-00000000006d",'heading','',0,'',"00000000-0000-0000-0000-000000000000" );
INSERT INTO C_IR VALUES ( "00000000-0000-0000-0000-000000000087","00000000-0000-0000-0000-000000000076","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000086" );
INSERT INTO C_IR VALUES ( "00000000-0000-0000-0000-0000000000a2","00000000-0000-0000-0000-000000000076","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a1" );
INSERT INTO C_PO VALUES ( "00000000-0000-0000-0000-000000000086","00000000-0000-0000-0000-000000000085",'Port1',0,0 );
INSERT INTO C_PO VALUES ( "00000000-0000-0000-0000-0000000000a1","00000000-0000-0000-0000-0000000000a0",'Port1',0,0 );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000a3","00000000-0000-0000-0000-000000000077","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000a6","00000000-0000-0000-0000-000000000078","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000a9","00000000-0000-0000-0000-00000000007a","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000ac","00000000-0000-0000-0000-00000000007b","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000af","00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000b2","00000000-0000-0000-0000-000000000080","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000b5","00000000-0000-0000-0000-000000000082","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_REP VALUES ( "00000000-0000-0000-0000-0000000000b8","00000000-0000-0000-0000-000000000083","00000000-0000-0000-0000-0000000000a2" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-000000000088","00000000-0000-0000-0000-000000000077","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-00000000008b","00000000-0000-0000-0000-000000000078","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-00000000008e","00000000-0000-0000-0000-00000000007a","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-000000000091","00000000-0000-0000-0000-00000000007b","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-000000000094","00000000-0000-0000-0000-00000000007c","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-000000000097","00000000-0000-0000-0000-000000000080","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-00000000009a","00000000-0000-0000-0000-000000000082","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_PEP VALUES ( "00000000-0000-0000-0000-00000000009d","00000000-0000-0000-0000-000000000083","00000000-0000-0000-0000-000000000087" );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000a3",'init','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000a6",'takeoff','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000a9",'land','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000ac",'arm','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000af",'set_destination','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000b2",'set_heading','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000b5",'get_heading','','',1,0 );
INSERT INTO SPR_RO VALUES ( "00000000-0000-0000-0000-0000000000b8",'ready','','select any ctrl from Controller;
generate Controller2:''ready'' to ctrl;
',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-000000000088",'init','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-00000000008b",'takeoff','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-00000000008e",'land','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-000000000091",'arm','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-000000000094",'set_destination','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-000000000097",'set_heading','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-00000000009a",'get_heading','','',1,0 );
INSERT INTO SPR_PO VALUES ( "00000000-0000-0000-0000-00000000009d",'ready','','',1,0 );
INSERT INTO CL_IPINS VALUES ( "00000000-0000-0000-0000-0000000001d3","00000000-0000-0000-0000-0000000001d2" );
INSERT INTO CL_IP VALUES ( "00000000-0000-0000-0000-0000000001d2",'mavcontrol','' );
INSERT INTO CL_IR VALUES ( "00000000-0000-0000-0000-0000000001d6","00000000-0000-0000-0000-0000000001d3",'mavcontrol','' );
INSERT INTO CL_IIR VALUES ( "00000000-0000-0000-0000-0000000001d2","00000000-0000-0000-0000-000000000087","00000000-0000-0000-0000-0000000001d1","00000000-0000-0000-0000-000000000000",'mavcontrol','' );
INSERT INTO CL_IIR VALUES ( "00000000-0000-0000-0000-0000000001d6","00000000-0000-0000-0000-0000000000a2","00000000-0000-0000-0000-0000000001d5","00000000-0000-0000-0000-000000000000",'mavcontrol','' );
INSERT INTO CL_IC VALUES ( "00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000085","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,'','gnc::Library::MAV','' );
INSERT INTO CL_IC VALUES ( "00000000-0000-0000-0000-0000000001d4","00000000-0000-0000-0000-0000000000a0","00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",0,'','gnc::Library::Control','' );
INSERT INTO CL_POR VALUES ( "00000000-0000-0000-0000-0000000001d0","00000000-0000-0000-0000-000000000086",'Port1',"00000000-0000-0000-0000-0000000001d1" );
INSERT INTO CL_POR VALUES ( "00000000-0000-0000-0000-0000000001d4","00000000-0000-0000-0000-0000000000a1",'Port1',"00000000-0000-0000-0000-0000000001d5" );
INSERT INTO SM_SM VALUES ( "00000000-0000-0000-0000-000000000185",'',0 );
INSERT INTO SM_STATE VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'init',1,0 );
INSERT INTO SM_STATE VALUES ( "00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'take off',2,0 );
INSERT INTO SM_STATE VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'land',3,0 );
INSERT INTO SM_STATE VALUES ( "00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'go',4,0 );
INSERT INTO SM_EVT VALUES ( "00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",1,'start',0,'','Controller1','' );
INSERT INTO SM_EVT VALUES ( "00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",2,'ready',0,'','Controller2','' );
INSERT INTO SM_EVT VALUES ( "00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",3,'halt',0,'','Controller3','' );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEME VALUES ( "00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_NSTXN VALUES ( "00000000-0000-0000-0000-0000000001b5","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_NSTXN VALUES ( "00000000-0000-0000-0000-0000000001b9","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_NSTXN VALUES ( "00000000-0000-0000-0000-0000000001bd","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_NSTXN VALUES ( "00000000-0000-0000-0000-0000000001c1","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_NSTXN VALUES ( "00000000-0000-0000-0000-0000000001c5","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000186","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_CH VALUES ( "00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000",'' );
INSERT INTO SM_TXN VALUES ( "00000000-0000-0000-0000-0000000001b5","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018a","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_TXN VALUES ( "00000000-0000-0000-0000-0000000001b9","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_TXN VALUES ( "00000000-0000-0000-0000-0000000001bd","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_TXN VALUES ( "00000000-0000-0000-0000-0000000001c1","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000192","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_TXN VALUES ( "00000000-0000-0000-0000-0000000001c5","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_MOORE VALUES ( "00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_MOAH VALUES ( "00000000-0000-0000-0000-000000000187","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000186" );
INSERT INTO SM_MOAH VALUES ( "00000000-0000-0000-0000-00000000018b","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-00000000018a" );
INSERT INTO SM_MOAH VALUES ( "00000000-0000-0000-0000-000000000193","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000192" );
INSERT INTO SM_MOAH VALUES ( "00000000-0000-0000-0000-00000000019a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000199" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-000000000187","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-00000000018b","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-000000000193","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-00000000019a","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-0000000001b6","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-0000000001ba","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-0000000001be","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-0000000001c2","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_AH VALUES ( "00000000-0000-0000-0000-0000000001c6","00000000-0000-0000-0000-000000000185" );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-000000000187","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-00000000018b","00000000-0000-0000-0000-000000000185",1,'Port1::takeoff( alt:15);
Port1::set_heading( heading:0 );','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-000000000193","00000000-0000-0000-0000-000000000185",1,'Port1::land();
Port1::set_heading( heading:0 );','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-00000000019a","00000000-0000-0000-0000-000000000185",1,'select one wp related by self -> Waypoint[R3.''is flying to''];
Port1::set_destination( x:wp.x, y:wp.y, z:wp.z );

select one next_wp related by wp -> Waypoint[R2.''follows''];
if (not_empty next_wp)
	relate self to next_wp across R3.''is flying to'';
else
	generate Controller3:''halt'' to self;
end if;
//Port1::set_destination( x:3, y:3, z:1 );
//Port1::set_heading( heading:0 );','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-0000000001b6","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-0000000001ba","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-0000000001be","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-0000000001c2","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ACT VALUES ( "00000000-0000-0000-0000-0000000001c6","00000000-0000-0000-0000-000000000185",1,'','',0 );
INSERT INTO SM_ISM VALUES ( "00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000000be" );
INSERT INTO SM_SEVT VALUES ( "00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEVT VALUES ( "00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_SEVT VALUES ( "00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_LEVT VALUES ( "00000000-0000-0000-0000-000000000181","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_LEVT VALUES ( "00000000-0000-0000-0000-0000000000bf","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_LEVT VALUES ( "00000000-0000-0000-0000-00000000017a","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-000000000000" );
INSERT INTO SM_TAH VALUES ( "00000000-0000-0000-0000-0000000001b6","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000001b5" );
INSERT INTO SM_TAH VALUES ( "00000000-0000-0000-0000-0000000001ba","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000001b9" );
INSERT INTO SM_TAH VALUES ( "00000000-0000-0000-0000-0000000001be","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000001bd" );
INSERT INTO SM_TAH VALUES ( "00000000-0000-0000-0000-0000000001c2","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000001c1" );
INSERT INTO SM_TAH VALUES ( "00000000-0000-0000-0000-0000000001c6","00000000-0000-0000-0000-000000000185","00000000-0000-0000-0000-0000000001c5" );
INSERT INTO E_GEN VALUES ( "00000000-0000-0000-0000-0000000000bc","00000000-0000-0000-0000-0000000000bd" );
INSERT INTO E_GEN VALUES ( "00000000-0000-0000-0000-000000000178","00000000-0000-0000-0000-000000000179" );
INSERT INTO E_GEN VALUES ( "00000000-0000-0000-0000-00000000017f","00000000-0000-0000-0000-000000000180" );
INSERT INTO E_GEN VALUES ( "00000000-0000-0000-0000-0000000001b4","00000000-0000-0000-0000-0000000001ab" );
INSERT INTO E_ESS VALUES ( "00000000-0000-0000-0000-0000000000bc",1,0,2,10,2,22,1,22,0,0,0,0 );
INSERT INTO E_ESS VALUES ( "00000000-0000-0000-0000-000000000178",1,0,2,10,2,22,1,35,0,0,0,0 );
INSERT INTO E_ESS VALUES ( "00000000-0000-0000-0000-00000000017f",1,0,2,10,2,22,1,35,0,0,0,0 );
INSERT INTO E_ESS VALUES ( "00000000-0000-0000-0000-0000000001b4",1,0,8,11,8,23,0,0,0,0,0,0 );
INSERT INTO E_GES VALUES ( "00000000-0000-0000-0000-0000000000bc" );
INSERT INTO E_GES VALUES ( "00000000-0000-0000-0000-000000000178" );
INSERT INTO E_GES VALUES ( "00000000-0000-0000-0000-00000000017f" );
INSERT INTO E_GES VALUES ( "00000000-0000-0000-0000-0000000001b4" );
INSERT INTO E_GSME VALUES ( "00000000-0000-0000-0000-0000000000bc","00000000-0000-0000-0000-0000000000bf" );
INSERT INTO E_GSME VALUES ( "00000000-0000-0000-0000-000000000178","00000000-0000-0000-0000-00000000017a" );
INSERT INTO E_GSME VALUES ( "00000000-0000-0000-0000-00000000017f","00000000-0000-0000-0000-000000000181" );
INSERT INTO E_GSME VALUES ( "00000000-0000-0000-0000-0000000001b4","00000000-0000-0000-0000-00000000017a" );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000003",1,"00000000-0000-0000-0000-000000000002","00000000-0000-0000-0000-000000000000",5 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000004d",1,"00000000-0000-0000-0000-000000000002","00000000-0000-0000-0000-000000000000",5 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000053",1,"00000000-0000-0000-0000-000000000002","00000000-0000-0000-0000-000000000000",5 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000076",1,"00000000-0000-0000-0000-000000000075","00000000-0000-0000-0000-000000000000",6 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000085",1,"00000000-0000-0000-0000-000000000084","00000000-0000-0000-0000-000000000000",2 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000a0",1,"00000000-0000-0000-0000-000000000084","00000000-0000-0000-0000-000000000000",2 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000c1",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a0",7 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000c2",1,"00000000-0000-0000-0000-0000000000c1","00000000-0000-0000-0000-000000000000",1 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000174",1,"00000000-0000-0000-0000-0000000000c1","00000000-0000-0000-0000-000000000000",1 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000017b",1,"00000000-0000-0000-0000-0000000000c1","00000000-0000-0000-0000-000000000000",1 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000182",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-0000000000a0",7 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000be",1,"00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000",4 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000ca",1,"00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000",4 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000e4",1,"00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000",9 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000d5",1,"00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000",9 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000d7",1,"00000000-0000-0000-0000-000000000182","00000000-0000-0000-0000-000000000000",9 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d0",1,"00000000-0000-0000-0000-0000000001cf","00000000-0000-0000-0000-000000000000",21 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d4",1,"00000000-0000-0000-0000-0000000001cf","00000000-0000-0000-0000-000000000000",21 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d3",1,"00000000-0000-0000-0000-0000000001cf","00000000-0000-0000-0000-000000000000",22 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000004f",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000003f",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000000a",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000006d",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000056",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d7",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000184",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d8",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000000c0",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001d9",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000032",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001da",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001db",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-0000000001dc",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-000000000005",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000002f",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO PE_PE VALUES ( "00000000-0000-0000-0000-00000000002b",1,"00000000-0000-0000-0000-000000000000","00000000-0000-0000-0000-000000000000",3 );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000004f","00000000-0000-0000-0000-000000000000",'void','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000003f","00000000-0000-0000-0000-000000000000",'boolean','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000000a","00000000-0000-0000-0000-000000000000",'integer','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000006d","00000000-0000-0000-0000-000000000000",'real','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-000000000056","00000000-0000-0000-0000-000000000000",'string','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001d7","00000000-0000-0000-0000-000000000000",'unique_id','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-000000000184","00000000-0000-0000-0000-000000000000",'state<State_Model>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001d8","00000000-0000-0000-0000-000000000000",'same_as<Base_Attribute>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000000c0","00000000-0000-0000-0000-000000000000",'inst_ref<Object>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001d9","00000000-0000-0000-0000-000000000000",'inst_ref_set<Object>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-000000000032","00000000-0000-0000-0000-000000000000",'inst<Event>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001da","00000000-0000-0000-0000-000000000000",'inst<Mapping>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001db","00000000-0000-0000-0000-000000000000",'inst_ref<Mapping>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-0000000001dc","00000000-0000-0000-0000-000000000000",'component_ref','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-000000000005","00000000-0000-0000-0000-000000000000",'date','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000002f","00000000-0000-0000-0000-000000000000",'inst_ref<Timer>','','' );
INSERT INTO S_DT VALUES ( "00000000-0000-0000-0000-00000000002b","00000000-0000-0000-0000-000000000000",'timestamp','','' );
