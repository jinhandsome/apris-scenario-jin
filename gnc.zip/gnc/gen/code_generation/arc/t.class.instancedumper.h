.if ( te_sys.InstanceLoading )
void ${te_class.GeneratedName}_instancedumper( ${te_instance.handle} );
.end if
