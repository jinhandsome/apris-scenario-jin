#ifndef SYS_XTUMLLOAD_H
#define SYS_XTUMLLOAD_H
${te_target.c2cplusplus_linkage_begin}

int ${te_prefix.result}xtUML_load( int, char * [] );
void ${te_prefix.result}MASL_load( const char * );

${te_target.c2cplusplus_linkage_end}
#endif   /* SYS_XTUMLLOAD_H */
.//
